

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<title>Contact - AIR 7 SEAS</title>
<link rel="shortcut icon" href="source/images/a7s-icon.ico"/>
<meta charset="utf-8"/>
<meta name="description"
      content="Air 7 seas is leading Freight Forwarder, NVOCC, OTI, Cargo Consolidator, Custom Broker, Carrier, and Shipping Agents for Ship Lines, Airlines, Truckers, Shipper & Consignee to handle International and Domestic transportation by Air Freight, Sea Freight or Road Freight.">
<meta name="description"
      content="Air 7 Seas Overseas Relocation, Air 7 Seas Moving Overseas, Air 7 Seas Relocation Services, Air 7 Seas Shipping India, Air 7 Seas Shipping USA, Air 7 Seas Freight Forwarder, Air 7 Seas Air Freight, Air 7 Seas Air Cargo, Air 7 Seas Customs Clearance, Air 7 Seas International Shipping Companies, Air 7 Seas Moving Estimate, Air 7 Seas Shipping Quote, Air 7 Seas Moving International, Air 7 Seas Domestic Movers, Air 7 Seas Shipping Agent, Air 7 Seas Shipping International, Air 7 Seas International Moving Service, Air 7 Seas Cargo Agent, Air 7 Seas Customs Broker, Air 7 Seas International Mover, Air 7 Seas Household Goods, Air 7 Seas Commercial Goods, Air 7 Seas Breakbulk Cargo, Air 7 Seas Car Shipping, Air 7 Seas Motorbike Shipping, Air 7 Seas Auto Vehicle Mechinery, Air 7 Seas Cargo Consolidation, Air 7 Seas Freight Service Provider">
<meta name="keywords"
      content="Overseas Relocation, Moving Overseas, Relocation Services, Shipping India, Shipping USA, Freight Forwarder, Air Freight, Air Cargo, Customs Clearance, International Shipping Companies, Moving Estimate, Shipping Quote, Moving International, Domestic Movers, Shipping Agent, Shipping International, International Moving Service, Cargo Agent, Customs Broker, International Mover, Household Goods, Commercial Goods, Breakbulk Cargo, Car Shipping, Motorbike Shipping, Auto Vehicle Mechinery, Cargo Consolidation, Freight Service Provider">
<meta name="author" content="Air 7 Seas Transport Logistics Pvt Ltd">
<!--  <base href="http://www.air7seas.com/"> -->

<link href="source/css/tel/intlTelInput.css" rel="stylesheet">

<link href="source/css/sole.css" rel="stylesheet" type="text/css" visible="true"/>
<link href="source/css/skin.css" rel="stylesheet" type="text/css" visible="true"/>
<link href="source/css/controls.css" rel="stylesheet" type="text/css" visible="true"/>
<script src="source/js/script.js" type="text/javascript"></script>

<link rel="stylesheet" type="text/css" href="source/css/jquery.datetimepicker.css"/>
<script src="source/js/jquery-1.11.1.js"></script>
<script src="source/js/jquery.validate.js"></script>
<script>
    $().ready(function () {

        $("#frmContact").validate({
            rules: {
                name: "required",
                phone: "required",
                email: "required",
                captcha: "required"
            },
            messages: {
                name: "",
                phone: "",
                email: "",
                captcha: " "
            }
        });
    });
</script>

<style>
    body {
        margin: 0px;
        padding: 0px;
    }

    #cc:hover {
        text-decoration: underline;
    }

    #captcha.success {
        border: 1px solid #49c24f;
        background: #bcffbf;
    }

    #captcha.error {
        border: 1px solid #c24949;
        background: #ffbcbc;
    }

    #loader {
        height: 90%;
        width: 100%;
        position: absolute;
        background-color: #ffffff;
        z-index: 2147483647 !important;
        opacity: 0.8;
        overflow: hidden;
        text-align: center;
        top: 0;
        left: 0;

    }
</style>
<script type="text/javascript">
function change_captcha() {
    document.getElementById('captcha_cv').src = "get_captcha.php?rnd=" + Math.random();
}


function contactList(items) {
    document.getElementById("abi-contact").style.display = "none";
    document.getElementById("abq-contact").style.display = "none";


    document.getElementById("lax-lgb-ont-contact").style.display = "none";
    document.getElementById("dfw-contact").style.display = "none";
    document.getElementById("nyc-contact").style.display = "none";
    document.getElementById("atl-contact").style.display = "none";
    document.getElementById("ord-chi-contact").style.display = "none";
    //document.getElementById("bwi-contact").style.display = "none";
    document.getElementById("mia-contact").style.display = "none";
    document.getElementById("sfo-oak-sjc-contact").style.display = "none";
    document.getElementById("bhm-contact").style.display = "none";
    document.getElementById("hsv-contact").style.display = "none";
    document.getElementById("mgm-contact").style.display = "none";
    document.getElementById("mob-contact").style.display = "none";
    document.getElementById("cvg-contact").style.display = "none";
    document.getElementById("chs-contact").style.display = "none";
    document.getElementById("gsp-contact").style.display = "none";
    document.getElementById("bna-contact").style.display = "none";
    document.getElementById("mem-contact").style.display = "none";
    document.getElementById("tri-contact").style.display = "none";
    document.getElementById("tys-contact").style.display = "none";
    document.getElementById("lit-contact").style.display = "none";
    document.getElementById("top-contact").style.display = "none";
    document.getElementById("btr-contact").style.display = "none";
    document.getElementById("btr-lft-contact").style.display = "none";
    document.getElementById("shv-contact").style.display = "none";
    document.getElementById("msy-contact").style.display = "none";
    document.getElementById("okc-contact").style.display = "none";
    document.getElementById("tul-contact").style.display = "none";
    document.getElementById("act-contact").style.display = "none";
    document.getElementById("crp-contact").style.display = "none";
    document.getElementById("elp-contact").style.display = "none";
    document.getElementById("iah-hou-contact").style.display = "none";
    document.getElementById("lbb-contact").style.display = "none";
    document.getElementById("lrd-contact").style.display = "none";
    document.getElementById("maf-contact").style.display = "none";
    document.getElementById("mfe-contact").style.display = "none";
    document.getElementById("sat-contact").style.display = "none";
    document.getElementById("sps-contact").style.display = "none";
    document.getElementById("aus-contact").style.display = "none";
    document.getElementById("ama-contact").style.display = "none";
    document.getElementById("bdl-contact").style.display = "none";
    document.getElementById("bos-contact").style.display = "none";
    document.getElementById("bwi-contact").style.display = "none";
    document.getElementById("pwm-contact").style.display = "none";
    document.getElementById("mht-contact").style.display = "none";
    document.getElementById("syr-contact").style.display = "none";
    document.getElementById("swf-contact").style.display = "none";
    document.getElementById("buf-contact").style.display = "none";
    document.getElementById("bgm-contact").style.display = "none";
    document.getElementById("alb-contact").style.display = "none";
    document.getElementById("roc-contact").style.display = "none";
    document.getElementById("pit-contact").style.display = "none";
    document.getElementById("phl-contact").style.display = "none";
    document.getElementById("mdt-contact").style.display = "none";
    document.getElementById("orf-contact").style.display = "none";
    document.getElementById("ric-contact").style.display = "none";
    document.getElementById("btv-contact").style.display = "none";
    document.getElementById("mgw-contact").style.display = "none";
    document.getElementById("jax-contact").style.display = "none";
    document.getElementById("pns-contact").style.display = "none";
    document.getElementById("rsw-contact").style.display = "none";
    document.getElementById("tpa-contact").style.display = "none";
    document.getElementById("orl-mco-contact").style.display = "none";
    document.getElementById("sdf-contact").style.display = "none";
    document.getElementById("clt-contact").style.display = "none";
    document.getElementById("gso-contact").style.display = "none";
    document.getElementById("rdu-contact").style.display = "none";
    document.getElementById("avl-contact").style.display = "none";
    document.getElementById("den-contact").style.display = "none";
    document.getElementById("boi-contact").style.display = "none";
    document.getElementById("rno-contact").style.display = "none";
    document.getElementById("pdx-contact").style.display = "none";
    document.getElementById("slc-contact").style.display = "none";
    document.getElementById("geg-contact").style.display = "none";
    document.getElementById("sea-contact").style.display = "none";
    document.getElementById("phx-contact").style.display = "none";
    document.getElementById("tuc-contact").style.display = "none";
    document.getElementById("ols-contact").style.display = "none";
    document.getElementById("san-contact").style.display = "none";
    document.getElementById("las-contact").style.display = "none";
    document.getElementById("smf-contact").style.display = "none";
    document.getElementById("brl-contact").style.display = "none";
    document.getElementById("cid-contact").style.display = "none";
    document.getElementById("dsm-contact").style.display = "none";
    document.getElementById("mli-contact").style.display = "none";
    document.getElementById("evv-contact").style.display = "none";
    document.getElementById("ind-contact").style.display = "none";
    document.getElementById("sbn-contact").style.display = "none";
    document.getElementById("dtt-dtw-contact").style.display = "none";
    document.getElementById("grr-cad-contact").style.display = "none";
    document.getElementById("msp-contact").style.display = "none";
    document.getElementById("mci-mkc-contact").style.display = "none";
    document.getElementById("stl-contact").style.display = "none";
    document.getElementById("jln-contact").style.display = "none";
    document.getElementById("oma-contact").style.display = "none";
    document.getElementById("cle-contact").style.display = "none";
    document.getElementById("cmh-contact").style.display = "none";
    document.getElementById("day-contact").style.display = "none";
    document.getElementById("tol-contact").style.display = "none";
    document.getElementById("mdn-contact").style.display = "none";
    document.getElementById("mke-contact").style.display = "none";
    document.getElementById("iad-contact").style.display = "none";
    document.getElementById("jfk-lga-contact").style.display = "none";
    document.getElementById("nyc-ewr-contact").style.display = "none";
    document.getElementById(items).style.display = "block";

    if (items == "abi-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3368.879854908879!2d-99.72170080000001!3d32.3955822!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86569278896e6c2f%3A0xbaa23741c8681015!2s141+Tannehill+Dr%2C+Abilene%2C+TX+79602%2C+USA!5e0!3m2!1sen!2sin!4v1423578826476';
    } else if (items == "abq-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3266.1019549792063!2d-106.618258!3d35.054190000000006!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87220b84d8603977%3A0xad49d57f261e057e!2s2400+Alamo+Ave+SE%2C+Albuquerque%2C+NM+87106%2C+USA!5e0!3m2!1sen!2sin!4v1423586907138';
    } else if (items == "lax-lgb-ont-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3313.665611277337!2d-118.22755578512974!3d33.84673318066231!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80dd34be2a68c9c3%3A0xc9ac740b3dbb0d60!2s2665+E+Del+Amo+Blvd%2C+Compton%2C+CA+90220!5e0!3m2!1sen!2sin!4v1487801862965';
    } else if (items == "dfw-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3348.585233079465!2d-97.06166540000001!3d32.935555!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x864c2b1aa124f577%3A0xf7f3f7e29d44bb13!2s1061+Texan+Trail+%23100%2C+Grapevine%2C+TX+76051%2C+USA!5e0!3m2!1sen!2sin!4v1423741274309';
    } else if (items == "nyc-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3019.4448214066683!2d-74.0653913!3d40.8181922!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c2f8656356d361%3A0x4d93b30bb7087e74!2s369+Washington+Ave+%237%2C+Carlstadt%2C+NJ+07072%2C+USA!5e0!3m2!1sen!2sin!4v1423573838326';
    } else if (items == "atl-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3322.786408079394!2d-84.4081379!3d33.610845999999995!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88f4fcee4799667b%3A0x5e882f9da307421f!2s560+Atlanta+S+Pkwy+%23600%2C+Atlanta%2C+GA+30349%2C+USA!5e0!3m2!1sen!2sin!4v1423574001335';
    } else if (items == "ord-chi-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2965.3677103245523!2d-87.979567!3d41.992383399999994!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880fb19b22537d37%3A0xbabb54121532bff!2s814+Wood+Dale+Rd%2C+Wood+Dale%2C+IL+60191%2C+USA!5e0!3m2!1sen!2sin!4v1423574081462';
    } else if (items == "bwi-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3093.75726171768!2d-76.6665287!3d39.157502300000004!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89b7e31642ccf139%3A0xcb5133dcf514ac07!2s1901+Park+100+Dr+%23102%2C+Glen+Burnie%2C+MD+21061%2C+USA!5e0!3m2!1sen!2sin!4v1423581718124';
    } else if (items == "mia-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3590.795806587093!2d-80.26006000000001!3d25.843273!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88d9b091ff431741%3A0x2239cc206c2ae386!2s2275+E+11th+Ave%2C+Hialeah%2C+FL+33013%2C+USA!5e0!3m2!1sen!2sin!4v1423574272493';
    } else if (items == "sfo-oak-sjc-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3169.337501539561!2d-121.89725399999998!3d37.405496899999996!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x808fceb215c020c3%3A0xe5a67952c0fb8022!2s1815+Houret+Ct%2C+Milpitas%2C+CA+95035%2C+USA!5e0!3m2!1sen!2sin!4v1423574392176';
    } else if (items == "bhm-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3321.229918653541!2d-86.7272556851356!3d33.651203980716936!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88890f464094307d%3A0xef47b507199ec2c6!2s1531+Red+Hollow+Rd%2C+Birmingham%2C+AL+35215%2C+USA!5e0!3m2!1sen!2sin!4v1488582865701';
    } else if (items == "hsv-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3281.304916041647!2d-86.7628897!3d34.672253100000006!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886265133afc0fc1%3A0xb9ea40f6d53cbe39!2s9310+Madison+Blvd+%231%2C+Madison%2C+AL+35758%2C+USA!5e0!3m2!1sen!2sin!4v1423574589519';
    } else if (items == "mgm-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3368.5659537245033!2d-86.232266!3d32.403995!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x888c2992383c76c9%3A0x4e6c1624c02f253c!2s2541+Midpark+Rd%2C+Montgomery%2C+AL+36109%2C+USA!5e0!3m2!1sen!2sin!4v1423574668332';
    } else if (items == "mob-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d8164.12145381912!2d-88.08411634639805!3d30.64550393934767!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x889a4e8f6f4409ef%3A0xab0e74880572ecd0!2s2215+Avenue+O%2C+Mobile%2C+AL+36615%2C+USA!5e0!3m2!1sen!2sin!4v1545377812254';
    } else if (items == "cvg-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3098.101149520565!2d-84.62804799999999!3d39.058609!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8841c8476c6b4f7d%3A0xcf11c9ea783eeccf!2s1810+Airport+Exchange+Blvd+%23100%2C+Erlanger%2C+KY+41018%2C+USA!5e0!3m2!1sen!2sin!4v1423574810526';
    } else if (items == "chs-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3348.7128549644735!2d-80.063699!3d32.932184!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88fe62379bc72d29%3A0xf9549329169dd345!2s3074+Ashley+Phosphate+Rd%2C+North+Charleston%2C+SC+29418%2C+USA!5e0!3m2!1sen!2sin!4v1423577035241';
    } else if (items == "gsp-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3273.1954041562735!2d-82.22381109999999!3d34.8764392!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x885829f8ee7cb9f5%3A0xfdc39d8bd0a10805!2s12+Runion+Dr%2C+Greer%2C+SC+29651%2C+USA!5e0!3m2!1sen!2sin!4v1423577155744';
    } else if (items == "bna-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3223.9548019521108!2d-86.6956591!3d36.0945898!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88646efc7f2d6625%3A0x18855349e954f0e2!2s541+Harding+Industrial+Dr%2C+Nashville%2C+TN+37211%2C+USA!5e0!3m2!1sen!2sin!4v1423577225886';
    } else if (items == "mem-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3266.4997899402083!2d-89.9131101!3d35.04424169999999!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x887f85f6d542bd93%3A0xbc7000b69389a0d3!2s3861+Knight+Rd%2C+Memphis%2C+TN+38118%2C+USA!5e0!3m2!1sen!2sin!4v1423577736415';
    } else if (items == "tri-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3207.5203555910584!2d-82.4297752!3d36.493299300000004!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x885a8f0181214741%3A0x9f591e2a4e072913!2s873+Centenary+Rd%2C+Blountville%2C+TN+37617%2C+USA!5e0!3m2!1sen!2sin!4v1423577805913';
    } else if (items == "tys-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d3234.846587608563!2d-83.97140598520842!3d35.82823952950397!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1s3267+North+Park+Blvd%2C+Bldg+10%2C+Ste%23+V!5e0!3m2!1sen!2sin!4v1545378791452';
    } else if (items == "lit-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3279.3738871325377!2d-92.245489!3d34.720968899999995!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87d2bbb82e089df3%3A0x32f662263dae891b!2s2323+E+Roosevelt+Rd%2C+Little+Rock%2C+AR+72206%2C+USA!5e0!3m2!1sen!2sin!4v1423577960566';
    } else if (items == "top-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3101.421875745639!2d-95.671526!3d38.982867000000006!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87bf1cf3d2eda7b9%3A0x452d7f2b7a51c7d!2s4631+SE+Adams+St%2C+Topeka%2C+KS+66609%2C+USA!5e0!3m2!1sen!2sin!4v1423578034782';
    } else if (items == "btr-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3441.637364695697!2d-91.0566758!3d30.389653700000004!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8626bb2b51e0c1a7%3A0xcb84978f68c2d70d!2s11337+Cedar+Park+Ave%2C+Baton+Rouge%2C+LA+70809%2C+USA!5e0!3m2!1sen!2sin!4v1423578101454';
    } else if (items == "btr-lft-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3445.5562985928004!2d-92.11305399999999!3d30.278221000000002!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x862498f8f816bc19%3A0xfad17ff0e7e5cdfe!2s1441+LA-93%2C+Scott%2C+LA+70583%2C+USA!5e0!3m2!1sen!2sin!4v1423578264166';
    } else if (items == "shv-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3363.7523353399874!2d-93.755684!3d32.53276100000001!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8636ccda2f173759%3A0x4374506660b6e52b!2s209+Kansas+City+Ave%2C+Shreveport%2C+LA+71107%2C+USA!5e0!3m2!1sen!2sin!4v1423578331244';
    } else if (items == "msy-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3455.731252378673!2d-90.2708189!3d29.987152599999995!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8620ba9ff365af03%3A0x7fa4b8b4f9e8901c!2s200+Crofton+Rd+%23500%2C+Louis+Armstrong+New+Orleans+International+Airport%2C+Kenner%2C+LA+70062%2C+USA!5e0!3m2!1sen!2sin!4v1423578499508';
    } else if (items == "okc-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3249.988053005562!2d-97.4786321!3d35.4550902!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87b2165777951029%3A0x9b6d09c1607af7a6!2s1905+S+Skyline+Dr%2C+Oklahoma+City%2C+OK+73129%2C+USA!5e0!3m2!1sen!2sin!4v1423578581572';
    } else if (items == "tul-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3220.557107744966!2d-95.8511389!3d36.17733069999999!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87b6f3b17e352a83%3A0xb771ae3f0945f753!2s1533+N+Garnett+Rd%2C+Tulsa%2C+OK+74116%2C+USA!5e0!3m2!1sen!2sin!4v1423578656627';
    } else if (items == "act-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3397.509847667065!2d-97.10781620000002!3d31.619888!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x864f9d4ebc5633dd%3A0x19767ee8e2660fc2!2s324+S+Lacy+Dr%2C+Waco%2C+TX+76705%2C+USA!5e0!3m2!1sen!2sin!4v1423578941682';
    } else if (items == "crp-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3529.8075285516893!2d-97.47135910000002!3d27.784904100000002!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x866860e59b621b67%3A0xa34f432f289adbca!2s113+Gibson+Ln%2C+Corpus+Christi%2C+TX+78406%2C+USA!5e0!3m2!1sen!2sin!4v1423579008426';
    } else if (items == "elp-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3390.6468248449964!2d-106.3999923!3d31.807373899999995!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86e75a640cf257a9%3A0xce173dd8adc219ff!2s7+Leigh+Fisher+Blvd%2C+El+Paso%2C+TX+79906%2C+USA!5e0!3m2!1sen!2sin!4v1423579080114';
    } else if (items == "iah-hou-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3457.204850494096!2d-95.3120398!3d29.9447858!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8640b6b310c35781%3A0xeadc12dba96aae19!2s15550+Export+Plaza+Dr%2C+Houston%2C+TX+77032%2C+USA!5e0!3m2!1sen!2sin!4v1423579145603';
    } else if (items == "lbb-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3323.665779229149!2d-101.841224!3d33.58802599999999!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86fe132a2ede1fe3%3A0xc5f831f16b89a7d6!2s808+Avenue+E%2C+Lubbock%2C+TX+79401%2C+USA!5e0!3m2!1sen!2sin!4v1423579202763';
    } else if (items == "lrd-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3537.887403772575!2d-99.46649599999999!3d27.534956999999995!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x866121376fe0fc43%3A0xa9e17723af28e226!2s4118+Airpark+Dr%2C+Laredo+International+Airport+(LRD)%2C+Laredo%2C+TX+78041%2C+USA!5e0!3m2!1sen!2sin!4v1423579268874';
    } else if (items == "maf-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3386.1284099815716!2d-102.2112167!3d31.930270900000004!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86fbd06246ddff61%3A0xccc44672b2ee95d3!2s2701+Earhart+Dr%2C+Midland%2C+TX+79706%2C+USA!5e0!3m2!1sen!2sin!4v1423579336746';
    } else if (items == "mfe-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3580.3292387765728!2d-98.243304!3d26.185966099999998!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8665a760fe159d89%3A0x582db11ed108467e!2s2201+Uvalde+Ave%2C+McAllen%2C+TX+78503%2C+USA!5e0!3m2!1sen!2sin!4v1423741519720';
    } else if (items == "sat-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d111132.25723821657!2d-98.4930505!3d29.490609999999993!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x865cf479f16c6f05%3A0xe89f23a5bd19ed6d!2sLykes+Cartage+San+Antonio!5e0!3m2!1sen!2sin!4v1423579591578';
    } else if (items == "sps-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3308.73449953446!2d-98.56471700000002!3d33.973663!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8653269ba529f9b1%3A0x966e3b04cb629cf0!2s391+Cartwright+Rd%2C+Wichita+Falls%2C+TX+76305%2C+USA!5e0!3m2!1sen!2sin!4v1423579676481';
    } else if (items == "aus-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3443.3839943753414!2d-97.6730907!3d30.340034999999993!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8644c9a3a5e47dff%3A0x734fbe8ef84aa471!2s8606+Wall+St+%231720%2C+Austin%2C+TX+78754%2C+USA!5e0!3m2!1sen!2sin!4v1423579757603';
    } else if (items == "ama-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3259.8428170692064!2d-101.82838799999999!3d35.210384!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87014ee445a43867%3A0x887f97015831a960!2s710+SE+2nd+Ave%2C+Amarillo%2C+TX+79101%2C+USA!5e0!3m2!1sen!2sin!4v1423579822073';
    } else if (items == "bdl-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2967.844749977933!2d-72.6709245!3d41.9391873!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89e6fdcef8c38a81%3A0x745009b044ce928d!2s315+Ella+Grasso+Turnpike%2C+Windsor+Locks%2C+CT+06096%2C+USA!5e0!3m2!1sen!2sin!4v1423581569960';
    } else if (items == "bos-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2946.2723369117903!2d-71.0505257!3d42.400645499999996!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89e37109caf02d43%3A0xb5a6efd775131f35!2s401+2nd+St%2C+Everett%2C+MA+02149%2C+USA!5e0!3m2!1sen!2sin!4v1423581649419';
    } else if (items == "iad-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3101.2379115989647!2d-77.44827268511278!3d38.98706624925952!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89b638960cf55b1f%3A0x8daed97c8f8d3ae8!2s107+Executive+Dr%2C+Sterling%2C+VA+20166%2C+USA!5e0!3m2!1sen!2sin!4v1545379406480';
    } else if (items == "pwm-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2888.3633923584684!2d-70.327196!3d43.619795!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4cb2992419e427f3%3A0x7587cee2790d6002!2s75+Postal+Service+Way%2C+Scarborough%2C+ME+04074%2C+USA!5e0!3m2!1sen!2sin!4v1423581789029';
    } else if (items == "mht-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2921.7720378124027!2d-71.3627518!3d42.91984850000001!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89e252169a6e7b27%3A0x99adfd13833ae8be!2s2500+Liberty+Dr%2C+Londonderry%2C+NH+03053%2C+USA!5e0!3m2!1sen!2sin!4v1423581853988';
    } else if (items == "syr-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2913.004658180623!2d-76.08347300000001!3d43.104417!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d992b312bac9dd%3A0x64294edf0b4189cf!2s24+Corporate+Cir%2C+East+Syracuse%2C+NY+13057%2C+USA!5e0!3m2!1sen!2sin!4v1423581950845';
    } else if (items == "swf-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2986.750446187342!2d-74.13281599999999!3d41.53134599999999!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89dd295032d30077%3A0xc8103a42c6448b58!2s28+Stone+Castle+Rd%2C+Rock+Tavern%2C+NY+12575%2C+USA!5e0!3m2!1sen!2sin!4v1423582031236';
    } else if (items == "buf-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2922.5684778551304!2d-78.7369812!3d42.9030504!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d30b65ebbe8381%3A0x8d3aedb4c9bf41eb!2s3813+Broadway%2C+Buffalo%2C+NY+14227%2C+USA!5e0!3m2!1sen!2sin!4v1423582097204';
    } else if (items == "bgm-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2960.4668682468136!2d-75.823449!3d42.097471!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89dae4620f03a7f9%3A0xe00534a5dae9c2a4!2s215+Industrial+Park+Dr%2C+Binghamton%2C+NY+13904%2C+USA!5e0!3m2!1sen!2sin!4v1423582171861';
    } else if (items == "alb-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2929.697259527095!2d-73.798261!3d42.752457!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89de0d06ddb7bd4d%3A0x2132e50bafd217e3!2s12+Runway+Ave%2C+Latham%2C+NY+12110%2C+USA!5e0!3m2!1sen!2sin!4v1423582243068';
    } else if (items == "roc-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2909.621151961648!2d-77.6542946849739!3d43.175475891208855!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d6b475bd99dbb1%3A0x7f77d93afd219ad1!2s75+Norman+St%2C+Rochester%2C+NY+14613%2C+USA!5e0!3m2!1sen!2sin!4v1545380537055';
    } else if (items == "pit-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3034.095789697509!2d-80.29744149999999!3d40.495264799999994!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8834433dfd834fb5%3A0xe3e680cc5a9530e7!2s55+Matchette+Rd%2C+Clinton%2C+PA+15026%2C+USA!5e0!3m2!1sen!2sin!4v1423582595307';
    } else if (items == "phl-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3061.302071094597!2d-75.27588868508394!3d39.88986869543758!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c6c30b08b502af%3A0x23d8ac4a3cda7281!2s850+Carpenters+Crossing%2C+Folcroft%2C+PA+19032%2C+USA!5e0!3m2!1sen!2sin!4v1545383174845';
    } else if (items == "mdt-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3042.595019531833!2d-76.89080748507045!3d40.30695017023356!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c8c6c147517445%3A0x4167ed107e68c1c9!2s3500+Industrial+Rd%2C+Harrisburg%2C+PA+17110%2C+USA!5e0!3m2!1sen!2sin!4v1545380861726';
    } else if (items == "orf-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3192.1345303412986!2d-76.23385118517798!3d36.863198571851434!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89ba97b19e8add0b%3A0x4096290b8c60b8a6!2s4580+Village+Ave+Ste%23+B%2C+Norfolk%2C+VA+23502%2C+USA!5e0!3m2!1sen!2sin!4v1545381257602';
    } else if (items == "ric-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3165.249561522274!2d-77.33707728515868!3d37.50203173557823!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89b11afe615552cf%3A0x6e24b3d83bdc8ce6!2s5300+Federal+Road+%23101%2C+Richmond%2C+VA+23250%2C+USA!5e0!3m2!1sen!2sin!4v1545381415055';
    } else if (items == "btv-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d22720.09151821791!2d-73.166052!3d44.61724100000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4cca7267bb373d9d%3A0xe5f93b564bf6824f!2sNew+England+Deliveries+Inc!5e0!3m2!1sen!2sin!4v1423583788273';
    } else if (items == "mgw-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3075.25419584808!2d-79.9497822!3d39.5764211!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88357d1a78ac9a97%3A0x2018dd6a2afcba15!2s1603+Grafton+Rd%2C+Morgantown%2C+WV+26508%2C+USA!5e0!3m2!1sen!2sin!4v1423583877143';
    } else if (items == "jax-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6876.262558197506!2d-81.68272449999996!3d30.489035000000012!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88e5aeb92822c5ab%3A0xa26b80dea4375f6b!2sForward+Air+Inc!5e0!3m2!1sen!2sin!4v1423583993057';
    } else if (items == "pns-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3436.5295815977443!2d-87.3184018!3d30.534338399999996!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88909668853f751b%3A0xaf7e45d551aef1f7!2s2474+W+9+Mile+Rd%2C+Pensacola%2C+FL+32534%2C+USA!5e0!3m2!1sen!2sin!4v1423584064104';
    } else if (items == "rsw-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3568.80396573725!2d-81.75825928544178!3d26.558564881640624!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88db6ccaca80c171%3A0xb771c94d5644cd7d!2s12601+Westlinks+Dr+%235%2C+Fort+Myers%2C+FL+33913%2C+USA!5e0!3m2!1sen!2sin!4v1545381619112';
    } else if (items == "tpa-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3522.7243396131166!2d-82.528954!3d28.002328999999996!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88c2c22805b17dab%3A0xb8914ae83c9fdb68!2s5113+W+Idlewild+Ave%2C+Tampa%2C+FL+33634%2C+USA!5e0!3m2!1sen!2sin!4v1423584309474';
    } else if (items == "orl-mco-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3509.2396755564673!2d-81.349983!3d28.412024000000002!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88e77d4f9bcb2fdd%3A0xefd77eb8323d6d38!2s2487+Tradeport+Dr%2C+Orlando%2C+FL+32824%2C+USA!5e0!3m2!1sen!2sin!4v1423584395383';
    } else if (items == "sdf-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3135.9654345767926!2d-85.7565319!3d38.187477!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88690d9aab065e7b%3A0xddc59c19ccc7efcf!2sLouisville+Ave%2C+Louisville%2C+KY%2C+USA!5e0!3m2!1sen!2sin!4v1423584516895';
    } else if (items == "clt-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3260.4217314041166!2d-80.9386042!3d35.1959628!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x885698f7204724ad%3A0xf833efda26690cff!2s3301+International+Airport+Dr%2C+Charlotte%2C+NC+28208%2C+USA!5e0!3m2!1sen!2sin!4v1423584961438';
    } else if (items == "gso-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3223.187586500525!2d-79.9503263!3d36.1132874!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8853036fb7dd493b%3A0x68e481bf427d75f8!2s7609+Bentley+Rd%2C+Greensboro%2C+NC+27409%2C+USA!5e0!3m2!1sen!2sin!4v1423585053525';
    } else if (items == "rdu-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3234.283686802514!2d-78.83029619999999!3d35.8420468!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89acf1e458d3f53d%3A0x3a06a5f6712a48dd!2s409+Airport+Blvd+%23100%2C+Morrisville%2C+NC+27560%2C+USA!5e0!3m2!1sen!2sin!4v1423585128871';
    } else if (items == "avl-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3250.7458889768013!2d-82.49585768521975!3d35.43632435097281!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8859ec1387bd656f%3A0x9331f91b7ff9dd10!2s63+Fletcher+Commercial+Dr%2C+Fletcher%2C+NC+28732%2C+USA!5e0!3m2!1sen!2sin!4v1545381805854';
    } else if (items == "den-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3067.1540458848012!2d-104.8677032!3d39.7586496!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x876c7b5e0bba6f93%3A0xa139ce3a2581dfe3!2sGeneva+Ct%2C+Denver%2C+CO+80238%2C+USA!5e0!3m2!1sen!2sin!4v1423585338181';
    } else if (items == "boi-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2891.2147464449313!2d-116.19239209999999!3d43.5604082!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54aef7fb14444127%3A0xdc2f95ddb1ea2c52!2s925+W+Amity+Rd%2C+Boise%2C+ID+83705%2C+USA!5e0!3m2!1sen!2sin!4v1423585403892';
    } else if (items == "rno-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3078.268373365903!2d-119.75789329999999!3d39.508432199999994!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80993f09259f51c7%3A0xb38966367c527400!2s4965+Joule+St%2C+Reno%2C+NV+89502%2C+USA!5e0!3m2!1sen!2sin!4v1423585476308';
    } else if (items == "pdx-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2793.4234783947113!2d-122.52049500000001!3d45.561921999999996!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5495a39754d60b81%3A0x3133dc6b8c586b0d!2s13822+NE+Airport+Way%2C+Portland%2C+OR+97230%2C+USA!5e0!3m2!1sen!2sin!4v1423585555277';
    } else if (items == "slc-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3022.892695706553!2d-111.97328329999999!3d40.74238659999999!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8752f36c8a560317%3A0xee12e5ebd47b2829!2s1232+Gladiola+St%2C+Salt+Lake+City%2C+UT+84104%2C+USA!5e0!3m2!1sen!2sin!4v1423585632198';
    } else if (items == "geg-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2685.8554829340524!2d-117.19510180000002!3d47.68722650000001!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5361dfdb66e35281%3A0xd09ff2e6b9a5b010!2s3808+N+Sullivan+Rd%2C+Spokane+Valley%2C+WA+99216%2C+USA!5e0!3m2!1sen!2sin!4v1423585704252';
    } else if (items == "sea-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2700.4077140182144!2d-122.25327370000001!3d47.4039881!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54905c7428d549d5%3A0x2f16d8a3431929b0!2s22027+68th+Ave+S%2C+Kent%2C+WA+98032%2C+USA!5e0!3m2!1sen!2sin!4v1423585841523';
    } else if (items == "phx-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3330.504583131235!2d-112.037345!3d33.410087!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x872b0e2d0d0d8be9%3A0xa24cc364fa9c1c0b!2s4010+S+21st+St+%232%2C+Phoenix%2C+AZ+85040%2C+USA!5e0!3m2!1sen!2sin!4v1423585988197';
    } else if (items == "tuc-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3378.234647862143!2d-110.92717700000001!3d32.1439658!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86d67ae002a70467%3A0x105f042d17822bec!2s5990+S+Country+Club+Rd+%23150%2C+Tucson%2C+AZ+85706%2C+USA!5e0!3m2!1sen!2sin!4v1423586637684';
    } else if (items == "ols-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3407.0576231095424!2d-110.97045568533008!3d31.357389062310205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86d6ac594bdbc811%3A0x92a71ccc2f76d7ea!2s1650+W+Calle+Plata%2C+Nogales%2C+AZ+85621%2C+USA!5e0!3m2!1sen!2sin!4v1545381950751';
    } else if (items == "san-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3353.0932545305095!2d-117.1579581!3d32.816294000000006!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80dbffec479a2d89%3A0x58f96009d5614805!2s7615+Othello+Ave%2C+San+Diego%2C+CA+92111%2C+USA!5e0!3m2!1sen!2sin!4v1423586835120';
    } else if (items == "las-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3225.0770914796126!2d-115.13348439999999!3d36.0672237!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80c8cf86edc4bdd5%3A0x89694eb0f274c747!2s1410+Pama+Ln%2C+Las+Vegas%2C+NV+89119%2C+USA!5e0!3m2!1sen!2sin!4v1423586985850';
    } else if (items == "smf-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3109.8421007246816!2d-121.30599000000001!3d38.790254000000004!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x809b2180539f6b31%3A0x14f5eadc4f032e78!2s8860+Industrial+Ave+%23130%2C+Roseville%2C+CA+95678%2C+USA!5e0!3m2!1sen!2sin!4v1423587065440';
    } else if (items == "brl-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3019.7795812959075!2d-91.1433665!3d40.8108372!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87e132186e519b61%3A0xb1579c7f454521c3!2s105+S+Roosevelt+Ave%2C+West+Burlington%2C+IA+52655%2C+USA!5e0!3m2!1sen!2sin!4v1423587138257';
    } else if (items == "cid-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2968.6664775862114!2d-91.678772!3d41.921527999999995!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87e4f81c322d2e55%3A0x2b64e6b547c10656!2s733+58th+Ave+Ct+SW%2C+Cedar+Rapids%2C+IA+52404%2C+USA!5e0!3m2!1sen!2sin!4v1423587206216';
    } else if (items == "dsm-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2981.3531259978777!2d-93.5830684!3d41.6481118!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87ee9a75af5e2479%3A0x5456bd8075a43217!2s4774+NE+22nd+St%2C+Des+Moines%2C+IA+50313%2C+USA!5e0!3m2!1sen!2sin!4v1423587309400';
    } else if (items == "mli-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2990.359182809987!2d-90.532032!3d41.4531244!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87e2321b9870b2fd%3A0x1fa6ca70b497a02d!2s3003+1st+Ave+E%2C+Milan%2C+IL+61264%2C+USA!5e0!3m2!1sen!2sin!4v1423587384369';
    } else if (items == "evv-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3144.309095810002!2d-87.54349668514374!3d37.9932502073333!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8871d57fba83f193%3A0xd70963f3d047bdd0!2s1271+Maxwell+Ave%2C+Evansville%2C+IN+47711%2C+USA!5e0!3m2!1sen!2sin!4v1545382081508';
    } else if (items == "ind-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3069.368078500882!2d-86.27309799999999!3d39.708909999999996!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886ca773b8396e91%3A0x183d8f9a93cc9f60!2s6430+Airway+Dr%2C+Indianapolis%2C+IN+46241%2C+USA!5e0!3m2!1sen!2sin!4v1423587525504';
    } else if (items == "sbn-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2978.408900776783!2d-86.35046868502397!3d41.71169458379106!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88112e1ad6fbb24f%3A0xfd6784ad38836af4!2s24805+Hwy+20%2C+South+Bend%2C+IN+46628%2C+USA!5e0!3m2!1sen!2sin!4v1545382247148';
    } else if (items == "dtt-dtw-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2954.5259800519916!2d-83.32329448500658!3d42.22457475164031!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x883b48c41be7bffd%3A0x4b361417d78cb36d!2s28759+Goddard+Rd+%23200%2C+Romulus%2C+MI+48174%2C+USA!5e0!3m2!1sen!2sin!4v1545382387636';
    } else if (items == "grr-cad-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2924.38194051835!2d-85.526769!3d42.864782!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88184c1b37344117%3A0x87cab4693a2af0c9!2s5450+Kraft+Ave+SE%2C+Grand+Rapids%2C+MI+49512%2C+USA!5e0!3m2!1sen!2sin!4v1423588180238';
    } else if (items == "msp-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2828.6723784439496!2d-93.134203!3d44.848605000000006!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87f62cfec02cf73f%3A0xd484c44197748454!2s917+Lone+Oak+Rd%2C+Eagan%2C+MN+55121%2C+USA!5e0!3m2!1sen!2sin!4v1423588252775';
    } else if (items == "mci-mkc-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3086.731955884993!2d-94.71418!3d39.316998999999996!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87c05de5a4d2ecc9%3A0x63c90c7307e465e1!2s1013+Mexico+City+Ave%2C+Kansas+City+International+Airport+(MCI)%2C+Kansas+City%2C+MO+64153%2C+USA!5e0!3m2!1sen!2sin!4v1423588470727';
    } else if (items == "stl-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3111.605928249907!2d-90.3476759!3d38.7498043!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87df3691be904b6f%3A0xf6f4864175d7bd84!2s6111+James+S+McDonnell+Blvd%2C+St+Louis%2C+MO+63134%2C+USA!5e0!3m2!1sen!2sin!4v1423588544670';
    } else if (items == "jln-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3183.4740496172544!2d-94.5439698!3d37.0700149!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87c87a9214fee217%3A0x700a7aca43ce829c!2s2425+W+20th+St%2C+Joplin%2C+MO+64804%2C+USA!5e0!3m2!1sen!2sin!4v1423588609326';
    } else if (items == "oma-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2998.1350578463316!2d-95.923165!3d41.284164999999994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87938fdc498448c3%3A0x7c85b5e35b6efea5!2sBlack+Hawk+Freight!5e0!3m2!1sen!2sin!4v1423588730415';
    } else if (items == "cle-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2992.934997590373!2d-81.8368069!3d41.397217999999995!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8830ec9b90a5c0d1%3A0xceacc6bc4ca7d115!2s19300+Holland+Rd%2C+Brook+Park%2C+OH+44142%2C+USA!5e0!3m2!1sen!2sin!4v1423588820933';
    } else if (items == "cmh-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3057.7815292408036!2d-83.1021936850814!3d39.968636990693994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x883890387b6e02d5%3A0x197ee28111ee75e6!2s3616+Fisher+Rd%2C+Columbus%2C+OH+43228%2C+USA!5e0!3m2!1sen!2sin!4v1545382559600';
    } else if (items == "day-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3065.8886988764434!2d-84.1871345!3d39.7870531!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8840817d0a3654c1%3A0x4092d7048da8ac12!2s1765+Stanley+Ave%2C+Dayton%2C+OH+45404%2C+USA!5e0!3m2!1sen!2sin!4v1423589220124';
    } else if (items == "tol-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2986.61933272327!2d-83.6442637850299!3d41.534185694845526!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x883c76f08cd19789%3A0xd45308467d6ed0aa!2s26495+Southpoint+Rd%2C+Perrysburg%2C+OH+43551%2C+USA!5e0!3m2!1sen!2sin!4v1545382867959';
    } else if (items == "mdn-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2908.4064792176564!2d-89.33412299999999!3d43.20096300000001!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8806ff3adb83400b%3A0xd01e2ae83675978f!2s6512+Blanchars+Crossing%2C+Windsor%2C+WI+53598%2C+USA!5e0!3m2!1sen!2sin!4v1423589848595';
    } else if (items == "mke-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2921.0030152710833!2d-87.91225299999999!3d42.936063299999994!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8805169641faa901%3A0xef4ebdf8a375c!2s5975+S+Howell+Ave%2C+Milwaukee%2C+WI+53207%2C+USA!5e0!3m2!1sen!2sin!4v1423589651155';
    } else if (items == "jfk-lga-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3026.596084922007!2d-73.77007921430406!3d40.66083329192724!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c266937c4d8e45%3A0xc688b2a01598cd48!2s147-24+177th+St!5e0!3m2!1sen!2sin!4v1431356597227';
    } else if (items == "nyc-ewr-contact") {
        document.getElementById("maps").src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3021.5026551601113!2d-74.0858187849026!3d40.77296227932531!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c2565695fec8df%3A0xe501f77ed9eaf52f!2s900+Castle+Rd%2C+Secaucus%2C+NJ+07094!5e0!3m2!1sen!2sin!4v1487801056727';
    }
}
</script>

<script>
    /*(function (i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function () {
            (i[r].q = i[r].q || []).push(arguments)
        }, i[r].l = 1 * new Date();
        a = s.createElement(o),
            m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m)
    })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

    ga('create', 'UA-54008281-2', 'auto');
    ga('send', 'pageview');*/

</script>

</head>
<body>
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link href="source/css/sole.css" rel="stylesheet" type="text/css" visible="true"/>
    <link href="source/css/skin.css" rel="stylesheet" type="text/css" visible="true"/>

    <link
        href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800'
        rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="source/css/megadrop.css"/>
    <script type="text/javascript" src="source/js/megascripts.js"></script>
    <style>
        .searchbox {
            height: 28px;
            width: 225px;
            border: 1px solid #dadada;
            border-top-left-radius: 3px;
            border-bottom-left-radius: 3px;
            padding-left: 10px;
            font-size: 12px;
            color: #9b9b9b
        }

        .searchbutton {
            cursor: pointer;
            background-image: url('source/images/search.GIF');
            height: 30px;
            width: 70px;
            margin-top: 0;
            color: transparent
        }

        .txtSearchbox::-webkit-input-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox:-moz-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox::-moz-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox:-ms-input-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }
    </style>
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NQDLZPP');</script>
<!-- End Google Tag Manager -->
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NQDLZPP"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div id="topLine">
</div>
<div id="main-header" align="center" style="font-family: Arial;">
    <div id="main-header-area" align="left">
        <a href="index.php">
            <img src="source/images/logo-new.png" alt="Air 7 Seas" style="float: left; position: relative;"></a>

        <div class="top-small-link" style=" vertical-align: middle">
            <table border="0">
                <tr style="vertical-align: top">
                    <td style="padding-top: 3px;">
                        <a href="cargo-tracking.php" style="color: #404040; font-family: Arial;"><b>Cargo
                                Tracking</b></a>|
                        <a href="about-air7seas.php">About Us</a>|
                        <a href="https://portal.cargoez.com/air7seas/login" target="_blank">Login</a>|
                        <a href="shipping-news.php">News &amp; Events</a>

                    </td>
                    <td style="vertical-align: top;"><img src="source/images/phone-ico.PNG" alt=""
                                                          style="margin-top: 0px;">
                    </td>
                    <td style="padding: 3px 0 0 5px; width: 185px;">
                        <span style="font-size: 13pt; float: right"><span style="font-size: 9pt;">Toll Free:</span>
                        <a href="tel:+18882477732"
                           style="padding-left: 0px; padding-right: 0px; margin-right: 0px; color: #026799;"><b>1-888-247-7732<b/></a></span>
                    </td>

                </tr>
                <tr>
                    <td colspan="3" style="">
                        <div id="SrCl" style="padding-top: 8px; float: right">
                            <form method="post" action="search-results.php">

                                <input type="text" id="find" name="find" autocomplete="off"
                                       class="searchbox txtSearchbox" placeholder="How can i help you...?">
                                <input type="submit" name="" style="border:0px; height: 28px;" class="searchbutton"
                                       alt="Search"/>

                            </form>
                        </div>
                    </td>
                </tr>
            </table>


        </div>


    </div>
</div>
<div id="menu-bar" style="width: 100%; background-color: #1e6a89;" align="center">
<div style="width: 980px;" align="left">
<ul class="nav-mainmenu clearfix animated">
<li><a href="index.php">Home</a></li>
<li>
    <a href="#">Services</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px; ">

            <ul class="menu-items">
                <li class="seperator"><a href="international-freight.php" style="font-weight: 600">International
                        Freight</a></li>
                <li class="seperator"><a href="domestic-freight.php">Domestic Freight</a></li>
                <li class="seperator"><a href="freight-forwarder.php">Freight Forwarding</a></li>
                <li class="seperator"><a href="freight-consultation.php">Consultation</a></li>

            </ul>
        </div>
    </div>
</li>
<li><a href="#">Products</a>

    <div class="container-2" style="width: 500px;">
        <table border="0">
            <tr>
                <td style="border-right:1px solid #ccc; vertical-align: top;">
                    <div class="col1" style="width: 250px;">

                        <ul class="menu-items">


                            <li class="seperator"><a href="shipping-to-vietnam.php"><img
                                        src="source/images/Vietnam-Flag-icon.png" alt="Vietnam Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Saigon Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-india.php"><img
                                        src="source/images/India-Flag-icon.png" alt="India Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">India Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-middle-east.php"><img
                                        src="source/images/MiddleEast-Flag-icon.png" alt="Shipping to Middle East"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Middle East Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-china.php"><img
                                        src="source/images/China-Flag-icon.png" alt="China Shipper"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">China Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-philippines.php"><img
                                        src="source/images/Philippines-Flag-icon.png" alt="Philippines Shipper"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Manila Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-spain.php"><img
                                        src="source/images/Spain-Flag-icon.png" alt="Spain Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Spain Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-mexico.php"><img
                                        src="source/images/Mexico-Flag-icon.png" alt="Mexico Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Mexico Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="autos-to-canada.php"><img
                                        src="source/images/Canada-Flag-icon.png" alt="Canada Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Autos to Canada</span></a>
                            </li>
  <li class="seperator"><a href="importers-logistics-rep.php">Importer&#39;s Rep</a></li>

                        </ul>
                    </div>
                </td>
                <td style="vertical-align: top;">
                    <div class="col1" style="width: 250px;">

                        <ul class="menu-items">
                            <li class="seperator"><a href="shipping-to-africa.php">
                                    <img src="source/images/Africa-Flag-icon.png" alt="AfriCargo Express" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">AfriCargo Express</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-latin-america.php">
                                    <img src="source/images/Latino-Flag-icon.png" alt="Latino Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Latino Shipper</span></a>
                            </li>
                              <li class="seperator"><a href="nvo.php">
                                    <img src="source/images/lcl-icon.jpg" alt="Latino Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Cargo-Coloader LCL</span></a>
                            </li>
                            <li class="seperator"><a href="a7s-pre-fulfilment-service.php"><img src="source/images/receiving-center-icon.png"
                                                                                      alt="Air7seas Pre-Fulfillment Service" width="22px"
                                                                                      style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Pre-Fulfillment &amp; Delivery </span></a></li>
                            <li class="seperator"><a href="receiving-center.php"><img src="source/images/receiving-center-icon.png"
                                                                                      alt="Mexico Shipper" width="22px"
                                                                                      style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Pre-Shipping Receiving Center</span></a></li>
                            <!--<li class="seperator"><a href="receiving-center.php">Receiving Center</a></li>-->
                            <li class="seperator"><a href="partners-agents.php"><img
                                        src="source/images/partners-agents-icon.png" alt="Canada Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Partners - Agents</span></a>
                            </li>
                            <li class="seperator"><a href="autos-vehicles-machinery.php"><img
                                        src="source/images/autos-vehicle-mechinery-icon.png" alt="Mexico Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Autos Vehicles Machinery</span></a>
                            </li>
                            <li class="seperator"><a href="transloading-transhipment.php">Transloading -
                                    Transhipment</a></li>
                            <li class="seperator"><a href="ship-hazardous-perishable-goods.php">Hazardous &amp;
                                    Perishable</a></li>


                        </ul>
                    </div>
                </td>
            </tr>
        </table>


    </div>
</li>
<li><a href="#">Mover &amp; Relocation</a>

    <div class="container-4" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="move-household-goods.php">Household Goods</a></li>
                <li class="seperator"><a href="ship-commercial-goods.php">Commercial Goods</a></li>
                <!--     <li class="seperator"><a href="#">Countries served</a></li> -->
            </ul>
        </div>
    </div>
</li>
<li><a href="#">Freight Carrier</a>

    <div class="container-4" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="air-freight-carrier.php">Air Freight Carrier</a></li>
                <li class="seperator"><a href="ocean-freight-carrier.php">Ocean Freight Carrier</a>
                </li>
                <li class="seperator"><a href="soc-movements.php">SOC Movements</a></li>
            </ul>
        </div>
    </div>
</li>
<li>
    <a href="#">Customs Release</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="export-import.php"">Export - Import</a></li>
                <li class="seperator"><a href="isf.php">ISF / AMS</a></li>
                <li class="seperator"><a href="importers-logistics-rep.php">Importer&#39;s Rep</a></li>
            </ul>
        </div>
    </div>
</li>

<li><a href="#">Insurance</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="cargo-insurance-coverage-types.php">Coverage Types</a></li>
                <li class="seperator"><a href="free-estimate-insurance.php">Free Estimate - Insurance</a>
                </li>
                <li class="seperator"><a href="order-online-insurance.php">Order Online - Insurance</a></li>
                <li class="seperator"><a href="claim-submission.php">Claim submission Form</a></li>
                <li class="seperator"><a href="faq-insurance.php">FAQ</a></li>
                <!--<li class="seperator"><a href="#">Resources - Insurance</a></li>-->
                <li class="seperator"><a href="damages-to-the-goods-by-customs.php">Damages to the goods by
                        Customs</a></li>

            </ul>
        </div>
    </div>
</li>
<li><a href="#">Contact Us</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="contact-us.php">Contacts</a></li>
                <li class="seperator"><a href="free-estimatesdetails.php">Get an Estimate</a></li>
                <li class="seperator"><a href="ordernowdetails.php">Book a Shipment</a></li>
                <li class="seperator"><a href="feedback.php">Feedback</a></li>
                <li class="seperator"><a href="complaint.php">Complaint</a></li>
                <li class="seperator"><a href="customer-review.php">Testimonial</a></li>
                <li class="seperator"><a href="claim-submission.php">Claim submission</a></li>
                <li class="seperator"><a href="terms-and-conditions.php">Terms &amp; Conditions</a></li>
                <li class="seperator"><a href="jobs.php">Jobs</a></li>
            </ul>
        </div>
    </div>
</li>
<li><a href="#" class="last-list">Tools &amp; Resources</a>

    <div class="container-1 right" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="forms-downloads.php">Documents &amp; Forms</a></li>
                <li class="seperator"><a href="payments.php">Payment options</a></li>
                <li class="seperator"><a href="moving-tips.php">Moving Tips</a></li>
                <li class="seperator"><a href="container-sizes.php">Container Sizes for Sea</a></li>
                <li class="seperator"><a href="faq.php">FAQs</a></li>
                <li class="seperator"><a href="shipping-news.php">News &amp; Events</a></li>
                <li class="seperator"><a href="ask-a-question.php">Ask a question</a></li>
            </ul>
        </div>
    </div>
</li>

</ul>
</div>

</div>
<div id="info-bar" style="box-shadow: 0px 3px 3px 0px rgba(0, 0, 0, 0.15); position: relative; z-index: 100;"
     align="center">
    <div id="info-bar-area" align="left">
        <div class="top-thin-links">
            <div class="thin-links-wrapper">
                <a class="review" href="free-estimatesdetails.php"><span class="icon"></span><span>Free Shipping Estimate</span></a>
                <a class="finance" href="estimate-sizeof-shipment.php"><span
                        class="icon"></span><span>Moving Calculator</span></a>
                <a class="facebook" href="moving-tips.php"><span class="icon"></span><span>Moving Tips</span></a>
                <a class="catalogue" href="ordernowdetails.php"><span class="icon"></span><span>Order Online</span></a>
                <a class="trade-account" href="ask-a-question.php"><span class="icon"></span><span>Shipping ?</span></a>
            </div>
        </div>
    </div>
</div>

</body>
</html>

<form id="frmContact" class="frmAS" method="post" action="contact-us.php">
<div id="contents" align="center">
<div id="contentsArea" align="left">

<div class="col span_12_of_12"
     style="width: 100%; position: relative;  vertical-align: top; padding: 20px 20px 40px 40px; background-color: #ffffff;"
     align="left">

<div id="loader" style="display: none; margin-top: 20px;">
    <img src="source/images/gif-loader.GIF" style="margin-top: 20%;">
</div>

<div id="frmDisplay">

<h1 style="font-size: 18pt; font-family: 'open sans'; color: #026799; margin-bottom: 10px; font-weight: 700;"> Contact
    Us</h1>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<table style="width: 100%; padding-right: 20px;">
<tr>
<td style=" width: 50%; padding-left: 12px; vertical-align: top;">
    <table border="0" style="padding-top: 15px; padding-left: 0px; font-size: 11pt;">
        <tr>
            <td class="form-label" style="width: 130px;">Subject</td>
            <td class="form-label" align="left">:&nbsp;
                <select class="form-textbox" id="comment_on" name="comment_on" style="font-size: 11pt; width: 230px;">
                                                <option value="Information">Information</option>
                                                    <option value="Complaint">Complaint</option>
                                                    <option value="Feedback">Feedback</option>
                                                    <option value="Suggestion">Suggestion</option>
                                                    <option value="Appreciation">Appreciation</option>
                                        </select>
            </td>
        </tr>
        <tr>
            <td class="form-label">Name *</td>
            <td class="form-label" align="left">:&nbsp;
                <input type="text" id="name" name="name" class="form-textbox" required value=""
                       style="font-size: 11pt; width: 230px;">
            </td>
        </tr>
        <tr>
            <td class="form-label">Company</td>
            <td class="form-label" align="left">:&nbsp;&nbsp;
                <span>http://www.</span><input type="text" id="company" name="company" class="form-textbox"
                                               style="width: 148px; font-size: 11pt;" value="">
            </td>
        </tr>
        <tr>
            <td class="form-label">Email *</td>
            <td class="form-label" align="left">:&nbsp; <input type="email" id="email" name="email" required
                                                               class="form-textbox"
                                                               style="font-size: 11pt; width: 230px;"
                                                               value="">
            </td>
        </tr>
        <tr>
            <td class="form-label">Phone No *</td>
            <td class="form-label" align="left">:&nbsp;
                <input type="tel" id="phone" name="phone" class="form-textbox"
                       style="margin-left: 5px; width: 230px; font-size: 11pt;" required/>
                <input type="hidden" id="mob_no" name="mob_no">
            </td>
        </tr>
        <tr>
            <td class="form-label" style="">Message<span style="float: right; margin-right: -7px;">:</span></td>
            <td class="form-label" align="left">
                <textarea id="comments" name="comments" class="form-textbox"
                          style="min-height: 50px; max-height: 50px; min-width: 230px; max-width: 230px; margin-left: 18px; font-size: 11pt;"></textarea>
            </td>
        </tr>
        <tr>
            <td class="form-label">Are You ?</td>
            <td class="form-label" align="left">:&nbsp;
                <select name="customer_type" id="customer_type" class="form-textbox"
                        style="width: 230px; font-size: 11pt;">
                    <option selected>Select One</option>
                                                <option value="Manufacturer">Manufacturer</option>
                                                    <option value="Supplier/Vendor">Supplier/Vendor</option>
                                                    <option value="Exporter /Importer">Exporter /Importer</option>
                                                    <option value="Distributor">Distributor</option>
                                                    <option value="Trader">Trader</option>
                                                    <option value="Forwarder/Cargo Agent">Forwarder/Cargo Agent</option>
                                                    <option value="Shipper">Shipper</option>
                                        </select>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="height: 10px;"></td>
        </tr>
        <tr>
            <td class="form-label" style="position: absolute; margin-top: 5px;">Security Code<span
                    style="float: right; margin-left: 51px;">:</span></td>
            <td class="form-label">
                <input type="text" maxlength="6" name="captcha" class="form-textbox" autocomplete="off"
                       id="captcha" style="position: absolute; width: 80px; margin-left: 15px; font-size: 11pt;">
                <img src="get_captcha.php" alt="" id="captcha_cv"
                     style="border: 1px solid #c6c6c6; margin-left: 100px;"/>
                <img src="source/images/refresh.png" alt="" id="refreshimg" name="refreshimg"
                     style="cursor: pointer;"
                     title="Click to refresh image" onclick="change_captcha()"><br>
                <span id="codeInfo_cv"></span>
            </td>
        </tr>
        <tr>
            <td></td>
            <td style="padding-top: 10px; padding-left: 15px;">
                <input type="submit" id="send_mail" name="send_mail" class="naviBlue"
                       value="Submit" style="font-size: 11pt; width: 130px">&nbsp;
            </td>
        </tr>
    </table>
</td>
<td style="width: 50%;padding-left: 30px; padding-top: 23px; vertical-align: top;">
<a href="contactlist.php" class="resource-link" style="font-weight: bold; font-size: 15pt;">Departments &amp;
    Contacts</a><br><br>

<div style="font-size: 10pt; line-height: 23px;">


    <h2 style="font-size: 13pt; font-family: 'open sans'; color: #555555; margin-bottom: 10px; font-weight: 600;">
        Corporate Office -</h2>


    <div style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px;">
        <a href="https://goo.gl/maps/m3c18"
           target="_blank" class="resource-link">
            <span style=" font-size: 13pt; font-weight: 600;">AIR 7 SEAS Transport Logistics, Inc.<br></span>
            1815 Houret Court, Milpitas, CA 95035 USA</a><br style="line-height: 25px;">

        <a href="tel:+18882477732">
            <img src="source/images/phone.png" style="position: absolute; margin-top: 3px;" alt=""
                 width="23px"/></a><span style="margin-left: 15px;">Toll Free: <a
                href="tel:+18882477732" class="resource-link">888-AIR7SEAS (888-247-7732)</span></a>
        <br>

        </a>

        <a href="tel:+14089578787" style="padding-left: 20px;color: #666666; ">Int'l Phone: <a
                href="tel:+14089578787" class="resource-link">+1-408-957-8787</a>
            <br>

        </a>

        <img src="source/images/fax_ico.png" style="position: absolute; margin-top: 3px;" alt="" width="20px"/><span
            style="margin-left: 20px;">Fax: 1-888-A7S2FAX (888-277-2329)</span><br>
    </div>
    <hr style="margin: 10px 0px;">
</div>

<div style="font-size: 10pt; line-height: 23px;  display: inline">
<h2 style="font-size: 13pt; font-family: 'open sans'; display: inline; color: #555555; margin-bottom: 5px;  font-weight: 600;">
    Depot Locations : </h2>

<select id="contactAddress"
        style="padding: 3px 7px; margin-bottom: 5px; width: 150px; border: 1px solid #e4e4e4; font-size:13pt; color:#444444;"
        onchange="contactList(this.value);">
    <option value="abi-contact">ABI</option>
    <option value="abq-contact">ABQ</option>
    <option value="act-contact">ACT</option>
    <option value="alb-contact">ALB</option>
    <option value="ama-contact">AMA</option>
    <option value="atl-contact">ATL</option>
    <option value="aus-contact">AUS</option>
    <option value="avl-contact">AVL</option>
    <option value="bdl-contact">BDL</option>
    <option value="bgm-contact">BGM</option>
    <option value="bhm-contact">BHM</option>
    <option value="bna-contact">BNA</option>
    <option value="boi-contact">BOI</option>
    <option value="bos-contact">BOS</option>
    <option value="brl-contact">BRL</option>
    <option value="btr-contact">BTR</option>
    <option value="btr-lft-contact">BTR LFT</option>
    <option value="btv-contact">BTV</option>
    <option value="buf-contact">BUF</option>
    <option value="bwi-contact">BWI</option>
    <option value="chs-contact">CHS</option>
    <option value="cid-contact">CID</option>
    <option value="cle-contact">CLE</option>
    <option value="clt-contact">CLT</option>
    <option value="cmh-contact">CMH</option>
    <option value="crp-contact">CRP</option>
    <option value="cvg-contact">CVG</option>
    <option value="day-contact">DAY</option>
    <option value="den-contact">DEN</option>
    <option value="dfw-contact">DFW</option>
    <option value="dsm-contact">DSM</option>
    <option value="dtt-dtw-contact">DTT DTW</option>
    <option value="elp-contact">ELP</option>
    <option value="evv-contact">EVV</option>
    <option value="geg-contact">GEG</option>
    <option value="grr-cad-contact">GRR CAD</option>
    <option value="gso-contact">GSO</option>
    <option value="gsp-contact">GSP</option>
    <option value="hsv-contact">HSV</option>
    <option value="iad-contact">IAD</option>
    <option value="iah-hou-contact">IAH HOU</option>
    <option value="ind-contact">IND</option>
    <option value="jax-contact">JAX</option>
    <option value="jfk-lga-contact">JFK LGA</option>
    <option value="jln-contact">JLN</option>
    <option value="las-contact">LAS</option>
    <option value="lax-lgb-ont-contact">LAX LGB ONT</option>
    <option value="lbb-contact">LBB</option>
    <option value="lit-contact">LIT</option>
    <option value="lrd-contact">LRD</option>
    <option value="maf-contact">MAF</option>
    <option value="mci-mkc-contact">MCI MKC</option>
    <option value="mdn-contact">MDN</option>
    <option value="mdt-contact">MDT</option>
    <option value="mem-contact">MEM</option>
    <option value="mfe-contact">MFE</option>
    <option value="mgm-contact">MGM</option>
    <option value="mgw-contact">MGW</option>
    <option value="mht-contact">MHT</option>
    <option value="mia-contact">MIA</option>
    <option value="mke-contact">MKE</option>
    <option value="mli-contact">MLI</option>
    <option value="mob-contact">MOB</option>
    <option value="msp-contact">MSP</option>
    <option value="msy-contact">MSY</option>
    <option value="nyc-ewr-contact">NYC EWR</option>
    <option value="okc-contact">OKC</option>
    <option value="ols-contact">OLS</option>
    <option value="oma-contact">OMA</option>
    <option value="ord-chi-contact">ORD CHI MDW</option>
    <option value="orf-contact">ORF</option>
    <option value="orl-mco-contact">ORL MCO</option>
    <option value="pdx-contact">PDX</option>
    <option value="phl-contact">PHL</option>
    <option value="phx-contact">PHX</option>
    <option value="pit-contact">PIT</option>
    <option value="pns-contact">PNS</option>
    <option value="pwm-contact">PWM</option>
    <option value="rdu-contact">RDU</option>
    <option value="ric-contact">RIC</option>
    <option value="rno-contact">RNO</option>
    <option value="roc-contact">ROC</option>
    <option value="rsw-contact">RSW</option>
    <option value="san-contact">SAN</option>
    <option value="sat-contact">SAT</option>
    <option value="sbn-contact">SBN</option>
    <option value="sdf-contact">SDF</option>
    <option value="sea-contact">SEA</option>
    <option value="sfo-oak-sjc-contact">SFO OAK SJC</option>
    <option value="shv-contact">SHV</option>
    <option value="slc-contact">SLC</option>
    <option value="smf-contact">SMF</option>
    <option value="sps-contact">SPS</option>
    <option value="stl-contact">STL</option>
    <option value="swf-contact">SWF</option>
    <option value="syr-contact">SYR</option>
    <option value="tol-contact">TOL</option>
    <option value="top-contact">TOP</option>
    <option value="tpa-contact">TPA</option>
    <option value="tri-contact">TRI</option>
    <option value="tuc-contact">TUC</option>
    <option value="tul-contact">TUL</option>
    <option value="tys-contact">TYS</option>
</select>


<div id="abi-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: block;">
    141 G Tannehill, Abilene, TX 79602 USA<br>
    <a href="tel:+13256958110"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+13256958110" class="resource-link">1-325-695-8110</a>
</div>
<div id="abq-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    2400 Alamo Ave. SE, Albuquerque, NM 87106 USA<br>
    <a href="tel:+15057645995"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+15057645995" class="resource-link">1-505-764-5995</a>
</div>
<div id="lax-lgb-ont-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    2665 East Del Amo Blvd, Rancho Dominguez, CA 90221<br>
    <a href="tel:+13104967301"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+13104967301" class="resource-link">1-310-496-7301</a>
    <span style="float: right; margin-right: 20px;">E-Mail: <a href="mailto:saleslax@air7seas.us" class="resource-link">SalesLAX
            (@) air7seas.us</a></span>
</div>
<div id="dfw-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    1061 Texan Trail, Suite 100,
    Grapevine TX 76051 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
    <span style="float: right; margin-right: 20px;">E-Mail: <a href="mailto:salesdfw1@air7seas.us"
                                                               class="resource-link">SalesDFW1 (@)
            air7seas.us</a></span>
</div>
<div id="nyc-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    369 Washington Ave, Unit 7,
    Carlstadt, NJ 07072 USA<br>
    <a href="tel:+18772477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18772477732" class="resource-link">1-877-247-7732</a>
    <span style="float: right; margin-right: 20px;">E-Mail: <a href="mailto:salesnyc@air7seas.us" class="resource-link">SalesNYC
            (@) air7seas.us</a></span>
</div>
<div id="atl-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    560 Atlanta South Pkwy, Ste# 600, Atlanta, GA 30349 USA <br>
    <a href="tel:+18005247732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18005247732" class="resource-link">1-800-524-7732</a>
    <span style="float: right; margin-right: 20px;">E-Mail: <a href="mailto:salesatl1@air7seas.us"
                                                               class="resource-link">SalesATL1 (@)
            air7seas.us</a></span>
</div>
<div id="ord-chi-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    814 Wood Dale Rd, Wood Dale, IL 60191 USA<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
    <span style="float: right; margin-right: 20px;">E-Mail: <a href="mailto:saleschi1@air7seas.us"
                                                               class="resource-link">SalesCHI1 (@)
            air7seas.us</a></span>
</div>
<div id="iad-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    107-A Executive Dr.,Dulles, VA 20166 USA<br>
    <a href="tel:+18772477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18772477732" class="resource-link">1-877-247-7732</a>
</div>
<div id="mia-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    2275 E. 11th Ave, Hialeah, FL 33013 USA<br>
    <a href="tel:+18778637667"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18778637667" class="resource-link">1-877-863-7667</a>
    <span style="float: right; margin-right: 20px;">E-Mail: <a href="mailto:salesmia@air7seas.us" class="resource-link">SalesMIA
            (@) air7seas.us</a></span>
</div>
<div id="sfo-oak-sjc-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    1815 Houret Court, Milpitas, CA 95035 USA<br>
    <a href="tel:+14089578787"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+14089578787" class="resource-link">1-408-957-8787</a>
</div>
<div id="bhm-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    1531 Red Hollow Road, Birmingham, AL 35215 USA<br>
    <a href="tel:+12055919400"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+12055919400" class="resource-link">1-205-591-9400</a>
</div>
<div id="hsv-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    9310 Madison Blvd, Ste# 1, Huntsville, AL 35758 USA<br>
    <a href="tel:+18005247732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18005247732" class="resource-link">1-800-524-7732</a>
</div>
<div id="mgm-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    2541 Midpark Dr, Montgomery, AL 36109 USA<br>
    <a href="tel:+18005247732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18005247732" class="resource-link">1-800-524-7732</a>
</div>
<div id="mob-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    2215 Avenue O, Mobile, AL 36615 USA<br>
    <a href="tel:+12516534880"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+12516534880" class="resource-link">1-251-653-4880</a>
</div>
<div id="cvg-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    1810 Airport Exchange Blvd, Ste# 100, Erlanger, <br>KY 41018 USA<br>
    <a href="tel:+18005247732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18005247732" class="resource-link">1-800-524-7732</a>
</div>
<div id="chs-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    3074 Ashley Phosphate Rd, North Charleston, SC 29418 USA<br>
    <a href="tel:+18005247732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18005247732" class="resource-link">1-800-524-7732</a>
</div>
<div id="gsp-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    12 Runion Rd, Bldg 2, Greer, SC 29651 USA<br>
    <a href="tel:+18005247732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18005247732" class="resource-link">1-800-524-7732</a>
</div>
<div id="bna-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    541 Harding Industrial Dr, Nashville, TN 37217 USA<br>
    <a href="tel:+18005247732"><img src="source/images/phone.png" width=""/></a>Tel: <a
        href="tel:+18005247732" class="resource-link">1-800-524-7732</a>
</div>
<div id="mem-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    3861 Knight Rd, Memphis, TN 38118 USA<br>
    <a href="tel:+18005247732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18005247732" class="resource-link">1-800-524-7732</a>
</div>
<div id="tri-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    873 Centenary Rd, Blountville, TN 37617 USA<br>
    <a href="tel:+18005247732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18005247732" class="resource-link">1-800-524-7732</a>
</div>
<div id="tys-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    3267 North Park Blvd, Bldg 10, Ste# V, Alcoa, TN 37701 USA<br>
    <a href="tel:+18653801515"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18653801515" class="resource-link">1-865-380-1515</a>
</div>
<div id="tys-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    3267 North Park Blvd, Bldg 10, Ste# E, Alcoa, TN 37701 USA<br>
    <a href="tel:+18653801515"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18653801515" class="resource-link">1-865-380-1515</a>
</div>
<div id="lit-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    2323 E. Roosevelt, Little Rock, AR 72206 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
</div>
<div id="top-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    4631 S.E. Adams, Topeka, KS 66609 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
</div>
<div id="btr-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    11337 Cedar Park Ave, Baton Rouge, LA 70878 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
</div>
<div id="btr-lft-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    1441 B. Highway 93 N, Scott, LA 70583 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
</div>
<div id="shv-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    209 Kansas City Ave, Shreveport, LA 71107 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
</div>
<div id="msy-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    200 Crofton Rd, Bldg# 7A, Ste# 500, Kenner, LA 70062 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
</div>
<div id="okc-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    1905 E. Skyline Dr, Oklahoma City, OK 73129 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
</div>
<div id="tul-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    1533 N. Garnett Road, Tulsa, OK 74116 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
</div>

<div id="act-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    324 S. Lacy Dr, Waco, TX 76705 USA<br>
    <a href="tel:+12547992509"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+12547992509" class="resource-link">1-254-799-2509</a>
</div>
<div id="crp-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    113 Gibson Ln, Corpus Christi, TX 78406 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
</div>
<div id="elp-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    7 Leigh Fisher, El Paso, TX 79906 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
</div>
<div id="iah-hou-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    15550 Export Plaza Dr, Houston, TX 77032 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
</div>
<div id="lbb-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    808 Ave E, Lubbock, TX 79401 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
</div>
<div id="lrd-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    4118 Airpark Dr, Laredo, TX 78041 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
</div>
<div id="maf-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    2701 Earhard Dr, Midland, TX 79706 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
</div>
<div id="mfe-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    2201 Uvalde Ave Bay 8, McAllen, TX 78503 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
</div>
<div id="sat-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    4534 Macro Drive, Bldg 2, San Antonio, TX 78218 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
</div>
<div id="sps-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    391 Cartwright Rd, Wichita Falls, TX 76305 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
</div>
<div id="aus-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    8606 Wall St, Ste# 1720, Austin, TX 78754 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
</div>
<div id="ama-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    710 SE 2nd St, Amarillo, TX 79101 USA<br>
    <a href="tel:+18662477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18662477732" class="resource-link">1-866-247-7732</a>
</div>
<div id="bdl-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    315 Ella Grasso Turnpike, Windsor Locks, CT 06096 USA<br>
    <a href="tel:+18772477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18772477732" class="resource-link">1-877-247-7732</a>
</div>
<div id="bos-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    401 Second St, Everett, MA 02149 USA<br>
    <a href="tel:+18772477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18772477732" class="resource-link">1-877-247-7732</a>
</div>
<div id="bwi-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    1901 Park 100 Drive, Suite 102, Glen Burnie, MD 21061 USA<br>
    <a href="tel:+18772477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18772477732" class="resource-link">1-877-247-7732</a>
</div>
<div id="pwm-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    75 Postal Service Way, Scarborough, ME 04070 USA<br>
    <a href="tel:+18772477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18772477732" class="resource-link">1-877-247-7732</a>
</div>
<div id="mht-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    2500 Liberty Dr, Londonderry, NH 03053 USA<br>
    <a href="tel:+18772477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18772477732" class="resource-link">1-877-247-7732</a>
</div>
<div id="syr-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    24 Corporate Circle, Syracuse, NY 13057 USA<br>
    <a href="tel:+18772477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18772477732" class="resource-link">1-877-247-7732</a>
</div>
<div id="swf-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    28 Stone Castle Rd, Rock Tavern, NY 12575 USA<br>
    <a href="tel:+18772477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18772477732" class="resource-link">1-877-247-7732</a>
</div>
<div id="buf-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    3813 Broadway, Buffalo, NY 14227 USA<br>
    <a href="tel:+18772477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18772477732" class="resource-link">1-877-247-7732</a>
</div>
<div id="bgm-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    215-C Industrial Park Drive, Binghamton, NY 13904 USA<br>
    <a href="tel:+18772477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18772477732" class="resource-link">1-877-247-7732</a>
</div>
<div id="alb-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    12 Runway Aveune, Latham, NY 12110 USA<br>
    <a href="tel:+18772477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18772477732" class="resource-link">1-877-247-7732</a>
</div>
<div id="roc-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    75 Norman St, Rochester, NY 14613 USA<br>
    <a href="tel:+15854582190"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+15854582190" class="resource-link">1-585-458-2190</a>
</div>
<div id="pit-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    55 Matchette Rd, Cliton, PA 15026 USA<br>
    <a href="tel:+18772477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18772477732" class="resource-link">1-877-247-7732</a>
</div>
<div id="phl-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    850 Carpenters Crossing, Folcroft, PA 19032<br>
    <a href="tel:+18772477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18772477732" class="resource-link">1-877-247-7732</a>
</div>
<div id="mdt-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    3500 Industrial Rd, Harrisburg, PA 17110 USA<br>
    <a href="tel:+18772477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18772477732" class="resource-link">1-877-247-7732</a>
</div>
<div id="orf-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    4580 Village Ave, Ste# B, Norfolk, VA 23502 USA<br>
    <a href="tel:+18772477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18772477732" class="resource-link">1-877-247-7732</a>
</div>
<div id="ric-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    5300 Federal Rd, Ste# 101, Richmond, VA 23250 USA<br>
    <a href="tel:+18772477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18772477732" class="resource-link">1-877-247-7732</a>
</div>
<div id="btv-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    24 Clapper Road, Milton, VT 05468 USA<br>
    <a href="tel:+18772477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18772477732" class="resource-link">1-877-247-7732</a>
</div>
<div id="mgw-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    1603 Grafton Road, Morgantown, WV 26508 USA<br>
    <a href="tel:+18772477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18772477732" class="resource-link">1-877-247-7732</a>
</div>
<div id="jax-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    14200 Pecan Park Rd, Cargo Bldg 4, Jacksonville, <br>FL 32218 USA<br>
    <a href="tel:+18778637667"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18778637667" class="resource-link">1-877-863-7667</a>
</div>
<div id="pns-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    2474 West Nine Mile Rd, Pensacola, FL 32534 USA<br>
    <a href="tel:+18778637667"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18778637667" class="resource-link">1-877-863-7667</a>
</div>
<div id="rsw-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    12601 Westlinks Dr, Unit 5, Fort Myers, FL 33913 USA<br>
    <a href="tel:+12396902697"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+12396902697" class="resource-link">1-239-690-2697</a>
</div>
<div id="tpa-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    5113 W Idlewild Ave, Tampa, FL 33634 USA<br>
    <a href="tel:+18778637667"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18778637667" class="resource-link">1-877-863-7667</a>
</div>
<div id="orl-mco-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    2487 Tradeport Dr, Orlando, FL 32824 USA<br>
    <a href="tel:+18778637667"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18778637667" class="resource-link">1-877-863-7667</a>
</div>
<div id="sdf-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    464 Louisville Ave, Louisville, KY 40213 USA<br>
    <a href="tel:+18778637667"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18778637667" class="resource-link">1-877-863-7667</a>
</div>
<div id="clt-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    3301 International Airport Rd, Charlotte, NC 28208 USA<br>
    <a href="tel:+18778637667"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18778637667" class="resource-link">1-877-863-7667</a>
</div>
<div id="gso-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    7609 Bentley Rd, Greensboro, NC 27409 USA<br>
    <a href="tel:+18778637667"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18778637667" class="resource-link">1-877-863-7667</a>
</div>
<div id="rdu-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    409-B Airport Blvd, Ste# 100, Morrisville, NC 27560 USA<br>
    <a href="tel:+18778637667"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18778637667" class="resource-link">1-877-863-7667</a>
</div>
<div id="avl-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    63 Fletcher Commercial Dr, Fletcher, NC 28732 USA<br>
    <a href="tel:+18778637667"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18778637667" class="resource-link">1-877-863-7667</a>
</div>
<div id="den-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    555 Geneva St Stapleton Business Ctr# 8, Denver, <br>CO 80238 USA<br>
    <a href="tel:+18882477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18882477732" class="resource-link">1-888-247-7732</a>
</div>
<div id="boi-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    925 West Amity Road, Boise, ID 83705 USA<br>
    <a href="tel:+18882477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18882477732" class="resource-link">1-888-247-7732</a>
</div>
<div id="rno-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    4965 Joule St, Reno, NV 89502 USA<br>
    <a href="tel:+18882477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18882477732" class="resource-link">1-888-247-7732</a>
</div>
<div id="pdx-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    13822 N.E. Airport Way, Portland, OR 97230 USA<br>
    <a href="tel:+18882477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18882477732" class="resource-link">1-888-247-7732</a>
</div>
<div id="slc-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    1232 South Gladiola, Salt Lake City, UT 84104 USA<br>
    <a href="tel:+18882477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18882477732" class="resource-link">1-888-247-7732</a>
</div>
<div id="geg-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    3808 North Sullivan Road, Bldg 13, Spokane, WA 99216 USA<br>
    <a href="tel:+18882477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18882477732" class="resource-link">1-888-247-7732</a>
</div>
<div id="sea-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    22027 68th Ave Str, Bldg 4, Kent, WA 98032 USA<br>
    <a href="tel:+18882477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18882477732" class="resource-link">1-888-247-7732</a>
</div>
<div id="phx-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    4010 South 21st Street Ste#2, Phoenix, AZ 85040 USA<br>
    <a href="tel:+18887447277"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18887447277" class="resource-link">1-888-744-7277</a>
</div>
<div id="tuc-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    5990 South Country Club Rd, Ste# 150, Tuscon, <br>AZ 85706 USA<br>
    <a href="tel:+18887447277"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18887447277" class="resource-link">1-888-744-7277</a>
</div>
<div id="ols-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    1650 W Calle Plat, Nogales, AZ 85621 USA<br>
    <a href="tel:+18887447277"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18887447277" class="resource-link">1-888-744-7277</a>
</div>
<div id="san-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    7615 Othello Avenue, San Diego, CA 92111 USA<br>
    <a href="tel:+18887447277"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18887447277" class="resource-link">1-888-744-7277</a>
</div>

<div id="las-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    1410 Pama Lane, Las Vegas, NV 89119 USA<br>
    <a href="tel:+18887447277"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18887447277" class="resource-link">1-888-744-7277</a>
</div>
<div id="smf-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    8860 Industrial Ave, Suite 130, Roseville, CA 95678 USA<br>
    <a href="tel:+18882477732"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18882477732" class="resource-link">1-888-247-7732</a>
</div>
<div id="brl-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    105 S. Roosevelt Ave, Burlington, IA 52601 USA<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
</div>
<div id="cid-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    733 58th Ave Court SW, Cedar Rapids, IA 52404 USA<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
</div>
<div id="dsm-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    4774 NE 22nd St, Des Moines, IA 50313 USA<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
</div>
<div id="mli-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    3003 1st Ave East, Milan, IL 61264 USA<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
</div>
<div id="evv-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    1271 Maxwell Ave, Evansville, IL 47711 USA<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
</div>
<div id="ind-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    6430 Airway Drive, Indianapolis, IN 46241 USA<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
</div>
<div id="sbn-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    24805 US 20 West, South Bend, IN 46628 USA<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
</div>
<div id="dtt-dtw-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    28759 Goddard Rd. Suite 200,Romulus, MI 48174<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
</div>
<div id="grr-cad-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    5450 Kraft Ave SE, Grand Rapids, MI 49512 USA<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
</div>
<div id="msp-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    917 Lone Oak Road, Eagon, MN 55120 USA<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
</div>
<div id="mci-mkc-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    1013 Mexico City Ave, Kansas City, MO 64153 USA<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
</div>
<div id="stl-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    6111 James S. McDonnell Blvd, St. Louis, MO 63134 USA<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
</div>
<div id="jln-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    2425 W 20TH, Joplin, MO 64804 USA<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
</div>
<div id="oma-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    2732 North 5th St, Carter Lake, NB 51510 USA<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
</div>
<div id="cle-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    19300 Holland Road, Brook Park, OH 44142 USA<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
</div>
<div id="cmh-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    3616 Fisher Road, Columbus, OH 43228 USA<br>
    <a href="tel:+16143510400"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+16143510400" class="resource-link">1-614-351-0400</a>
</div>
<div id="day-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    1765 Stanley Ave, Dayton, OH 45404 USA<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
</div>
<div id="tol-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    26495 South Point Road, Perrysburg, OH 43551 USA<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
</div>
<div id="mdn-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    6512 Blanchar&#39;s Crossing, Windsor, WI 53598 USA<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
</div>
<div id="mke-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    5975 S. Howell Ave, Milwaukee, WI 53207 USA<br>
    <a href="tel:+18667447494"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+18667447494" class="resource-link">1-866-744-7494</a>
</div>
<div id="jfk-lga-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    147-24 177th St, Jamaica, NY 11434 USA<br>
    <a href="tel:+17188742911"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+17188742911" class="resource-link">1-718-874-2911</a>
</div>
<div id="nyc-ewr-contact"
     style="width: 100%; font-size: 11pt; color: #727272; padding-left: 0px; padding-bottom: 10px; display: none;">
    900 Castle Road, Secaucus, NJ 07094<br>
    <a href="tel:+17328531170"><img src="source/images/phone.png" alt="" width=""/></a>Tel: <a
        href="tel:+17328531170" class="resource-link">1-732-853-1170</a>
    <span style="float: right; margin-right: 20px;">E-Mail: <a href="mailto:Salesnyc@air7seas.us" class="resource-link">
            SalesNYC (@) air7seas.us</a></span>
</div>

</div>

</td>
</tr>
<tr>
    <td colspan="2">
        <iframe id="maps"
                src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3368.879854908879!2d-99.72170080000001!3d32.3955822!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x86569278896e6c2f%3A0xbaa23741c8681015!2s141+Tannehill+Dr%2C+Abilene%2C+TX+79602%2C+USA!5e0!3m2!1sen!2sin!4v1423578826476"
                width="900px" height="300" frameborder="0"
                style="display: block; border: 1px solid #DDDDDD; margin-top: 10px;"></iframe>
    </td>
</tr>
</table>
</div>
</div>
<!--<div style="width: 100%;" align="center">-->
<!--<div style="width: 100%; margin: 10px 0px;" align="center">

</div>-->
</div>
</div>
<script src="source/js/tel/intlTelInput.js"></script>
<script src="source/js/tel/utils.js"></script>
<script>
    /*$("#phone").intlTelInput({
     nationalMode: true,
     utilsScript: "source/js/tel/utils.js"
     });*/

    var input = $("#phone"),
        output = $("#output");

    input.intlTelInput({
        nationalMode: true,
        utilsScript: "../../lib/libphonenumber/build/utils.js" // just for formatting/placeholders etc
    });

    input.keyup(function () {
        var intlNumber = input.intlTelInput("getNumber");
        if (intlNumber) {
            //output.text("International: " + intlNumber);
            document.getElementById('mob_no').value = intlNumber;
        } else {
            output.text("Please enter a number below");
        }
    });

</script>
</form>
<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" lang="en">


<head>
    <!--Start of Zopim Live Chat Script
    <script type="text/javascript">
        window.$zopim || (function (d, s) {
            var z = $zopim = function (c) {
                z._.push(c)
            }, $ = z.s =
                d.createElement(s), e = d.getElementsByTagName(s)[0];
            z.set = function (o) {
                z.set.
                    _.push(o)
            };
            z._ = [];
            z.set._ = [];
            $.async = !0;
            $.setAttribute('charset', 'utf-8');
            $.src = '//v2.zopim.com/?2NBKvMLseKA8C45Gr5ywmelLErtAkht6';
            z.t = +new Date;
            $.
                type = 'text/javascript';
            e.parentNode.insertBefore($, e)
        })(document, 'script');
    </script>
    End of Zopim Live Chat Script-->
    
    <!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = '3kWxTfUv3x';var d=document;var w=window;function l(){
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
<!-- {/literal} END JIVOSITE CODE -->

    <link href="source/css/sole.css" rel="stylesheet">

<body class="vpform pgTrustPilot" lang="en-GB" align="center">


<div id="footerinfo" style="width: 100%; background-color: #cccccc" align="center">
    <div style="width: 980px; background-color: #ffffff; padding: 10px 0px;" align="left">
        <div id="BreadcrumbWrapper">
            <div class="section group">
                <div class="col span_12_of_12" style="line-height: 23px; border-right: 1px solid #dddddd; ">
                </div>
            </div>
            <hr>
        </div>
        <img src="source/images/logos.jpg" alt="" style="width: 980px;">
        <div style="margin-left:40px;">
            <a id="bbblink" class="ruvtbum" target="_blank" href="https://www.bbb.org/us/ca/milpitas/profile/logistics/air-7-seas-transport-logistics-1216-213698#bbbseal"
        title="AIR 7 SEAS Transport Logistics Inc, Logistics, Milpitas, CA"
        style="display: block;position: relative;overflow: hidden; width: 60px; height: 108px; margin: 0">
        <img style="padding: 0px; border: none;" id="bbblinkimg" src="https://seal-sanjose.bbb.org/logo/ruvtbum/air-7-seas-transport-logistics-213698.png" width="120" height="108" alt="AIR 7 SEAS Transport Logistics Inc, Logistics, Milpitas, CA" />
        </a>    
        </div>
        
        <script type="text/javascript">var bbbprotocol = ( ("https:" == document.location.protocol) ? "https://" : "http://" ); (function(){var s=document.createElement('script');s.src=bbbprotocol + 'seal-sanjose.bbb.org' + unescape('%2Flogo%2Fair-7-seas-transport-logistics-213698.js');s.type='text/javascript';s.async=true;var st=document.getElementsByTagName('script');st=st[st.length-1];var pt=st.parentNode;pt.insertBefore(s,pt.nextSibling);})();
        </script>
    </div>
</div>
<!--footer-->
<footer style="background-color: #4d4d4d">
    <div class="DB MMdLFtR">
        <div class="FL DB MMdLFtRa" style="padding-left: 75px;">

            <div id="FtR" class="LH20 footer-links">
                <div class="left-section FL">
                    <div class="left-wrapper FL">
                        <section class="ordering-fromus">
                            <div class="title">
                                AIR 7 SEAS
                            </div>
                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="about-air7seas.php" id="aContact">About Us</a>
                                    <a href="feedback.php" id="aFAQ">Feedback</a>
                                    <a href="shipping-news.php" id="aOrdertracking">News &amp;
                                        Events</a>
                                    <a href="#">Privacy Policy</a>
                                    <a href="terms-and-conditions.php">Terms &amp;
                                        Conditions</a>
                                    <a href="jobs.php">Jobs</a>
                                </li>
                            </ul>
                        </section>
                        <section class="help-support">
                            <div class="title">
                                SERVICES
                            </div>

                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="international-freight.php">International &#45;
                                        Freight</a>
                                    <a href="domestic-freight.php">Domestic &#45;
                                        Freight</a>
                                    <a href="autos-vehicles-machinery.php">Machinery &amp; Vehicles</a>
                                    <a href="freight-forwarder.php">Freight Forwarding</a>
                                    <a href="customs-release.php">Customs Release</a>
                                    <a href="moving.php">Movers</a>
                                </li>
                            </ul>
                        </section>
                        <section class="information">
                            <div class="title">
                                SUPPORT
                            </div>
                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="faq.php">Frequently Asked Questions</a>
                                    <a href="moving-tips.php">Moving Tips</a>

                                    <a href="payments.php" id="aFreeRecycle">Payment Options</a>
                                    <a href="procedural-steps-for-claim-submition.php">Claim
                                        Submission Procedures</a>
                                    <a href="isf.php">Importer Security Filing (ISF)</a>
                                    <a href="order-online-insurance.php">Order Online -
                                        Insurance</a>

                                </li>
                            </ul>
                        </section>
                    </div>
                    <div class="social-links">


                    </div>
                </div>
                <section class="newsletter">
                    <div class="title">CORPORATE OFFICE</div>
                    <div class="footer-contact">
                        <ul>
                            <li class="f-map"><a
                                    href="contact-us.php"
                                    target="_blank">1815 Houret Court, <br> Milpitas, CA 95035, US</a></li>
                            <li class="f-phone"><span><a href="tel:+18882477732">Call Us: 1-888-247-7732</a></span></li>
                            <li class="f-mail"><a href="mailto:info@air7seas.us">info (@) air7seas.us</a></li>
                        </ul>
                    </div>
                    <br><br>

                    <div>
                        <a href="https://www.facebook.com/pages/Air7Seas-Transport-Logistics-Inc/731149066945233" target="_blank">
                            <img src="source/images/icons/fb.png" style="margin-top: 7px; width: 25px;">
                        </a>&nbsp;
                        <a href="https://twitter.com/Air7seas" target="_blank">
                            <img src="source/images/icons/twitter.png" style="margin-top: 7px; width: 25px;">
                        </a>&nbsp;
                        <a href="https://www.google.com/maps/place/AIR+7+SEAS+Transport+Logistics+Inc/@37.405497,-121.8994427,17z/data=!3m1!4b1!4m5!3m4!1s0x808fceb215c020c3:0x183384c4fb534d3c!8m2!3d37.405497!4d-121.897254" target="_blank">
                            <img src="source/images/icons/gp.png" style="margin-top: 7px; width: 25px;">
                        </a>
                    </div>

                </section>
            </div>
        </div>
    </div>

</footer>

<div class="baseline-footer">
    <div class="baseline-footer-wrapper">
        <section class="FL" itemprop="provider" itemscope itemtype="http://schema.org/Organization">
            <div class="FL">

                <meta itemprop="url" content="http://www.air7seas.com/"/>
                <meta itemprop="name" content="Air 7 Seas Transport Logistics Pvt Ltd"/>
                <meta itemprop="email" content="info@air7seas.com "/>
                <div itemprop="location" itemscope itemtype="http://www.schema.org/LocalBusiness">

                    <meta itemprop="openingHours" content="Mo-Fr 08:00-16:00"/>
                    <meta itemprop="openingHours" content="Sa-Su Holiday"/>
                    <div itemprop="geo" itemscope itemtype="http://schema.org/GeoCoordinates">
                        <meta itemprop="latitude" content="53.55519"/>
                        <meta itemprop="longitude" content="-3.041651"/>
                    </div>
                </div>

            </div>
            <div class="contact-information">
                <div id="pnlUKFooter">

                    <div class="address" itemprop=address itemscope itemtype=http://schema.org/PostalAddress>
                        <span class="address-image"></span>

                        <div class="address-wrapper">
                            <span itemprop=streetAddress><a href="contact-us.php" style="color: #cfcfcf;">1815 Houret
                                    Court,<br> Milpitas, CA 95035</a></span>,
                            <span itemprop=addressLocality>USA</span>
                        </div>
                    </div>
                    <div class="phone-number">
                        <span class="phone-image"></span>
                        <span class="telephone" itemprop=telephone><a href="tel:+18882477732" style="color: #cfcfcf;">1-888-247-7732</a></span>
                        <span class="sales-support">(Customer Support)</span>
                    </div>
                    <div class="email-address">
                        <span class="email-img"></span>
                        <span itemprop=email><a class="mail-id"
                                                href="mailto:info@air7seas.us">info (@) air7seas.us</a></span>
                    </div>


                </div>

            </div>
        </section>


        <div itemprop="copyrightHolder" itemscope itemtype="http://www.schema.org/Organization"
             class="copywrite-holder">
            <meta itemprop="url" content="http://www.air7seas.com/"/>
            <meta itemprop="name" content="Air 7 Seas Transport Logistics Pvt Ltd"/>

            <meta itemprop="email" content="info@air7seas.com "/>

            Copyright <span class="copyrights">&copy;</span> AIR 7 SEAS 2014 &#45; 2015
        </div>
        <meta itemprop="copyrightYear" content="1986-2014"/>

        <div class="divAuthorisedText">Authorised and regulated by AIR 7 SEAS 95035</div>


    </div>
</div>

</body>
</html>

<script>
    document.getElementById('footerinfo').style.display = 'none';
</script>
</body>
</html>