<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
    <title>NVOCC - Insurance - AIR 7 SEAS</title>
    <link
        href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800'
        rel='stylesheet' type='text/css'>
    <link rel="shortcut icon" href="source/images/a7s-icon.ico"/>
    <meta charset="utf-8"/>
    <meta name="description"
          content="Air 7 seas is leading Freight Forwarder, NVOCC, OTI, Cargo Consolidator, Custom Broker, Carrier, and Shipping Agents for Ship Lines, Airlines, Truckers, Shipper & Consignee to handle International and Domestic transportation by Air Freight, Sea Freight or Road Freight.">
    <meta name="description"
          content="Air 7 Seas Overseas Relocation, Air 7 Seas Moving Overseas, Air 7 Seas Relocation Services, Air 7 Seas Shipping India, Air 7 Seas Shipping USA, Air 7 Seas Freight Forwarder, Air 7 Seas Air Freight, Air 7 Seas Air Cargo, Air 7 Seas Customs Clearance, Air 7 Seas International Shipping Companies, Air 7 Seas Moving Estimate, Air 7 Seas Shipping Quote, Air 7 Seas Moving International, Air 7 Seas Domestic Movers, Air 7 Seas Shipping Agent, Air 7 Seas Shipping International, Air 7 Seas International Moving Service, Air 7 Seas Cargo Agent, Air 7 Seas Customs Broker, Air 7 Seas International Mover, Air 7 Seas Household Goods, Air 7 Seas Commercial Goods, Air 7 Seas Breakbulk Cargo, Air 7 Seas Car Shipping, Air 7 Seas Motorbike Shipping, Air 7 Seas Auto Vehicle Mechinery, Air 7 Seas Cargo Consolidation, Air 7 Seas Freight Service Provider">
    <meta name="keywords"
          content="Overseas Relocation, Moving Overseas, Relocation Services, Shipping India, Shipping USA, Freight Forwarder, Air Freight, Air Cargo, Customs Clearance, International Shipping Companies, Moving Estimate, Shipping Quote, Moving International, Domestic Movers, Shipping Agent, Shipping International, International Moving Service, Cargo Agent, Customs Broker, International Mover, Household Goods, Commercial Goods, Breakbulk Cargo, Car Shipping, Motorbike Shipping, Auto Vehicle Mechinery, Cargo Consolidation, Freight Service Provider">
    <meta name="author" content="Air 7 Seas Transport Logistics Pvt Ltd">
    <!--  <base href="http://www.air7seas.com/"> -->

    <link href="source/css/sole.css" rel="stylesheet" type="text/css" visible="true"/>
    <link href="source/css/skin.css" rel="stylesheet" type="text/css" visible="true"/>
    <link href="source/css/controls.css" rel="stylesheet" type="text/css" visible="true"/>
    <script src="source/js/script.js"></script>

    <!--     DATE CALANDER     -->


    <!--        COUNTRY CODE         -->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <link href="source/css/tel/intlTelInput.css" rel="stylesheet">

    <!--        MODAL POPUP     -->

    <script src="source/modal-popup/jquery-1.4.3.min.js" type="text/javascript"></script>
    <link rel="stylesheet" href="source/css/modal-popup.css"/>

    <link rel="stylesheet" type="text/css" href="source/css/jquery.datetimepicker.css"/>
    <script src="source/js/jquery-1.11.1.js"></script>
    <script src="source/js/jquery.validate.js"></script>
    <script>
        $().ready(function () {

            $('#refreshimg').click(function () {
                $.post("newsession.php");
                $("#captchaimage").load("image_req.php");
                return false;
            });

            $("#frmNVO").validate({
                rules: {
                    frm_city: "required",
                    frm_state: "required",
                    from_country: "required",
                    frm_zip: "required",
                    transport_mode: "required",
                    name: "required",
                    phone: "required",
                    email: "required",
                    find_us: "required",
                    captcha: "required"
                },
                messages: {
                    frm_city: "",
                    frm_state: "",
                    from_country: "",
                    frm_zip: "",
                    transport_mode: "",
                    name: "",
                    phone: "",
                    email: "",
                    find_us: "",
                    captcha: " "
                }
            });
        });

        function change_captcha() {
            document.getElementById('captcha_cv').src = "get_captcha.php?rnd=" + Math.random();
        }

        function change_commodity(value) {
            //commodity
            //txt_commodity
            if (value == 'If Others') {
                document.getElementById('commodity').style.display = 'none';
                document.getElementById('txt_commodity').style.display = 'block';
                document.getElementById('show_list').style.display = 'block';
            } else {
                document.getElementById('commodity').style.display = 'block';
                document.getElementById('txt_commodity').style.display = 'none';
                document.getElementById('show_list').style.display = 'none';
            }

            if (value == '1') {
                document.getElementById('commodity').selectedIndex = 0;
            }
        }

        function Focus_frm_city(){
            document.getElementById('frm_city').focus();
        }

    </script>
    
    <!-- Global site tag (gtag.js) - Google Ads: 881822992 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-881822992"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-881822992');
</script>

    
    <!-- Event snippet for Conversion Rate for Ocean Freight conversion page -->
<script>
  gtag('event', 'conversion', {'send_to': 'AW-881822992/McLZCMiJlGoQkJq-pAM'});
</script>


    <script>
        /*(function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function () {
                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

        ga('create', 'UA-54008281-2', 'auto');
        ga('send', 'pageview');*/

    </script>

    <style>
        #captcha.success {
            border: 1px solid #49c24f;
            background: #bcffbf;
        }

        #captcha.error {
            border: 1px solid #c24949;
            background: #ffbcbc;
        }

        #loader {
            height: 95%;
            width: 110%;
            position: absolute;
            background-color: #ffffff;
            z-index: 2147483647 !important;
            opacity: 0.8;
            overflow: hidden;
            text-align: center;
            top: 0;
            left: 0;

        }
    </style>

    <script type="text/javascript">

        $(document).ready(function () {


            //MODAL POPUP OPEN OPERATION


            $("#lcl-cargo-receiving-location").on('change', function (){
                var port = $(this).val();
                var val_1 = "#"+port;
                ShowDialog(true, val_1);
                e.preventDefault();
            });

            //MODAL POPUP CLOSE OPERATION

            $("#close_atlanta").click(function (e) {
                var val_1 = "#atlanta";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_bostan").click(function (e) {
                var val_1 = "#bostan";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_baltimore").click(function (e) {
                var val_1 = "#baltimore";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_chicago").click(function (e) {
                var val_1 = "#chicago";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_dallas").click(function (e) {
                var val_1 = "#dallas";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_houston").click(function (e) {
                var val_1 = "#houston";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_los_angeles").click(function (e) {
                var val_1 = "#los_angeles";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_miami").click(function (e) {
                var val_1 = "#miami";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_norfolk").click(function (e) {
                var val_1 = "#norfolk";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_new_york").click(function (e) {
                var val_1 = "#new_york";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_new_orleans").click(function (e) {
                var val_1 = "#new_orleans";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_oakland").click(function (e) {
                var val_1 = "#oakland";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_portland").click(function (e) {
                var val_1 = "#portland";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_seattle").click(function (e) {
                var val_1 = "#seattle";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_philadelphia").click(function (e) {
                var val_1 = "#philadelphia";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_memphis").click(function (e) {
                var val_1 = "#memphis";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_detroit").click(function (e) {
                var val_1 = "#detroit";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_columbus").click(function (e) {
                var val_1 = "#columbus";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_cleveland").click(function (e) {
                var val_1 = "#cleveland";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_charleston").click(function (e) {
                var val_1 = "#charleston";
                HideDialog(val_1);
                e.preventDefault();
            });
            $("#close_charlotte").click(function (e) {
                var val_1 = "#charlotte";
                HideDialog(val_1);
                e.preventDefault();
            });
        });

        function ShowDialog(modal, value) {
            var val_1 = value;
            $("#overlay").show();
            $(val_1).fadeIn(300);

            if (modal) {
                $("#overlay").unbind("click");
            }
            else {
                $("#overlay").click(function (e) {
                    HideDialog(val_1);
                });
            }
        }

        function HideDialog(value) {
            $("#overlay").hide();
            $(value).fadeOut(300);
        }

    </script>


    <script type="text/javascript">
        function refresh_captcha() {

            document.getElementById('captcha').src = "CaptchaSecurityImages.php";
        }
    </script>
    <style>
        body {
            margin: 0px;
            padding: 0px;
        }

        #cc:hover {
            text-decoration: underline;
        }
    </style>
    <script type="text/javascript">

        function Enable_insurance(value) {
            if (value == "Yes") {
                document.getElementById('insurance_amt').disabled = false;
            } else {
                document.getElementById('insurance_amt').disabled = true;
            }
        }

        function Enable_phone(value) {
            if (value == "Select") {
                document.getElementById('phone').disabled = true;
            } else {
                document.getElementById('phone').disabled = false;
            }
        }

    </script>
    <script type="text/javascript">
        function selectCity(country_id) {
            if (country_id != "-1") {
                loadData('from_near', country_id);
                $("#from_near_port").html("<option value='-1'>Select One Near You</option>");
            }
        }

        function loadData(loadType, loadId) {
            var dataString = 'loadType=' + loadType + '&loadId=' + loadId;
            $("#" + loadType + "_loader").show();
            $("#" + loadType + "_loader").fadeIn(400).
            html('<img src="source/images/loading.gif" />');
            $.ajax({
                type: "POST",
                url: "source/actions/fetch-from-port.php",
                data: dataString,
                cache: false,
                success: function (result) {
                    $("#" + loadType + "_loader").hide();
                    if (loadType == 'from_near') {
                        $("#" + loadType + "_port").html("<option value='-1'>Select One Near You</option>");
                    }
                    else {
                        $("#" + loadType + "_port").html("<option value='-1'>Select " + loadType + "</option>");
                    }
                    $("#" + loadType + "_port").append(result);
                }
            });
        }
    </script>
    <script type="text/javascript">
        function selectCity1(country_id) {
            if (country_id != "-1") {
                loadData1('to_near', country_id);
                $("#to_near_port").html("<option value='-1'>Select One Near You</option>");
            }
        }

        function loadData1(loadType, loadId) {
            var dataString = 'loadType=' + loadType + '&loadId=' + loadId;
            $("#" + loadType + "_loader").show();
            $("#" + loadType + "_loader").fadeIn(400).
            html('<img src="source/images/loading.gif" />');
            $.ajax({
                type: "POST",
                url: "source/actions/fetch-to-port.php",
                data: dataString,
                cache: false,
                success: function (result) {
                    $("#" + loadType + "_loader").hide();
                    if (loadType == 'to_near') {
                        $("#" + loadType + "_port").html("<option value='-1'>Select One Near You</option>");
                    } else {
                        $("#" + loadType + "_port").html("<option value='-1'>Select " + loadType + "</option>");
                    }
                    $("#" + loadType + "_port").append(result);
                }
            });
        }
    </script>


</head>
<body onload="selectCity('US'); selectCity1(''); Focus_frm_city()">
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link href="source/css/sole.css" rel="stylesheet" type="text/css" visible="true"/>
    <link href="source/css/skin.css" rel="stylesheet" type="text/css" visible="true"/>

    <link
        href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800'
        rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="source/css/megadrop.css"/>
    <script type="text/javascript" src="source/js/megascripts.js"></script>
    <style>
        .searchbox {
            height: 28px;
            width: 236px;
            border: 1px solid #dadada;
            border-top-left-radius: 3px;
            border-bottom-left-radius: 3px;
            padding-left: 10px;
            font-size: 12px;
            color: #9b9b9b
        }

        .searchbutton {
            cursor: pointer;
            background-image: url('source/images/search.GIF');
            height: 30px;
            width: 70px;
            margin-top: 0;
            color: transparent
        }

        .txtSearchbox::-webkit-input-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox:-moz-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox::-moz-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox:-ms-input-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }
    </style>
</head>
<body>
<div id="topLine">
</div>
<div id="main-header" align="center" style="font-family: Arial;">
    <div id="main-header-area" align="left">
        <a href="index.php">
            <img src="source/images/logo-new.png" alt="Air 7 Seas" style="float: left; position: relative;"></a>

        <div class="top-small-link" style=" vertical-align: middle">
            <table border="0">
                <tr style="vertical-align: top">
                    <td style="padding-top: 3px;">
                        <a href="cargo-tracking.php" style="color: #404040; font-family: Arial;"><b>Cargo
                                Tracking</b></a>|
                        <a href="about-air7seas.php">About Us</a>|
                        <a href="#">Login</a>|
                        <a href="shipping-news.php">News &amp; Events</a>

                    </td>
                    <td style="vertical-align: top;"><img src="source/images/phone-ico.PNG" alt=""
                                                          style="margin-top: 0px;">
                    </td>
                    <td style="padding: 3px 0 0 5px; width: 185px;">
                        <span style="font-size: 13pt; float: right"><span style="font-size: 9pt;">Toll Free:</span>
                        <a href="tel:+18882477732"
                           style="padding-left: 0px; padding-right: 0px; margin-right: 0px; color: #026799;"><b>1-888-247-7732<b/></a></span>
                    </td>

                </tr>
                <tr>
                    <td colspan="3" style="">
                        <div id="SrCl" style="padding-top: 8px; float: right">
                            <form method="post" action="search-results.php">

                                <input type="text" id="find" name="find" autocomplete="off"
                                       class="searchbox txtSearchbox" placeholder="How can i help you...?">
                                <input type="submit" name="" style="border:0px; height: 28px;" class="searchbutton"
                                       alt="Search"/>

                            </form>
                        </div>
                    </td>
                </tr>
            </table>


        </div>


    </div>
</div>
<div id="menu-bar" style="width: 100%; background-color: #1e6a89;" align="center">
    <div style="width: 980px;" align="left">
        <ul class="nav-mainmenu clearfix animated">
            <li><a href="index.php">Home</a></li>
            <li>
                <a href="#">Services</a>

                <div class="container-1" style="width: 230px;">
                    <div class="col1" style="width: 230px; ">

                        <ul class="menu-items">
                            <li class="seperator"><a href="international-freight.php" style="font-weight: 600">International
                                    Freight</a></li>
                            <li class="seperator"><a href="domestic-freight.php">Domestic Freight</a></li>
                            <li class="seperator"><a href="freight-forwarder.php">Freight Forwarding</a></li>
                            <li class="seperator"><a href="freight-consultation.php">Consultation</a></li>

                        </ul>
                    </div>
                </div>
            </li>
            <li><a href="#">Products</a>

                <div class="container-2" style="width: 500px;">
                    <table border="0">
                        <tr>
                            <td style="border-right:1px solid #ccc; vertical-align: top;">
                                <div class="col1" style="width: 250px;">

                                    <ul class="menu-items">


                                        <li class="seperator"><a href="shipping-to-vietnam.php"><img
                                                    src="source/images/Vietnam-Flag-icon.png" alt="Vietnam Shipper" width="22px"
                                                    style="position: absolute; margin-top: 1px;"><span
                                                    style="margin-left: 33px;">Saigon Shipper</span></a>
                                        </li>
                                        <li class="seperator"><a href="shipping-to-india.php"><img
                                                    src="source/images/India-Flag-icon.png" alt="India Shipper" width="22px"
                                                    style="position: absolute; margin-top: 1px;"><span
                                                    style="margin-left: 33px;">India Shipper</span></a>
                                        </li>
                                        <li class="seperator"><a href="shipping-to-middle-east.php"><img
                                                    src="source/images/MiddleEast-Flag-icon.png" alt="Shipping to Middle East"
                                                    width="22px"
                                                    style="position: absolute; margin-top: 1px;"><span
                                                    style="margin-left: 33px;">Middle East Shipper</span></a>
                                        </li>
                                        <li class="seperator"><a href="shipping-to-china.php"><img
                                                    src="source/images/China-Flag-icon.png" alt="China Shipper"
                                                    width="22px"
                                                    style="position: absolute; margin-top: 1px;"><span
                                                    style="margin-left: 33px;">China Shipper</span></a>
                                        </li>
                                        <li class="seperator"><a href="shipping-to-philippines.php"><img
                                                    src="source/images/Philippines-Flag-icon.png" alt="Philippines Shipper"
                                                    width="22px"
                                                    style="position: absolute; margin-top: 1px;"><span
                                                    style="margin-left: 33px;">Manila Shipper</span></a>
                                        </li>
                                        <li class="seperator"><a href="shipping-to-spain.php"><img
                                                    src="source/images/Spain-Flag-icon.png" alt="Spain Shipper" width="22px"
                                                    style="position: absolute; margin-top: 1px;"><span
                                                    style="margin-left: 33px;">Spain Shipper</span></a>
                                        </li>
                                        <li class="seperator"><a href="shipping-to-mexico.php"><img
                                                    src="source/images/Mexico-Flag-icon.png" alt="Mexico Shipper" width="22px"
                                                    style="position: absolute; margin-top: 1px;"><span
                                                    style="margin-left: 33px;">Mexico Shipper</span></a>
                                        </li>
                                        <li class="seperator"><a href="autos-to-canada.php"><img
                                                    src="source/images/Canada-Flag-icon.png" alt="Canada Shipper" width="22px"
                                                    style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Autos to Canada</span></a>
                                        </li>
                                        <li class="seperator"><a href="importers-logistics-rep.php">Importer&#39;s Rep</a></li>

                                    </ul>
                                </div>
                            </td>
                            <td style="vertical-align: top;">
                                <div class="col1" style="width: 250px;">

                                    <ul class="menu-items">
                                        <li class="seperator"><a href="shipping-to-africa.php">
                                                <img src="source/images/Africa-Flag-icon.png" alt="AfriCargo Express" width="22px"
                                                     style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">AfriCargo Express</span></a>
                                        </li>
                                        <li class="seperator"><a href="shipping-to-latin-america.php">
                                                <img src="source/images/Latino-Flag-icon.png" alt="Latino Shipper" width="22px"
                                                     style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Latino Shipper</span></a>
                                        </li>
                                        <li class="seperator"><a href="nvo.php">
                                                <img src="source/images/lcl-icon.jpg" alt="Latino Shipper" width="22px"
                                                     style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Cargo-Coloader LCL</span></a>
                                        </li>
                                        <li class="seperator"><a href="a7s-pre-fulfilment-service.php"><img src="source/images/receiving-center-icon.png"
                                                                                                            alt="Air7seas Pre-Fulfillment Service" width="22px"
                                                                                                            style="position: absolute; margin-top: 1px;"><span
                                                    style="margin-left: 33px;">Pre-Fulfillment &amp; Delivery </span></a></li>
                                        <li class="seperator"><a href="receiving-center.php"><img src="source/images/receiving-center-icon.png"
                                                                                                  alt="Mexico Shipper" width="22px"
                                                                                                  style="position: absolute; margin-top: 1px;"><span
                                                    style="margin-left: 33px;">Pre-Shipping Receiving Center</span></a></li>
                                        <!--<li class="seperator"><a href="receiving-center.php">Receiving Center</a></li>-->
                                        <li class="seperator"><a href="partners-agents.php"><img
                                                    src="source/images/partners-agents-icon.png" alt="Canada Shipper" width="22px"
                                                    style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Partners - Agents</span></a>
                                        </li>
                                        <li class="seperator"><a href="autos-vehicles-machinery.php"><img
                                                    src="source/images/autos-vehicle-mechinery-icon.png" alt="Mexico Shipper" width="22px"
                                                    style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Autos Vehicles Machinery</span></a>
                                        </li>
                                        <li class="seperator"><a href="transloading-transhipment.php">Transloading -
                                                Transhipment</a></li>
                                        <li class="seperator"><a href="ship-hazardous-perishable-goods.php">Hazardous &amp;
                                                Perishable</a></li>


                                    </ul>
                                </div>
                            </td>
                        </tr>
                    </table>


                </div>
            </li>
            <li><a href="#">Mover &amp; Relocation</a>

                <div class="container-4" style="width: 230px;">
                    <div class="col1" style="width: 230px;">

                        <ul class="menu-items">
                            <li class="seperator"><a href="move-household-goods.php">Household Goods</a></li>
                            <li class="seperator"><a href="ship-commercial-goods.php">Commercial Goods</a></li>
                            <!--     <li class="seperator"><a href="#">Countries served</a></li> -->
                        </ul>
                    </div>
                </div>
            </li>
            <li><a href="#">Freight Carrier</a>

                <div class="container-4" style="width: 230px;">
                    <div class="col1" style="width: 230px;">

                        <ul class="menu-items">
                            <li class="seperator"><a href="air-freight-carrier.php">Air Freight Carrier</a></li>
                            <li class="seperator"><a href="ocean-freight-carrier.php">Ocean Freight Carrier</a>
                            </li>
                            <li class="seperator"><a href="soc-movements.php">SOC Movements</a></li>
                        </ul>
                    </div>
                </div>
            </li>
            <li>
                <a href="#">Customs Release</a>

                <div class="container-1" style="width: 230px;">
                    <div class="col1" style="width: 230px;">

                        <ul class="menu-items">
                            <li class="seperator"><a href="export-import.php"">Export - Import</a></li>
                            <li class="seperator"><a href="isf.php">ISF / AMS</a></li>
                            <li class="seperator"><a href="importers-logistics-rep.php">Importer&#39;s Rep</a></li>
                        </ul>
                    </div>
                </div>
            </li>

            <li><a href="#">Insurance</a>

                <div class="container-1" style="width: 230px;">
                    <div class="col1" style="width: 230px;">

                        <ul class="menu-items">
                            <li class="seperator"><a href="cargo-insurance-coverage-types.php">Coverage Types</a></li>
                            <li class="seperator"><a href="free-estimate-insurance.php">Free Estimate - Insurance</a>
                            </li>
                            <li class="seperator"><a href="order-online-insurance.php">Order Online - Insurance</a></li>
                            <li class="seperator"><a href="claim-submission.php">Claim submission Form</a></li>
                            <li class="seperator"><a href="faq-insurance.php">FAQ</a></li>
                            <!--<li class="seperator"><a href="#">Resources - Insurance</a></li>-->
                            <li class="seperator"><a href="damages-to-the-goods-by-customs.php">Damages to the goods by
                                    Customs</a></li>

                        </ul>
                    </div>
                </div>
            </li>
            <li><a href="#">Contact Us</a>

                <div class="container-1" style="width: 230px;">
                    <div class="col1" style="width: 230px;">

                        <ul class="menu-items">
                            <li class="seperator"><a href="contact-us.php">Contacts</a></li>
                            <li class="seperator"><a href="free-estimatesdetails.php">Get an Estimate</a></li>
                            <li class="seperator"><a href="ordernowdetails.php">Book a Shipment</a></li>
                            <li class="seperator"><a href="feedback.php">Feedback</a></li>
                            <li class="seperator"><a href="complaint.php">Complaint</a></li>
                            <li class="seperator"><a href="customer-review.php">Testimonial</a></li>
                            <li class="seperator"><a href="claim-submission.php">Claim submission</a></li>
                            <li class="seperator"><a href="terms-and-conditions.php">Terms &amp; Conditions</a></li>
                            <li class="seperator"><a href="jobs.php">Jobs</a></li>
                        </ul>
                    </div>
                </div>
            </li>
            <li><a href="#" class="last-list">Tools &amp; Resources</a>

                <div class="container-1 right" style="width: 230px;">
                    <div class="col1" style="width: 230px;">

                        <ul class="menu-items">
                            <li class="seperator"><a href="forms-downloads.php">Documents &amp; Forms</a></li>
                            <li class="seperator"><a href="payments.php">Payment options</a></li>
                            <li class="seperator"><a href="moving-tips.php">Moving Tips</a></li>
                            <li class="seperator"><a href="container-sizes.php">Container Sizes for Sea</a></li>
                            <li class="seperator"><a href="faq.php">FAQs</a></li>
                            <li class="seperator"><a href="shipping-news.php">News &amp; Events</a></li>
                            <li class="seperator"><a href="ask-a-question.php">Ask a question</a></li>
                        </ul>
                    </div>
                </div>
            </li>

        </ul>
    </div>

</div>
<div id="info-bar" style="box-shadow: 0px 3px 3px 0px rgba(0, 0, 0, 0.15); position: relative; z-index: 100;"
     align="center">
    <div id="info-bar-area" align="left">
        <div class="top-thin-links">
            <div class="thin-links-wrapper">
                <a class="review" href="free-estimatesdetails.php"><span class="icon"></span><span>Free Shipping Estimate</span></a>
                <a class="finance" href="estimate-sizeof-shipment.php"><span
                        class="icon"></span><span>Moving Calculator</span></a>
                <a class="facebook" href="moving-tips.php"><span class="icon"></span><span>Moving Tips</span></a>
                <a class="catalogue" href="ordernowdetails.php"><span class="icon"></span><span>Order Online</span></a>
                <a class="trade-account" href="ask-a-question.php"><span class="icon"></span><span>Shipping ?</span></a>
            </div>
        </div>
    </div>
</div>

</body>
</html>

<form id="frmNVO" class="frmAS" action="nvo.php" method="post">
    <div id="contents" align="center">
        <div id="contentsArea" align="left">
            <img src="source/images/nvocc.jpg">
            <div class="col span_12_of_12"
                 style="width: 90%; position: relative;  vertical-align: top; padding: 20px 20px 20px 40px; padding-bottom: 40px; background-color: #ffffff;"
                 align=" left">

                <div style="background-color: #f4f4f4; padding: 0px 15px 15px; 0px; margin-left: 10px;">
                    <table border="0"
                           style="margin-top: 10px; font-size: 11pt; padding-top: 0px; padding-left: 30px; width: 900px;">
                        <tr>
                            <td style="width: 50%;">
                                <ul style="line-height: 2; font-weight:bold; list-style-image: url('source/images/list-style-icon.png');">
                                    <li><a href="lcl-export-schedule.php" class="resource-link" target="_blank"><b>Weekly
                                                Sailings</b></a></li>
                                    <!-- <li style="margin-left: 0px;">
                                         <select id="list_ports" name="list_ports" class="form-textbox"
                                                 style="margin-left: 0px;">
                                             <option selected>List of Countries Served</option>

                                                 <option value="Afghanistan">
                                         Afghanistan                    </option>
                                                     <option value="Alaska">
                                         Alaska                    </option>
                                                     <option value="Albania">
                                         Albania                    </option>
                                                     <option value="Algeria">
                                         Algeria                    </option>
                                                     <option value="Angola">
                                         Angola                    </option>
                                                     <option value="Antigua">
                                         Antigua                    </option>
                                                     <option value="Argentina">
                                         Argentina                    </option>
                                                     <option value="Aruba">
                                         Aruba                    </option>
                                                     <option value="Australia">
                                         Australia                    </option>
                                                     <option value="Austria">
                                         Austria                    </option>
                                                     <option value="Bahamas">
                                         Bahamas                    </option>
                                                     <option value="Bahrain">
                                         Bahrain                    </option>
                                                     <option value="Bangladesh">
                                         Bangladesh                    </option>
                                                     <option value="Barbados">
                                         Barbados                    </option>
                                                     <option value="Belgium">
                                         Belgium                    </option>
                                                     <option value="Belize">
                                         Belize                    </option>
                                                     <option value="Benin">
                                         Benin                    </option>
                                                     <option value="Brazil">
                                         Brazil                    </option>
                                                     <option value="Brunei">
                                         Brunei                    </option>
                                                     <option value="Bulgaria">
                                         Bulgaria                    </option>
                                                     <option value="Cambodia">
                                         Cambodia                    </option>
                                                     <option value="Cameroon">
                                         Cameroon                    </option>
                                                     <option value="Canada">
                                         Canada                    </option>
                                                     <option value="Canary Islands">
                                         Canary Islands                    </option>
                                                     <option value="Caroline">
                                         Caroline                    </option>
                                                     <option value="Chile">
                                         Chile                    </option>
                                                     <option value="China">
                                         China                    </option>
                                                     <option value="Columbia">
                                         Columbia                    </option>
                                                     <option value="Comoros Islands">
                                         Comoros Islands                    </option>
                                                     <option value="Congo">
                                         Congo                    </option>
                                                     <option value="Croatia">
                                         Croatia                    </option>
                                                     <option value="Cuba">
                                         Cuba                    </option>
                                                     <option value="Cyprus">
                                         Cyprus                    </option>
                                                     <option value="Czechoslovakia">
                                         Czechoslovakia                    </option>
                                                     <option value="Denmark">
                                         Denmark                    </option>
                                                     <option value="Djibouti">
                                         Djibouti                    </option>
                                                     <option value="Dominica">
                                         Dominica                    </option>
                                                     <option value="Dominican Republic">
                                         Dominican Republic                    </option>
                                                     <option value="Ecuador">
                                         Ecuador                    </option>
                                                     <option value="Egypt">
                                         Egypt                    </option>
                                                     <option value="El Salvador">
                                         El Salvador                    </option>
                                                     <option value="Estonia">
                                         Estonia                    </option>
                                                     <option value="Ethiopia">
                                         Ethiopia                    </option>
                                                     <option value="Fiji">
                                         Fiji                    </option>
                                                     <option value="Finland">
                                         Finland                    </option>
                                                     <option value="France">
                                         France                    </option>
                                                     <option value="Gabon">
                                         Gabon                    </option>
                                                     <option value="Gambia">
                                         Gambia                    </option>
                                                     <option value="Germany">
                                         Germany                    </option>
                                                     <option value="Ghana">
                                         Ghana                    </option>
                                                     <option value="Gilbert">
                                         Gilbert                    </option>
                                                     <option value="Grand Cayman">
                                         Grand Cayman                    </option>
                                                     <option value="Greece">
                                         Greece                    </option>
                                                     <option value="Grenada">
                                         Grenada                    </option>
                                                     <option value="Guam">
                                         Guam                    </option>
                                                     <option value="Guatemala">
                                         Guatemala                    </option>
                                                     <option value="Guinea">
                                         Guinea                    </option>
                                                     <option value="Guyana">
                                         Guyana                    </option>
                                                     <option value="Haiti">
                                         Haiti                    </option>
                                                     <option value="Hawaii">
                                         Hawaii                    </option>
                                                     <option value="Honduras">
                                         Honduras                    </option>
                                                     <option value="Hungary">
                                         Hungary                    </option>
                                                     <option value="Iceland">
                                         Iceland                    </option>
                                                     <option value="India">
                                         India                    </option>
                                                     <option value="Indonesia">
                                         Indonesia                    </option>
                                                     <option value="Iran">
                                         Iran                    </option>
                                                     <option value="Iraq">
                                         Iraq                    </option>
                                                     <option value="Ireland">
                                         Ireland                    </option>
                                                     <option value="Israel">
                                         Israel                    </option>
                                                     <option value="Italy">
                                         Italy                    </option>
                                                     <option value="Ivory Coast">
                                         Ivory Coast                    </option>
                                                     <option value="Jamaica">
                                         Jamaica                    </option>
                                                     <option value="Japan">
                                         Japan                    </option>
                                                     <option value="Jordan">
                                         Jordan                    </option>
                                                     <option value="Kenya">
                                         Kenya                    </option>
                                                     <option value="Kuwait">
                                         Kuwait                    </option>
                                                     <option value="Latvia">
                                         Latvia                    </option>
                                                     <option value="Lebanon">
                                         Lebanon                    </option>
                                                     <option value="Liberia">
                                         Liberia                    </option>
                                                     <option value="Libya">
                                         Libya                    </option>
                                                     <option value="Macau">
                                         Macau                    </option>
                                                     <option value="Madagascar">
                                         Madagascar                    </option>
                                                     <option value="Malagasy">
                                         Malagasy                    </option>
                                                     <option value="Malawi">
                                         Malawi                    </option>
                                                     <option value="Malaysia">
                                         Malaysia                    </option>
                                                     <option value="Maldives">
                                         Maldives                    </option>
                                                     <option value="Malta">
                                         Malta                    </option>
                                                     <option value="Mariana">
                                         Mariana                    </option>
                                                     <option value="Marshall">
                                         Marshall                    </option>
                                                     <option value="Martinique">
                                         Martinique                    </option>
                                                     <option value="Mauritania">
                                         Mauritania                    </option>
                                                     <option value="Mauritius">
                                         Mauritius                    </option>
                                                     <option value="Mexico">
                                         Mexico                    </option>
                                                     <option value="Micronesia">
                                         Micronesia                    </option>
                                                     <option value="Montserrat">
                                         Montserrat                    </option>
                                                     <option value="Morocco">
                                         Morocco                    </option>
                                                     <option value="Mozambique">
                                         Mozambique                    </option>
                                                     <option value="Myanmar">
                                         Myanmar                    </option>
                                                     <option value="Namibia">
                                         Namibia                    </option>
                                                     <option value="Netherlands">
                                         Netherlands                    </option>
                                                     <option value="Netherlands Antilles">
                                         Netherlands Antilles                    </option>
                                                     <option value="New Caledonia">
                                         New Caledonia                    </option>
                                                     <option value="New Herbrides">
                                         New Herbrides                    </option>
                                                     <option value="New Zealand">
                                         New Zealand                    </option>
                                                     <option value="Nicaragua">
                                         Nicaragua                    </option>
                                                     <option value="Nigeria">
                                         Nigeria                    </option>
                                                     <option value="Norway">
                                         Norway                    </option>
                                                     <option value="Oman">
                                         Oman                    </option>
                                                     <option value="Pakistan">
                                         Pakistan                    </option>
                                                     <option value="Panama">
                                         Panama                    </option>
                                                     <option value="Papua New Gunea">
                                         Papua New Gunea                    </option>
                                                     <option value="Peru">
                                         Peru                    </option>
                                                     <option value="Philippines">
                                         Philippines                    </option>
                                                     <option value="Poland">
                                         Poland                    </option>
                                                     <option value="Portugal">
                                         Portugal                    </option>
                                                     <option value="Puerto Rico">
                                         Puerto Rico                    </option>
                                                     <option value="Qatar">
                                         Qatar                    </option>
                                                     <option value="Reunion Islands">
                                         Reunion Islands                    </option>
                                                     <option value="Romania">
                                         Romania                    </option>
                                                     <option value="Russia">
                                         Russia                    </option>
                                                     <option value="Saudi Arabia">
                                         Saudi Arabia                    </option>
                                                     <option value="Scotland">
                                         Scotland                    </option>
                                                     <option value="Senegal">
                                         Senegal                    </option>
                                                     <option value="Seychelles">
                                         Seychelles                    </option>
                                                     <option value="Sierra Leone">
                                         Sierra Leone                    </option>
                                                     <option value="Singapore">
                                         Singapore                    </option>
                                                     <option value="Solomon Islands">
                                         Solomon Islands                    </option>
                                                     <option value="Somalia">
                                         Somalia                    </option>
                                                     <option value="South Africa">
                                         South Africa                    </option>
                                                     <option value="South Korea">
                                         South Korea                    </option>
                                                     <option value="Spain">
                                         Spain                    </option>
                                                     <option value="Sri Lanka">
                                         Sri Lanka                    </option>
                                                     <option value="St. Kitts">
                                         St. Kitts                    </option>
                                                     <option value="St. Maarten">
                                         St. Maarten                    </option>
                                                     <option value="St. Vincent">
                                         St. Vincent                    </option>
                                                     <option value="Sudan">
                                         Sudan                    </option>
                                                     <option value="Surinam">
                                         Surinam                    </option>
                                                     <option value="Sweden">
                                         Sweden                    </option>
                                                     <option value="Switzerland">
                                         Switzerland                    </option>
                                                     <option value="Syria">
                                         Syria                    </option>
                                                     <option value="Tahiti">
                                         Tahiti                    </option>
                                                     <option value="Taiwan">
                                         Taiwan                    </option>
                                                     <option value="Tanzania">
                                         Tanzania                    </option>
                                                     <option value="Thailand">
                                         Thailand                    </option>
                                                     <option value="Togo">
                                         Togo                    </option>
                                                     <option value="Tonga">
                                         Tonga                    </option>
                                                     <option value="Trinidad">
                                         Trinidad                    </option>
                                                     <option value="Tunisia">
                                         Tunisia                    </option>
                                                     <option value="Turkey">
                                         Turkey                    </option>
                                                     <option value="Tuvalu">
                                         Tuvalu                    </option>
                                                     <option value="UAE">
                                         UAE                    </option>
                                                     <option value="UK">
                                         UK                    </option>
                                                     <option value="Ukraine">
                                         Ukraine                    </option>
                                                     <option value="Uruguay">
                                         Uruguay                    </option>
                                                     <option value="US">
                                         US                    </option>
                                                     <option value="Venezuela">
                                         Venezuela                    </option>
                                                     <option value="Vietnam">
                                         Vietnam                    </option>
                                                     <option value="Western Samoa">
                                         Western Samoa                    </option>
                                                     <option value="Yemen">
                                         Yemen                    </option>
                                                     <option value="Yugoslavia">
                                         Yugoslavia                    </option>
                                                     <option value="Zaire">
                                         Zaire                    </option>
                                                     <option value="Zambia">
                                         Zambia                    </option>
                                                     <option value="Zimbabwe">
                                         Zimbabwe                    </option>

                                         </select></li> -->
                                    <!--<li><a href="lcl-coloadrate.php" class="resource-link" target="_blank">LCL </a>LCL &amp; FCL</li>-->
                                    <li><a href="ocean-freight-carrier.php" class="resource-link" target="_blank">Ocean Freight Carrier</a></li>
                                    <li> <a href="cargo-tracking.php" class="resource-link"
                                            target="_blank">Track Shipment</a></li>
                                </ul>
                            </td>
                            <td style="width: 50%;">
                                <ul style="list-style-image: url('source/images/list-style-icon.png'); line-height: 2; font-weight:bold">
                                    <li>
                                        <select id="lcl-cargo-receiving-location" name="lcl-cargo-receiving-location"
                                                class="form-textbox" style="margin-left: 0px;">
                                            <option selected>List of LCL Cargo Receiving Locations</option>
                                            <option value="oakland">Oakland, CA</option>
                                            <option value="chicago">Chicago, IL</option>
                                            <option value="los_angeles">Los Angeles, CA</option>
                                            <option value="new_york">New York, NY</option>
                                            <option value="houston">Houston, TX</option>
                                            <option value="seattle">Seattle, WA</option>
                                            <option value="bostan">Boston, MA</option>
                                            <option value="baltimore">Baltimore, MD</option>
                                            <option value="dallas">Dallas, TX</option>
                                            <option value="miami">Miami, FL</option>
                                            <option value="norfolk">Norfolk, VA</option>
                                            <option value="new_orleans">New Orleans, LA</option>
                                            <option value="portland">Portland, OR</option>
                                            <option value="atlanta">Atlanta, GA</option>
                                            <option value="philadelphia">Philadelphia, PA</option>
                                            <option value="memphis">Memphis, TN</option>
                                            <option value="detroit">Detroit, MI</option>
                                            <option value="columbus">Columbus, OH</option>
                                            <option value="cleveland">Cleveland, OH</option>
                                            <option value="charleston">Charleston, SC</option>
                                            <option value="charlotte">Charlotte, NC</option>
                                        </select></li>
                                    <!--<li><a href="#" class="resource-link">Coloader&#39;s Tool to
                                            cooperate</a></li>-->
                                    <li>Direct &amp; Faster Transit Time</li>
                                    <li>
                                        <a href="lcl-cargo.php" class="resource-link" target="_blank">LCL Cargo</a></li>
                                </ul>
                            </td>
                        </tr>
                    </table>
                </div>
                <br>
                <!--<h4 style="font-weight: 700;" class="title">LCL Receiving at&#45;</h4>
                <table style="width: 100%; padding-left: 30px; font-size: 10pt;">
                    <tr>
                        <td><a id="show_atlanta" style="cursor: pointer;" class="resource-link">Atlanta</a></td>
                        <td><a id="show_bostan" style="cursor: pointer;" class="resource-link">Boston</a></td>
                        <td><a id="show_baltimore" style="cursor: pointer;" class="resource-link">Baltimore</a></td>
                        <td><a id="show_chicago" style="cursor: pointer;" class="resource-link">Chicago</a></td>
                        <td><a id="show_dallas" style="cursor: pointer;" class="resource-link">Dallas</a></td>
                        <td><a id="show_houston" style="cursor: pointer;" class="resource-link">Houston</a></td>
                        <td><a id="show_los_angeles" style="cursor: pointer;" class="resource-link">Los Angeles</a></td>
                    </tr>
                    <tr style="height: 40px;">
                        <td><a id="show_miami" style="cursor: pointer;" class="resource-link">Miami</a></td>
                        <td><a id="show_norfolk" style="cursor: pointer;" class="resource-link">Norfolk</a></td>
                        <td><a id="show_new_york" style="cursor: pointer;" class="resource-link">New York</a></td>
                        <td><a id="show_new_orleans" style="cursor: pointer;" class="resource-link">New Orleans</a></td>
                        <td><a id="show_oakland" style="cursor: pointer;" class="resource-link">Oakland</a></td>
                        <td><a id="show_portland" style="cursor: pointer;" class="resource-link">Portland</a></td>
                        <td><a id="show_seattle" style="cursor: pointer;" class="resource-link">Seattle</a></td>
                    </tr>
                </table> -->
                <hr style="width:900px">
                <br>

                <table style="width: 100%;">
                    <tr>
                        <td style="width: 50%;"><h4 style="font-weight: 700;" class="title">Ask Rates/Make a Booking</h4></td>

                        <td style="width: 50%;" align="right">

                        </td>
                    </tr>
                </table>
                <div id="loader" style="display: none; margin-top: 20px;">
                    <img src="source/images/gif-loader.GIF" style="margin-top: 20%;">
                </div>

                <div id="frmDisplay">
                    <table border="0" style="padding-top: 2px; padding-left: 30px; width: 900px;">
                        <tr>
                            <td colspan="5">
                                <div style="margin-bottom: 5px; font-size: 11pt; font-weight: 700; color: red; display: none;">From Country or To Country must be United States</div>
                            </td>
                        </tr>

                        <tr>
                            <td style="width: 170px;" class="form-label">From</td>
                            <td class="form-label">:&nbsp;
                                <select id="from" name="from" class="form-textbox">
                                    <option>Select Service</option>
                                    <option value="Door">Door</option>
                                    <option value="Port">Port</option>
                                </select>
                            </td>
                            <td></td>
                            <td class="form-label">To</td>
                            <td class="form-label">:&nbsp;
                                <select id="to" name="to" class="form-textbox">
                                    <option>Select Service</option>
                                    <option value="Door">Door</option>
                                    <option value="Port">Port</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td class="form-label">From City *</td>
                            <td class="form-label">:&nbsp; <input type="text" id="frm_city" name="frm_city" value=""
                                                                  class="form-textbox" required></td>
                            <td></td>
                            <td class="form-label">To City</td>
                            <td class="form-label">:&nbsp; <input type="text" id="to_city" name="to_city" value=""
                                                                  class="form-textbox"></td>
                        </tr>
                        <tr>
                            <td class="form-label">From State *</td>
                            <td class="form-label">:&nbsp; <input type="text" id="frm_state" name="frm_state" value=""
                                                                  class="form-textbox" required>
                            </td>
                            <td></td>
                            <td class="form-label">To State</td>
                            <td class="form-label">:&nbsp; <input type="text" id="to_state" name="to_state" value=""
                                                                  class="form-textbox"></td>
                        </tr>
                        <tr>
                            <td class="form-label" style="width: 170px;">From Country</td>
                            <td class="form-label" style="width: 250px;">:&nbsp;
                                <select class="form-textbox" id="from_country"
                                        name="from_country" value="US"
                                        onchange="selectCity(this.options[this.selectedIndex].value)" required>
                                    <option value="">Select Country</option>
                                    <option value="Afghanistan">
                                        Afghanistan                    </option>
                                    <option value="Alaska">
                                        Alaska                    </option>
                                    <option value="Albania">
                                        Albania                    </option>
                                    <option value="Algeria">
                                        Algeria                    </option>
                                    <option value="Angola">
                                        Angola                    </option>
                                    <option value="Antigua">
                                        Antigua                    </option>
                                    <option value="Argentina">
                                        Argentina                    </option>
                                    <option value="Aruba">
                                        Aruba                    </option>
                                    <option value="Australia">
                                        Australia                    </option>
                                    <option value="Austria">
                                        Austria                    </option>
                                    <option value="Bahamas">
                                        Bahamas                    </option>
                                    <option value="Bahrain">
                                        Bahrain                    </option>
                                    <option value="Bangladesh">
                                        Bangladesh                    </option>
                                    <option value="Barbados">
                                        Barbados                    </option>
                                    <option value="Belgium">
                                        Belgium                    </option>
                                    <option value="Belize">
                                        Belize                    </option>
                                    <option value="Benin">
                                        Benin                    </option>
                                    <option value="Brazil">
                                        Brazil                    </option>
                                    <option value="Brunei">
                                        Brunei                    </option>
                                    <option value="Bulgaria">
                                        Bulgaria                    </option>
                                    <option value="Cambodia">
                                        Cambodia                    </option>
                                    <option value="Cameroon">
                                        Cameroon                    </option>
                                    <option value="Canada">
                                        Canada                    </option>
                                    <option value="Canary Islands">
                                        Canary Islands                    </option>
                                    <option value="Caroline">
                                        Caroline                    </option>
                                    <option value="Chile">
                                        Chile                    </option>
                                    <option value="China">
                                        China                    </option>
                                    <option value="Columbia">
                                        Columbia                    </option>
                                    <option value="Comoros Islands">
                                        Comoros Islands                    </option>
                                    <option value="Congo">
                                        Congo                    </option>
                                    <option value="Croatia">
                                        Croatia                    </option>
                                    <option value="Cuba">
                                        Cuba                    </option>
                                    <option value="Cyprus">
                                        Cyprus                    </option>
                                    <option value="Czechoslovakia">
                                        Czechoslovakia                    </option>
                                    <option value="Denmark">
                                        Denmark                    </option>
                                    <option value="Djibouti">
                                        Djibouti                    </option>
                                    <option value="Dominica">
                                        Dominica                    </option>
                                    <option value="Dominican Republic">
                                        Dominican Republic                    </option>
                                    <option value="Ecuador">
                                        Ecuador                    </option>
                                    <option value="Egypt">
                                        Egypt                    </option>
                                    <option value="El Salvador">
                                        El Salvador                    </option>
                                    <option value="Estonia">
                                        Estonia                    </option>
                                    <option value="Ethiopia">
                                        Ethiopia                    </option>
                                    <option value="Fiji">
                                        Fiji                    </option>
                                    <option value="Finland">
                                        Finland                    </option>
                                    <option value="France">
                                        France                    </option>
                                    <option value="Gabon">
                                        Gabon                    </option>
                                    <option value="Gambia">
                                        Gambia                    </option>
                                    <option value="Germany">
                                        Germany                    </option>
                                    <option value="Ghana">
                                        Ghana                    </option>
                                    <option value="Gilbert">
                                        Gilbert                    </option>
                                    <option value="Grand Cayman">
                                        Grand Cayman                    </option>
                                    <option value="Greece">
                                        Greece                    </option>
                                    <option value="Grenada">
                                        Grenada                    </option>
                                    <option value="Guam">
                                        Guam                    </option>
                                    <option value="Guatemala">
                                        Guatemala                    </option>
                                    <option value="Guinea">
                                        Guinea                    </option>
                                    <option value="Guyana">
                                        Guyana                    </option>
                                    <option value="Haiti">
                                        Haiti                    </option>
                                    <option value="Hawaii">
                                        Hawaii                    </option>
                                    <option value="Honduras">
                                        Honduras                    </option>
                                    <option value="Hungary">
                                        Hungary                    </option>
                                    <option value="Iceland">
                                        Iceland                    </option>
                                    <option value="India">
                                        India                    </option>
                                    <option value="Indonesia">
                                        Indonesia                    </option>
                                    <option value="Iran">
                                        Iran                    </option>
                                    <option value="Iraq">
                                        Iraq                    </option>
                                    <option value="Ireland">
                                        Ireland                    </option>
                                    <option value="Israel">
                                        Israel                    </option>
                                    <option value="Italy">
                                        Italy                    </option>
                                    <option value="Ivory Coast">
                                        Ivory Coast                    </option>
                                    <option value="Jamaica">
                                        Jamaica                    </option>
                                    <option value="Japan">
                                        Japan                    </option>
                                    <option value="Jordan">
                                        Jordan                    </option>
                                    <option value="Kenya">
                                        Kenya                    </option>
                                    <option value="Kuwait">
                                        Kuwait                    </option>
                                    <option value="Latvia">
                                        Latvia                    </option>
                                    <option value="Lebanon">
                                        Lebanon                    </option>
                                    <option value="Liberia">
                                        Liberia                    </option>
                                    <option value="Libya">
                                        Libya                    </option>
                                    <option value="Macau">
                                        Macau                    </option>
                                    <option value="Madagascar">
                                        Madagascar                    </option>
                                    <option value="Malagasy">
                                        Malagasy                    </option>
                                    <option value="Malawi">
                                        Malawi                    </option>
                                    <option value="Malaysia">
                                        Malaysia                    </option>
                                    <option value="Maldives">
                                        Maldives                    </option>
                                    <option value="Malta">
                                        Malta                    </option>
                                    <option value="Mariana">
                                        Mariana                    </option>
                                    <option value="Marshall">
                                        Marshall                    </option>
                                    <option value="Martinique">
                                        Martinique                    </option>
                                    <option value="Mauritania">
                                        Mauritania                    </option>
                                    <option value="Mauritius">
                                        Mauritius                    </option>
                                    <option value="Mexico">
                                        Mexico                    </option>
                                    <option value="Micronesia">
                                        Micronesia                    </option>
                                    <option value="Montserrat">
                                        Montserrat                    </option>
                                    <option value="Morocco">
                                        Morocco                    </option>
                                    <option value="Mozambique">
                                        Mozambique                    </option>
                                    <option value="Myanmar">
                                        Myanmar                    </option>
                                    <option value="Namibia">
                                        Namibia                    </option>
                                    <option value="Netherlands">
                                        Netherlands                    </option>
                                    <option value="Netherlands Antilles">
                                        Netherlands Antilles                    </option>
                                    <option value="New Caledonia">
                                        New Caledonia                    </option>
                                    <option value="New Herbrides">
                                        New Herbrides                    </option>
                                    <option value="New Zealand">
                                        New Zealand                    </option>
                                    <option value="Nicaragua">
                                        Nicaragua                    </option>
                                    <option value="Nigeria">
                                        Nigeria                    </option>
                                    <option value="Norway">
                                        Norway                    </option>
                                    <option value="Oman">
                                        Oman                    </option>
                                    <option value="Pakistan">
                                        Pakistan                    </option>
                                    <option value="Panama">
                                        Panama                    </option>
                                    <option value="Papua New Gunea">
                                        Papua New Gunea                    </option>
                                    <option value="Peru">
                                        Peru                    </option>
                                    <option value="Philippines">
                                        Philippines                    </option>
                                    <option value="Poland">
                                        Poland                    </option>
                                    <option value="Portugal">
                                        Portugal                    </option>
                                    <option value="Puerto Rico">
                                        Puerto Rico                    </option>
                                    <option value="Qatar">
                                        Qatar                    </option>
                                    <option value="Reunion Islands">
                                        Reunion Islands                    </option>
                                    <option value="Romania">
                                        Romania                    </option>
                                    <option value="Russia">
                                        Russia                    </option>
                                    <option value="Saudi Arabia">
                                        Saudi Arabia                    </option>
                                    <option value="Scotland">
                                        Scotland                    </option>
                                    <option value="Senegal">
                                        Senegal                    </option>
                                    <option value="Seychelles">
                                        Seychelles                    </option>
                                    <option value="Sierra Leone">
                                        Sierra Leone                    </option>
                                    <option value="Singapore">
                                        Singapore                    </option>
                                    <option value="Solomon Islands">
                                        Solomon Islands                    </option>
                                    <option value="Somalia">
                                        Somalia                    </option>
                                    <option value="South Africa">
                                        South Africa                    </option>
                                    <option value="South Korea">
                                        South Korea                    </option>
                                    <option value="Spain">
                                        Spain                    </option>
                                    <option value="Sri Lanka">
                                        Sri Lanka                    </option>
                                    <option value="St. Kitts">
                                        St. Kitts                    </option>
                                    <option value="St. Maarten">
                                        St. Maarten                    </option>
                                    <option value="St. Vincent">
                                        St. Vincent                    </option>
                                    <option value="Sudan">
                                        Sudan                    </option>
                                    <option value="Surinam">
                                        Surinam                    </option>
                                    <option value="Sweden">
                                        Sweden                    </option>
                                    <option value="Switzerland">
                                        Switzerland                    </option>
                                    <option value="Syria">
                                        Syria                    </option>
                                    <option value="Tahiti">
                                        Tahiti                    </option>
                                    <option value="Taiwan">
                                        Taiwan                    </option>
                                    <option value="Tanzania">
                                        Tanzania                    </option>
                                    <option value="Thailand">
                                        Thailand                    </option>
                                    <option value="Togo">
                                        Togo                    </option>
                                    <option value="Tonga">
                                        Tonga                    </option>
                                    <option value="Trinidad">
                                        Trinidad                    </option>
                                    <option value="Tunisia">
                                        Tunisia                    </option>
                                    <option value="Turkey">
                                        Turkey                    </option>
                                    <option value="Tuvalu">
                                        Tuvalu                    </option>
                                    <option value="UAE">
                                        UAE                    </option>
                                    <option value="UK">
                                        UK                    </option>
                                    <option value="Ukraine">
                                        Ukraine                    </option>
                                    <option value="Uruguay">
                                        Uruguay                    </option>
                                    <option value="US" selected>
                                        US                    </option>
                                    <option value="Venezuela">
                                        Venezuela                    </option>
                                    <option value="Vietnam">
                                        Vietnam                    </option>
                                    <option value="Western Samoa">
                                        Western Samoa                    </option>
                                    <option value="Yemen">
                                        Yemen                    </option>
                                    <option value="Yugoslavia">
                                        Yugoslavia                    </option>
                                    <option value="Zaire">
                                        Zaire                    </option>
                                    <option value="Zambia">
                                        Zambia                    </option>
                                    <option value="Zimbabwe">
                                        Zimbabwe                    </option>
                                </select>
                            </td>
                            <td style="width: 20px;"></td>
                            <td class="form-label">To Country</td>
                            <td class="form-label">:&nbsp;
                                <select class="form-textbox" id="to_country" value="" name="to_country"
                                        onchange="selectCity1(this.options[this.selectedIndex].value)">>
                                    <option>Select Country</option>
                                    <option value="Afghanistan">
                                        Afghanistan                    </option>
                                    <option value="Alaska">
                                        Alaska                    </option>
                                    <option value="Albania">
                                        Albania                    </option>
                                    <option value="Algeria">
                                        Algeria                    </option>
                                    <option value="Angola">
                                        Angola                    </option>
                                    <option value="Antigua">
                                        Antigua                    </option>
                                    <option value="Argentina">
                                        Argentina                    </option>
                                    <option value="Aruba">
                                        Aruba                    </option>
                                    <option value="Australia">
                                        Australia                    </option>
                                    <option value="Austria">
                                        Austria                    </option>
                                    <option value="Bahamas">
                                        Bahamas                    </option>
                                    <option value="Bahrain">
                                        Bahrain                    </option>
                                    <option value="Bangladesh">
                                        Bangladesh                    </option>
                                    <option value="Barbados">
                                        Barbados                    </option>
                                    <option value="Belgium">
                                        Belgium                    </option>
                                    <option value="Belize">
                                        Belize                    </option>
                                    <option value="Benin">
                                        Benin                    </option>
                                    <option value="Brazil">
                                        Brazil                    </option>
                                    <option value="Brunei">
                                        Brunei                    </option>
                                    <option value="Bulgaria">
                                        Bulgaria                    </option>
                                    <option value="Cambodia">
                                        Cambodia                    </option>
                                    <option value="Cameroon">
                                        Cameroon                    </option>
                                    <option value="Canada">
                                        Canada                    </option>
                                    <option value="Canary Islands">
                                        Canary Islands                    </option>
                                    <option value="Caroline">
                                        Caroline                    </option>
                                    <option value="Chile">
                                        Chile                    </option>
                                    <option value="China">
                                        China                    </option>
                                    <option value="Columbia">
                                        Columbia                    </option>
                                    <option value="Comoros Islands">
                                        Comoros Islands                    </option>
                                    <option value="Congo">
                                        Congo                    </option>
                                    <option value="Croatia">
                                        Croatia                    </option>
                                    <option value="Cuba">
                                        Cuba                    </option>
                                    <option value="Cyprus">
                                        Cyprus                    </option>
                                    <option value="Czechoslovakia">
                                        Czechoslovakia                    </option>
                                    <option value="Denmark">
                                        Denmark                    </option>
                                    <option value="Djibouti">
                                        Djibouti                    </option>
                                    <option value="Dominica">
                                        Dominica                    </option>
                                    <option value="Dominican Republic">
                                        Dominican Republic                    </option>
                                    <option value="Ecuador">
                                        Ecuador                    </option>
                                    <option value="Egypt">
                                        Egypt                    </option>
                                    <option value="El Salvador">
                                        El Salvador                    </option>
                                    <option value="Estonia">
                                        Estonia                    </option>
                                    <option value="Ethiopia">
                                        Ethiopia                    </option>
                                    <option value="Fiji">
                                        Fiji                    </option>
                                    <option value="Finland">
                                        Finland                    </option>
                                    <option value="France">
                                        France                    </option>
                                    <option value="Gabon">
                                        Gabon                    </option>
                                    <option value="Gambia">
                                        Gambia                    </option>
                                    <option value="Germany">
                                        Germany                    </option>
                                    <option value="Ghana">
                                        Ghana                    </option>
                                    <option value="Gilbert">
                                        Gilbert                    </option>
                                    <option value="Grand Cayman">
                                        Grand Cayman                    </option>
                                    <option value="Greece">
                                        Greece                    </option>
                                    <option value="Grenada">
                                        Grenada                    </option>
                                    <option value="Guam">
                                        Guam                    </option>
                                    <option value="Guatemala">
                                        Guatemala                    </option>
                                    <option value="Guinea">
                                        Guinea                    </option>
                                    <option value="Guyana">
                                        Guyana                    </option>
                                    <option value="Haiti">
                                        Haiti                    </option>
                                    <option value="Hawaii">
                                        Hawaii                    </option>
                                    <option value="Honduras">
                                        Honduras                    </option>
                                    <option value="Hungary">
                                        Hungary                    </option>
                                    <option value="Iceland">
                                        Iceland                    </option>
                                    <option value="India">
                                        India                    </option>
                                    <option value="Indonesia">
                                        Indonesia                    </option>
                                    <option value="Iran">
                                        Iran                    </option>
                                    <option value="Iraq">
                                        Iraq                    </option>
                                    <option value="Ireland">
                                        Ireland                    </option>
                                    <option value="Israel">
                                        Israel                    </option>
                                    <option value="Italy">
                                        Italy                    </option>
                                    <option value="Ivory Coast">
                                        Ivory Coast                    </option>
                                    <option value="Jamaica">
                                        Jamaica                    </option>
                                    <option value="Japan">
                                        Japan                    </option>
                                    <option value="Jordan">
                                        Jordan                    </option>
                                    <option value="Kenya">
                                        Kenya                    </option>
                                    <option value="Kuwait">
                                        Kuwait                    </option>
                                    <option value="Latvia">
                                        Latvia                    </option>
                                    <option value="Lebanon">
                                        Lebanon                    </option>
                                    <option value="Liberia">
                                        Liberia                    </option>
                                    <option value="Libya">
                                        Libya                    </option>
                                    <option value="Macau">
                                        Macau                    </option>
                                    <option value="Madagascar">
                                        Madagascar                    </option>
                                    <option value="Malagasy">
                                        Malagasy                    </option>
                                    <option value="Malawi">
                                        Malawi                    </option>
                                    <option value="Malaysia">
                                        Malaysia                    </option>
                                    <option value="Maldives">
                                        Maldives                    </option>
                                    <option value="Malta">
                                        Malta                    </option>
                                    <option value="Mariana">
                                        Mariana                    </option>
                                    <option value="Marshall">
                                        Marshall                    </option>
                                    <option value="Martinique">
                                        Martinique                    </option>
                                    <option value="Mauritania">
                                        Mauritania                    </option>
                                    <option value="Mauritius">
                                        Mauritius                    </option>
                                    <option value="Mexico">
                                        Mexico                    </option>
                                    <option value="Micronesia">
                                        Micronesia                    </option>
                                    <option value="Montserrat">
                                        Montserrat                    </option>
                                    <option value="Morocco">
                                        Morocco                    </option>
                                    <option value="Mozambique">
                                        Mozambique                    </option>
                                    <option value="Myanmar">
                                        Myanmar                    </option>
                                    <option value="Namibia">
                                        Namibia                    </option>
                                    <option value="Netherlands">
                                        Netherlands                    </option>
                                    <option value="Netherlands Antilles">
                                        Netherlands Antilles                    </option>
                                    <option value="New Caledonia">
                                        New Caledonia                    </option>
                                    <option value="New Herbrides">
                                        New Herbrides                    </option>
                                    <option value="New Zealand">
                                        New Zealand                    </option>
                                    <option value="Nicaragua">
                                        Nicaragua                    </option>
                                    <option value="Nigeria">
                                        Nigeria                    </option>
                                    <option value="Norway">
                                        Norway                    </option>
                                    <option value="Oman">
                                        Oman                    </option>
                                    <option value="Pakistan">
                                        Pakistan                    </option>
                                    <option value="Panama">
                                        Panama                    </option>
                                    <option value="Papua New Gunea">
                                        Papua New Gunea                    </option>
                                    <option value="Peru">
                                        Peru                    </option>
                                    <option value="Philippines">
                                        Philippines                    </option>
                                    <option value="Poland">
                                        Poland                    </option>
                                    <option value="Portugal">
                                        Portugal                    </option>
                                    <option value="Puerto Rico">
                                        Puerto Rico                    </option>
                                    <option value="Qatar">
                                        Qatar                    </option>
                                    <option value="Reunion Islands">
                                        Reunion Islands                    </option>
                                    <option value="Romania">
                                        Romania                    </option>
                                    <option value="Russia">
                                        Russia                    </option>
                                    <option value="Saudi Arabia">
                                        Saudi Arabia                    </option>
                                    <option value="Scotland">
                                        Scotland                    </option>
                                    <option value="Senegal">
                                        Senegal                    </option>
                                    <option value="Seychelles">
                                        Seychelles                    </option>
                                    <option value="Sierra Leone">
                                        Sierra Leone                    </option>
                                    <option value="Singapore">
                                        Singapore                    </option>
                                    <option value="Solomon Islands">
                                        Solomon Islands                    </option>
                                    <option value="Somalia">
                                        Somalia                    </option>
                                    <option value="South Africa">
                                        South Africa                    </option>
                                    <option value="South Korea">
                                        South Korea                    </option>
                                    <option value="Spain">
                                        Spain                    </option>
                                    <option value="Sri Lanka">
                                        Sri Lanka                    </option>
                                    <option value="St. Kitts">
                                        St. Kitts                    </option>
                                    <option value="St. Maarten">
                                        St. Maarten                    </option>
                                    <option value="St. Vincent">
                                        St. Vincent                    </option>
                                    <option value="Sudan">
                                        Sudan                    </option>
                                    <option value="Surinam">
                                        Surinam                    </option>
                                    <option value="Sweden">
                                        Sweden                    </option>
                                    <option value="Switzerland">
                                        Switzerland                    </option>
                                    <option value="Syria">
                                        Syria                    </option>
                                    <option value="Tahiti">
                                        Tahiti                    </option>
                                    <option value="Taiwan">
                                        Taiwan                    </option>
                                    <option value="Tanzania">
                                        Tanzania                    </option>
                                    <option value="Thailand">
                                        Thailand                    </option>
                                    <option value="Togo">
                                        Togo                    </option>
                                    <option value="Tonga">
                                        Tonga                    </option>
                                    <option value="Trinidad">
                                        Trinidad                    </option>
                                    <option value="Tunisia">
                                        Tunisia                    </option>
                                    <option value="Turkey">
                                        Turkey                    </option>
                                    <option value="Tuvalu">
                                        Tuvalu                    </option>
                                    <option value="UAE">
                                        UAE                    </option>
                                    <option value="UK">
                                        UK                    </option>
                                    <option value="Ukraine">
                                        Ukraine                    </option>
                                    <option value="Uruguay">
                                        Uruguay                    </option>
                                    <option value="US">
                                        US                    </option>
                                    <option value="Venezuela">
                                        Venezuela                    </option>
                                    <option value="Vietnam">
                                        Vietnam                    </option>
                                    <option value="Western Samoa">
                                        Western Samoa                    </option>
                                    <option value="Yemen">
                                        Yemen                    </option>
                                    <option value="Yugoslavia">
                                        Yugoslavia                    </option>
                                    <option value="Zaire">
                                        Zaire                    </option>
                                    <option value="Zambia">
                                        Zambia                    </option>
                                    <option value="Zimbabwe">
                                        Zimbabwe                    </option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td class="form-label">From Port</td>
                            <td class="form-label">:&nbsp; <select class="form-textbox" id="from_near_port" name="from_near_port">
                                    <option value="Country Port">Select One Near You</option>
                                </select>
                                <span id="from_near_loader"></span>
                            </td>
                            <td style="width: 20px;"></td>
                            <td class="form-label">To Port</td>
                            <td class="form-label">:&nbsp; <select class="form-textbox" id="to_near_port" name="to_near_port">
                                    <option value="Country Port">Select One Near You</option>
                                </select>
                                <span id="to_near_loader"></span>
                            </td>
                        </tr>
                        <tr>
                            <td class="form-label">From Zip *</td>
                            <td class="form-label">:&nbsp; <input type="text" id="frm_zip" name="frm_zip" value=""
                                                                  class="form-textbox" required></td>
                            <td></td>
                            <td class="form-label">To Zip</td>
                            <td class="form-label">:&nbsp; <input type="text" id="to_zip" name="to_zip" value=""
                                                                  class="form-textbox"></td>
                        </tr>
                        <tr>
                            <td class="form-label">Commodity <a id="show_list" class="resource-link"
                                                                style="margin-left: 75px; position: absolute; margin-top: -18px; cursor: pointer; display: none;"
                                                                onclick="change_commodity(1)">(Show List)</a>
                                <span style="position: absolute; margin-left: 105px;">:</span>
                            </td>
                            <td class="form-label">&nbsp;
                                <select id="commodity" name="commodity" class="form-textbox"
                                        style="margin-top: -15px; display: block; margin-left: 15px;" onchange="change_commodity(this.value)">
                                    <option>Select Commodity</option>
                                    <option value="If Others">If Others</option><option value="Automobile/s">Automobile/s</option><option value="Boat">Boat</option><option value="Charity Goods">Charity Goods</option><option value="Computer/Electronics">Computer/Electronics</option><option value="Hazardous Cargo">Hazardous Cargo</option><option value="Machinery">Machinery</option><option value="Metal Scrap">Metal Scrap</option><option value="Motorcycle/s">Motorcycle/s</option><option value="Perishable Cargo">Perishable Cargo</option><option value="Residential">Residential</option><option value="Residential with Vehicle (Auto, Motorcycle etc)">Residential with Vehicle (Auto, Motorcycle etc)</option><option value="Vehicle/s">Vehicle/s</option><option value="Waste Paper">Waste Paper</option><option value="Used Clothing">Used Clothing</option>
                                </select>
                                <input type="text" id="txt_commodity" name="txt_commodity"
                                       style="display: none; margin-top: -15px; margin-left: 15px;" class="form-textbox"
                                       value="">
                            </td>
                            <td></td>
                            <td class="form-label">Total Weight</td>
                            <td class="form-label">: &nbsp;<input id="total_weight" name="total_weight" value=""
                                                                  class="form-textbox"
                                                                  style="width: 80px;">
                                <span style="float: right; margin: 5px 30px 0px 0px"><label
                                        style="width: auto; padding-left: 15px; padding-top: 0px;"><input type="radio" name="weight"
                                                                                                          value="Kgs"
                                                                                                          checked>&nbsp;Kgs</label>
            <label style="width: auto; padding-left: 15px; padding-top: 0px;"><input type="radio" name="weight"
                                                                                     value="Lbs">&nbsp;Lbs</label></span>
                            </td>
                        </tr>
                        <tr>
                            <td class="form-label">Freight Charges</td>
                            <td class="form-label">:&nbsp;
                                <select id="freight_charges" name="freight_charges" class="form-textbox">
                                    <option selected>Select Freight Charges</option>
                                    <option value="Paid by Shipper">Paid by Shipper</option>
                                    <option value="Paid by Consignee">Paid by Consignee</option>
                                    <option value="3rd Party/Forwarder">3rd Party/Forwarder</option>
                                </select>
                            </td>
                            <td></td>
                            <td class="form-label">Mode of Transport *</td>
                            <td class="form-label">:&nbsp;
                                <select id="transport_mode" name="transport_mode" class="form-textbox" required>
                                    <option value="">Select Transport Mode</option>
                                    <option value="By Sea">By Sea</option>
                                    <option value="By Air">By Air</option>
                                    <option value="By Air - fastest">By Air - fastest</option>
                                    <option value="Both Air & Sea">Both Air & Sea</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td class="form-label">Details of the Package Length x Breadth x Height (Cubic Feet
                                / Meters) or Container size
                            </td>
                            <td class="form-label"><span style="position: absolute; margin-top: 22px;">:</span>
                                <textarea id="dimensions" name="dimensions" class="form-textbox"
                                          style="min-height: 60px; max-height: 60px; min-width: 200px; max-width: 200px; margin-left: 15px; margin-top: 5px;"></textarea>
                            </td>
                            <td></td>
                            <td class="form-label" style="vertical-align: top;">Insurance<br><br>HBL/HAWB #</td>
                            <td class="form-label" style="vertical-align: top; margin-top: 10px;">:&nbsp;
                                <select id="insurance" name="insurance" class="form-textbox" style="width:88px;">
                                    <option selected>Insurance</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                <input type="text" id="insurance_amt" name="insurance_amt" value=""
                                       class="form-textbox" style="width: 100px;">
                                <br>:&nbsp;&nbsp;<input type="text" id="hbl_no" name="hbl_no" class="form-textbox"
                                                        value="">
                            </td>
                        </tr>

                        <tr>
                            <td colspan="5" style="padding: 10px 0px;">
                                <hr>
                            </td>
                        </tr>
                        <tr>
                            <td class="form-label">Name *</td>
                            <td class="form-label">:&nbsp;
                                <input type="text" id="name" name="name" required class="form-textbox" value=""
                                       style="width: 118px;">
                                <input type="text" id="last_name" name="last_name" style="width: 70px;" class="form-textbox"
                                       value="">
                            </td>
                            <td></td>
                            <td class="form-label">Company</td>
                            <td class="form-label">:&nbsp;&nbsp; <span>http://www.</span><input type="text" id="company"
                                                                                                value="" name="company"
                                                                                                class="form-textbox" style="width: 135px;"></td>
                        </tr>
                        <tr>
                            <td class="form-label">Phone *</td>
                            <td class="form-label">:&nbsp;&nbsp;&nbsp;
                                <input id="phone" name="phone" type="tel" value="" required class="form-textbox">
                                <input type="hidden" id="mob_no" name="mob_no" value="">
                            </td>
                            <td></td>
                            <td class="form-label">Email *</td>
                            <td class="form-label">:&nbsp; <input type="email" id="email" name="email" value=""
                                                                  class="form-textbox" required></td>
                        </tr>
                        <tr>
                            <td class="form-label">Address<span style="float: right; margin-right: -6px;">:</span></td>
                            <td class="form-label">
        <textarea id="address" name="address" class="form-textbox"
                  style="min-height: 50px; max-height: 50px; min-width: 200px; max-width: 200px; margin-left: 15px;"></textarea>
                            </td>
                            <td></td>
                            <td class="form-label">Message<span style="float: right; margin-right: -6px;">:</span></td>
                            <td class="form-label">
        <textarea id="message" name="message" class="form-textbox"
                  style="min-height: 50px; max-height: 50px; min-width: 200px; max-width: 200px; margin-left: 15px;"></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td class="form-label">Are You?</td>
                            <td class="form-label">:&nbsp;
                                <select id="are_you" name="are_you" class="form-textbox">
                                    <option selected>Select One</option>
                                    <option value="Manufacturer">Manufacturer</option>
                                    <option value="Supplier/Vendor">Supplier/Vendor</option>
                                    <option value="Exporter/Importer">Exporter/Importer</option>
                                    <option value="Distributor">Distributor</option>
                                    <option value="Trader">Trader</option>
                                    <option value="Forwarder/Cargo Agent">Forwarder/Cargo Agent</option>
                                    <option value="Shipper">Shipper</option>
                                    <option value="NVOCC">NVOCC</option>
                                    <option value="Mover">Mover</option>
                                    <option value="Broker">Broker</option>
                                    <option value="Carrier">Carrier</option>
                                    <option value="Other">Other</option>
                                </select>
                            </td>
                            <td class="form-label"></td>
                            <td class="form-label">How you found us?</td>
                            <td class="form-label">:&nbsp;
                                <select id="find_us" name="find_us" class="form-textbox" required>
                                    <option value="Referred by someone">Referred by someone</option>
                                    <option value="Direct Mailers">Direct Mailers</option>
                                    <option value="Trade Magazines">Trade Magazines</option>
                                    <option value="Publications">Publications</option>
                                    <option value="Email broadcasting">Email broadcasting</option>
                                    <option value="Google">Google</option>
                                    <option value="Yahoo">Yahoo</option>
                                    <option value="MSN">MSN</option>
                                    <option value="AOL">AOL</option>
                                    <option value="Others">Others</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td colspan="4"><br>
                                <label style="padding-left: 30px; padding-top: 15px;">
                                    <input type="checkbox" name="salesperson_contact" id="salesperson_contact"
                                           style="position: absolute; margin-top: 2px; margin-left: -15px;">Salesperson can Contact Me</label>
                                <label style="padding-left: 35px; padding-top: 15px;">
                                    <input type="checkbox" name="service_literature" id="service_literature"
                                           style="position: absolute; margin-top: 2px; margin-left: -15px;">Send Service Literature</label>
                                <label style="padding-left: 35px; padding-top: 15px;">
                                    <input type="checkbox" name="mails_list" id="mails_list"
                                           style="position: absolute; margin-top: 2px; margin-left: -15px;">Don&#39;t Put me on your Mailing
                                    List</label>
                            </td>
                        </tr>
                        <tr>
                            <td></td>

                            <td style="height: 10px;" colspan="4">

                            </td>
                        </tr>
                        <tr>
                            <td class="form-label" style="position: absolute; margin-top: 5px;">Security Code<span
                                    style="margin-left: 91px;">:</span></td>
                            <td colspan="4" class="form-label" style="">
                                <input type="text" maxlength="6" name="captcha" class="form-textbox" autocomplete="off" id="captcha"
                                       style="width: 100px; position: absolute; margin-left: 15px;">
                                <img src="get_captcha.php" alt="" id="captcha_cv" style="border: 1px solid #c6c6c6; margin-left: 120px;"/>
                                <img src="source/images/refresh.png" id="refreshimg" name="refreshimg" style="cursor: pointer;"
                                     title="Click to refresh image" onclick="change_captcha()"><br>
                                <span id="codeInfo_cv"></span>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td colspan="4">
                                <input type="submit" id="send_info" name="send_info" value="Send Information" class="naviBlue"
                                       style="font-size: 11pt; padding: 7px 20px; margin-left: 8px;">
                            </td>
                        </tr>
                        <tr style="height: 20px;">
                            <td colspan="5"></td>
                        </tr>
                    </table>
                    <hr style="border: 0px; border-bottom:1px solid #dedede;  width: 900px; padding-top: 10px;">
                    <table style="width:950px; margin-top:20px;">
                        <tr>
                            <td style="vertical-align:top;"><a href="https://gem.godaddy.com/p/1c93d8?fe=1&pact=11313-134886588-9352950102-de014283098cc5e708f422047ed1c4789473ed90" class="resource-link" style="font-size: 11pt;" target="_blank"
                                >California to India</a><br>
                                <a href="source/images/NVOCC-LCL-Consol-Service.jpg" class="resource-link" style="font-size: 11pt;"  download>India, Mid East &amp; Africa</a>
                            </td>
                            <td class="form-label" style="vertical-align:top;"><a href="source/documents/Carrier-to-Carrier-Agreement.pdf" class="resource-link" download>Carrier to Carrier
                                    Agreement</a><br>
                                <a href="source/documents/BLsampleform.pdf" class="resource-link" download>Bill
                                    of Lading Specimen</a>
                            </td></td>
                            <td class="form-label"></td>
                            <td class="form-label" style="vertical-align:top;"><a href="contactlist.php" class="resource-link" target="_blank" style="font-size: 10pt;">Contacts At Air 7
                                    Seas</a><br><a href="refer-to-friend.php" class="resource-link" target="_blank">Recommend to a Friend</a></td>
                            <td class="form-label">USA Toll Free Tel: 1-800- 41 NVOCC<br>
                                Fax: 1-800-396-6659<br>
                                Email: <a href="mailto:nvo@air7seas.us"class="resource-link">nvo (@) air7seas.us</td>
                        </tr>

                    </table>
                </div>
                <div id="frmMessage" align="center" style="display: none;">
                    <div align="center">
                        <div style="padding-top: 20px; width: 700px;">
                            <p style="font-size: 11pt; width: 700; background-color: #edf5fe; padding: 20px 50px;">Thanks for
                                considering our shipping services. <br>Generally
                                you should be getting the reply to your <b>freight query in 24hrs</b> <br> <b>(except
                                    weekend/holidays)</b> but to expedite, you may call sales supervisor. <br> Looking forward
                                to win your business &amp; serve you.</p><br>

                            <p style="font-size: 11pt; width: 500;"><b>AIR 7 SEAS Team</b> &#45;&#45; www.air7seas.com</p>

                            <p style="font-size: 10pt; width: 500; color: #f09403;">Licensed, Bonded &amp; Insured. We bring
                                >20 years of experience to you. <br> Your choice for Air, Land or Sea shipping in USA &#45;
                                Professional &amp; Dependable</p><br>

                            <!--<p style="font-size: 11pt; width: 500; padding-top:10px;" align="center"><b>For the Further
                                    Details Contact:</b><br>Contact No: 408-9578787, Extn: 450 <br>Info@Air7Seas.com</p><br>-->


                            <a href="index.php" class="naviBlue" style="padding: 7px 20px;">Back to Home</a>
                        </div>

                    </div>
                </div>


                <!--        MODAL POPUP BEGINS      -->

                <div id="output"></div>

                <div id="overlay" class="web_dialog_overlay"></div>

                <div id="atlanta" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_atlanta">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">Atlanta, GA:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR 7 SEAS / VLS</b><br>
                                <b>5148 Kennedy Road</b><br>
                                <b>Forest Park, GA 30297</b><br>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                        <!--<tr>
                            <td colspan="2" style="text-align: center;">
                                <input id="btnSubmit" type="button" value="Submit"/>
                            </td>
                        </tr>-->
                    </table>
                </div>
                <div id="bostan" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_bostan">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">Boston, MA:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR 7 SEAS / The International Cargo Center of New England</b><br>
                                <b>One Harbor Street Boston, MA 02210</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                        <!--<tr>
                            <td colspan="2" style="text-align: center;">
                                <input id="btnSubmit" type="button" value="Submit"/>
                            </td>
                        </tr>-->
                    </table>
                </div>
                <div id="baltimore" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_baltimore">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">Baltimore, MD:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR 7 SEAS / BIW</b><br>
                                <b>7646-56 Canton Center Drive, Baltimore, MD 21224</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                        <!--<tr>
                            <td colspan="2" style="text-align: center;">
                                <input id="btnSubmit" type="button" value="Submit"/>
                            </td>
                        </tr>-->
                    </table>
                </div>
                <div id="chicago" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_chicago">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">Chicago, IL :</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR 7 SEAS / VLS</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p style="font-size: 10pt; font-weight: 700;">250 S. Gary Ave.<br>
                                    Carol Stream, IL 60188</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>

                    </table>
                </div>
                <div id="dallas" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_dallas">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">Dallas, TX:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR 7 SEAS / BLE</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p style="font-size: 10pt; font-weight: 700;">1220 Texan Trail, Ste. 200<br>
                                    Grapevine, TX 76051</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                    </table>
                </div>
                <div id="houston" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_houston">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">Houston, TX:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR 7 SEAS / AG</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p style="font-size: 10pt; font-weight: 700;">971 N. Sam Houston Pkwy, East Suite 100,<br>
                                     Houston, TX 77032</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                    </table>
                </div>
                <div id="los_angeles" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_los_angeles">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">Los Angeles, CA:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR 7 SEAS / VLS</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p style="font-size: 10pt; font-weight: 700;">2665 East Del Amo Blvd<br>
                                    Rancho Dominguez, CA 90221</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                    </table>
                </div>
                <div id="miami" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_miami">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">Miami, FL:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR 7 SEAS / VLS</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p style="font-size: 10pt; font-weight: 700;">9175 N.W. 117th Avenue<br>
                                    Miami, FL 33178</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                    </table>
                </div>
                <div id="norfolk" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_norfolk">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">Norfolk, VA:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR 7 SEAS / PTL</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p style="font-size: 10pt; font-weight: 700;">5998 Robin Hood Road<br>
                                    Suite 108, Norfolk, VA 23518</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                    </table>
                </div>
                <div id="new_york" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_new_york">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">New York, NY:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR 7 SEAS / VLS</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p style="font-size: 10pt; font-weight: 700;">900 Castle Road, Secaucus<br>
                                    NJ 07094</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                    </table>
                </div>
                <div id="new_orleans" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_new_orleans">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">New Orleans, LA:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR 7 SEAS / SWFI</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p style="font-size: 10pt; font-weight: 700;">12301 Old Gentily Road<br>
                                    New Orleans, Louisiana 70129</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                    </table>
                </div>
                <div id="oakland" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_oakland">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">Oakland/San Francisco, CA:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR 7 SEAS / ACT2</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p style="font-size: 10pt; font-weight: 700;">701E DNA Way<br>
                                    South San Francisco, CA 94080</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                    </table>
                </div>
                <div id="portland" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_portland">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">Portland, OR:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR 7 SEAS / SNWC</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p style="font-size: 10pt; font-weight: 700;">5330 NE Courier Ct.,<br>
                                    Suite 400, Portland, OR 97218</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                    </table>
                </div>
                <div id="seattle" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_seattle">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">Seattle, WA:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR 7 SEAS / SNW</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p style="font-size: 10pt; font-weight: 700;">20488 84th Avenue South<br>
                                    Kent, WA 98032</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                    </table>
                </div>
                <div id="philadelphia" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_philadelphia">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">Philadelphia, PA:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR7SEAS / Galasso Trucking</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p style="font-size: 10pt; font-weight: 700;">2840 E. Hedley Street<br>
                                    Philadelphia, PA 19137</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                    </table>
                </div>
                <div id="memphis" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_memphis">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">Memphis, TN:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR7SEAS / Easley Trans</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p style="font-size: 10pt; font-weight: 700;">4300 Air Trans Road<br>
                                    Memphis, TN 38118</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                    </table>
                </div>
                <div id="detroit" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_detroit">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">Detroit, MI:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR7SEAS / CST Co.</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p style="font-size: 10pt; font-weight: 700;">28450 Highland Road, Building #4<br>
                                    Romulus, MI 48174</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                    </table>
                </div>
                <div id="columbus" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_columbus">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">Columbus, OH:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR7SEAS / Midwest Express</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p style="font-size: 10pt; font-weight: 700;">6967 Alum Creek Drive,<br>
                                    Columbus, Ohio 43218</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                    </table>
                </div>
                <div id="cleveland" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_cleveland">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">Cleveland, OH:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR7SEAS / A G Xpress</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p style="font-size: 10pt; font-weight: 700;">6900 Lake Abrams Drive<br>
                                    Middleburg Heights, OH 44130</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                    </table>
                </div>
                <div id="charleston" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_charleston">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">Charleston, SC:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR7SEAS / P T Lines</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p style="font-size: 10pt; font-weight: 700;">3074 Ashley Phosphate Road<br>
                                    North Charleston, SC 29418</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                    </table>
                </div>
                <div id="charlotte" class="web_dialog">
                    <table style="width: 100%; border: 0px;" cellpadding="3" cellspacing="0">
                        <tr>
                            <td class="web_dialog_title">LCL Receiving At</td>
                            <td class="web_dialog_title align_right">
                                <a href="#" id="close_charlotte">Close</a>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b style="font-size: 16px;">Charlotte, NC:</b><br>
                                <b>For Export LCL shipments -</b><br>
                                <b>AIR7SEAS / P T Lines</b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p style="font-size: 10pt; font-weight: 700;">3410 Oak Lake Blvd<br>
                                    Charlotte, NC 28208</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;"><br>

                                <p>Before delivery of the shipment,<br>
                                    Please obtain Booking No from </p><br></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 15px;">
                                <b>Ph: 800-416-8622,<br>
                                    Fx: 800-396-6659<br>
                                    Email: <a href="mailto:lcl@air7seas.us"
                                              class="resource-link">LCL (@) air7seas.us</a></b>
                            </td>
                        </tr>
                    </table>
                </div>

            </div>

        </div>
    </div>
    <script src="source/js/tel/intlTelInput.js"></script>
    <script src="source/js/tel/utils.js"></script>
    <script>
        /*$("#phone").intlTelInput({
         nationalMode: true,
         utilsScript: "source/js/tel/utils.js"
         });*/

        var input = $("#phone"),
            output = $("#output");

        input.intlTelInput({
            nationalMode: true,
            utilsScript: "../../lib/libphonenumber/build/utils.js" // just for formatting/placeholders etc
        });

        input.keyup(function () {
            var intlNumber = input.intlTelInput("getNumber");
            if (intlNumber) {
                //output.text("International: " + intlNumber);
                document.getElementById('mob_no').value = intlNumber;
            } else {
                output.text("Please enter a number below");
            }
        });

    </script>
</form>
<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" lang="en">


<head>
    <!--Start of Zopim Live Chat Script
    <script type="text/javascript">
        window.$zopim || (function (d, s) {
            var z = $zopim = function (c) {
                z._.push(c)
            }, $ = z.s =
                d.createElement(s), e = d.getElementsByTagName(s)[0];
            z.set = function (o) {
                z.set.
                    _.push(o)
            };
            z._ = [];
            z.set._ = [];
            $.async = !0;
            $.setAttribute('charset', 'utf-8');
            $.src = '//v2.zopim.com/?2NBKvMLseKA8C45Gr5ywmelLErtAkht6';
            z.t = +new Date;
            $.
                type = 'text/javascript';
            e.parentNode.insertBefore($, e)
        })(document, 'script');
    </script>
    End of Zopim Live Chat Script-->

    <!-- BEGIN JIVOSITE CODE {literal} -->
    <script type='text/javascript'>
        (function(){ var widget_id = '3kWxTfUv3x';var d=document;var w=window;function l(){
            var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
    <!-- {/literal} END JIVOSITE CODE -->

    <link href="source/css/sole.css" rel="stylesheet">

<body class="vpform pgTrustPilot" lang="en-GB" align="center">


<div id="footerinfo" style="width: 100%; background-color: #cccccc" align="center">
    <div style="width: 980px; background-color: #ffffff; padding: 10px 0px;" align="left">
        <div id="BreadcrumbWrapper">
            <div class="section group">
                <div class="col span_12_of_12" style="line-height: 23px; border-right: 1px solid #dddddd; ">
                </div>
            </div>
            <hr>
        </div>
        <img src="source/images/logos.jpg" alt="" style="width: 980px;">
    </div>
</div>
<!--footer-->
<footer style="background-color: #4d4d4d">
    <div class="DB MMdLFtR">
        <div class="FL DB MMdLFtRa" style="padding-left: 75px;">

            <div id="FtR" class="LH20 footer-links">
                <div class="left-section FL">
                    <div class="left-wrapper FL">
                        <section class="ordering-fromus">
                            <div class="title">
                                AIR 7 SEAS
                            </div>
                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="about-air7seas.php" id="aContact">About Us</a>
                                    <a href="feedback.php" id="aFAQ">Feedback</a>
                                    <a href="shipping-news.php" id="aOrdertracking">News &amp;
                                        Events</a>
                                    <a href="#">Privacy Policy</a>
                                    <a href="terms-and-conditions.php">Terms &amp;
                                        Conditions</a>
                                    <a href="jobs.php">Jobs</a>
                                </li>
                            </ul>
                        </section>
                        <section class="help-support">
                            <div class="title">
                                SERVICES
                            </div>

                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="international-freight.php">International &#45;
                                        Freight</a>
                                    <a href="domestic-freight.php">Domestic &#45;
                                        Freight</a>
                                    <a href="autos-vehicles-machinery.php">Machinery &amp; Vehicles</a>
                                    <a href="freight-forwarder.php">Freight Forwarding</a>
                                    <a href="customs-release.php">Customs Release</a>
                                    <a href="moving.php">Movers</a>
                                </li>
                            </ul>
                        </section>
                        <section class="information">
                            <div class="title">
                                SUPPORT
                            </div>
                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="faq.php">Frequently Asked Questions</a>
                                    <a href="moving-tips.php">Moving Tips</a>

                                    <a href="payments.php" id="aFreeRecycle">Payment Options</a>
                                    <a href="procedural-steps-for-claim-submition.php">Claim
                                        Submission Procedures</a>
                                    <a href="isf.php">Importer Security Filing (ISF)</a>
                                    <a href="order-online-insurance.php">Order Online -
                                        Insurance</a>

                                </li>
                            </ul>
                        </section>
                    </div>
                    <div class="social-links">


                    </div>
                </div>
                <section class="newsletter">
                    <div class="title">CORPORATE OFFICE</div>
                    <div class="footer-contact">
                        <ul>
                            <li class="f-map"><a
                                    href="contact-us.php"
                                    target="_blank">1815 Houret Court, <br> Milpitas, CA 95035, US</a></li>
                            <li class="f-phone"><span><a href="tel:+18882477732">Call Us: 1-888-247-7732</a></span></li>
                            <li class="f-mail"><a href="mailto:info@air7seas.us">info (@) air7seas.us</a></li>
                        </ul>
                    </div>
                    <br><br>

                    <div>
                        <a href="https://www.facebook.com/pages/Air7Seas-Transport-Logistics-Inc/731149066945233" target="_blank">
                            <img src="source/images/icons/fb.png" style="margin-top: 7px; width: 25px;">
                        </a>&nbsp;
                        <a href="https://twitter.com/Air7seas" target="_blank">
                            <img src="source/images/icons/twitter.png" style="margin-top: 7px; width: 25px;">
                        </a>&nbsp;
                        <a href="https://plus.google.com/b/103457876862758011863/" target="_blank">
                            <img src="source/images/icons/gp.png" style="margin-top: 7px; width: 25px;">
                        </a>
                    </div>

                </section>
            </div>
        </div>
    </div>

</footer>

<div class="baseline-footer">
    <div class="baseline-footer-wrapper">
        <section class="FL" itemprop="provider" itemscope itemtype="http://schema.org/Organization">
            <div class="FL">

                <meta itemprop="url" content="http://www.air7seas.com/"/>
                <meta itemprop="name" content="Air 7 Seas Transport Logistics Pvt Ltd"/>
                <meta itemprop="email" content="info@air7seas.com "/>
                <div itemprop="location" itemscope itemtype="http://www.schema.org/LocalBusiness">

                    <meta itemprop="openingHours" content="Mo-Fr 08:00-16:00"/>
                    <meta itemprop="openingHours" content="Sa-Su Holiday"/>
                    <div itemprop="geo" itemscope itemtype="http://schema.org/GeoCoordinates">
                        <meta itemprop="latitude" content="53.55519"/>
                        <meta itemprop="longitude" content="-3.041651"/>
                    </div>
                </div>

            </div>
            <div class="contact-information">
                <div id="pnlUKFooter">

                    <div class="address" itemprop=address itemscope itemtype=http://schema.org/PostalAddress>
                        <span class="address-image"></span>

                        <div class="address-wrapper">
                            <span itemprop=streetAddress><a href="contact-us.php" style="color: #cfcfcf;">1815 Houret
                                    Court,<br> Milpitas, CA 95035</a></span>,
                            <span itemprop=addressLocality>USA</span>
                        </div>
                    </div>
                    <div class="phone-number">
                        <span class="phone-image"></span>
                        <span class="telephone" itemprop=telephone><a href="tel:+18882477732" style="color: #cfcfcf;">1-888-247-7732</a></span>
                        <span class="sales-support">(Customer Support)</span>
                    </div>
                    <div class="email-address">
                        <span class="email-img"></span>
                        <span itemprop=email><a class="mail-id"
                                                href="mailto:info@air7seas.us">info (@) air7seas.us</a></span>
                    </div>


                </div>

            </div>
        </section>


        <div itemprop="copyrightHolder" itemscope itemtype="http://www.schema.org/Organization"
             class="copywrite-holder">
            <meta itemprop="url" content="http://www.air7seas.com/"/>
            <meta itemprop="name" content="Air 7 Seas Transport Logistics Pvt Ltd"/>

            <meta itemprop="email" content="info@air7seas.com "/>

            Copyright <span class="copyrights">&copy;</span> AIR 7 SEAS 2014 &#45; 2015
        </div>
        <meta itemprop="copyrightYear" content="1986-2014"/>

        <div class="divAuthorisedText">Authorised and regulated by AIR 7 SEAS 95035</div>


    </div>
</div>

</body>
</html>

<script>
    document.getElementById('footerinfo').style.display = 'none';
</script>
</body>
</html>