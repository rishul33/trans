


<!DOCTYPE html>
<html>
<head>
    <title>Cargo Tracking - AIR 7 SEAS</title>
    <link rel="shortcut icon" href="source/images/a7s-icon.ico"/>
    <meta charset="utf-8"/>
    <meta name="description"
          content="Air 7 seas is leading Freight Forwarder, NVOCC, OTI, Cargo Consolidator, Custom Broker, Carrier, and Shipping Agents for Ship Lines, Airlines, Truckers, Shipper & Consignee to handle International and Domestic transportation by Air Freight, Sea Freight or Road Freight.">
    <meta name="description"
          content="Air 7 Seas Overseas Relocation, Air 7 Seas Moving Overseas, Air 7 Seas Relocation Services, Air 7 Seas Shipping India, Air 7 Seas Shipping USA, Air 7 Seas Freight Forwarder, Air 7 Seas Air Freight, Air 7 Seas Air Cargo, Air 7 Seas Customs Clearance, Air 7 Seas International Shipping Companies, Air 7 Seas Moving Estimate, Air 7 Seas Shipping Quote, Air 7 Seas Moving International, Air 7 Seas Domestic Movers, Air 7 Seas Shipping Agent, Air 7 Seas Shipping International, Air 7 Seas International Moving Service, Air 7 Seas Cargo Agent, Air 7 Seas Customs Broker, Air 7 Seas International Mover, Air 7 Seas Household Goods, Air 7 Seas Commercial Goods, Air 7 Seas Breakbulk Cargo, Air 7 Seas Car Shipping, Air 7 Seas Motorbike Shipping, Air 7 Seas Auto Vehicle Mechinery, Air 7 Seas Cargo Consolidation, Air 7 Seas Freight Service Provider">
    <meta name="keywords"
          content="Overseas Relocation, Moving Overseas, Relocation Services, Shipping India, Shipping USA, Freight Forwarder, Air Freight, Air Cargo, Customs Clearance, International Shipping Companies, Moving Estimate, Shipping Quote, Moving International, Domestic Movers, Shipping Agent, Shipping International, International Moving Service, Cargo Agent, Customs Broker, International Mover, Household Goods, Commercial Goods, Breakbulk Cargo, Car Shipping, Motorbike Shipping, Auto Vehicle Mechinery, Cargo Consolidation, Freight Service Provider">
    <meta name="author" content="Air 7 Seas Transport Logistics Pvt Ltd">
    <!--  <base href="http://www.air7seas.com/"> -->

    <link href="source/css/responsive.css" rel="stylesheet">
    <link href="source/css/controls.css" rel="stylesheet">
    <link href="source/css/sole.css" rel="stylesheet" type="text/css" visible="true"/>
    <link href="source/css/tab-plugin.css" rel="stylesheet" type="text/css">

    <script src="source/js/tab-jquery.min.js"></script>
    <script src="source/js/tab-custom.min.js" type="text/javascript"></script>
    <script src="source/js/tab-common.min.js"></script>

    <script>
        /*(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

        ga('create', 'UA-54008281-2', 'auto');
        ga('send', 'pageview');*/

    </script>

</head>
<body>
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link href="source/css/sole.css" rel="stylesheet" type="text/css" visible="true"/>
    <link href="source/css/skin.css" rel="stylesheet" type="text/css" visible="true"/>

    <link
        href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800'
        rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="source/css/megadrop.css"/>
    <script type="text/javascript" src="source/js/megascripts.js"></script>
    <style>
        .searchbox {
            height: 28px;
            width: 225px;
            border: 1px solid #dadada;
            border-top-left-radius: 3px;
            border-bottom-left-radius: 3px;
            padding-left: 10px;
            font-size: 12px;
            color: #9b9b9b
        }

        .searchbutton {
            cursor: pointer;
            background-image: url('source/images/search.GIF');
            height: 30px;
            width: 70px;
            margin-top: 0;
            color: transparent
        }

        .txtSearchbox::-webkit-input-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox:-moz-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox::-moz-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox:-ms-input-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }
    </style>
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NQDLZPP');</script>
<!-- End Google Tag Manager -->
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NQDLZPP"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div id="topLine">
</div>
<div id="main-header" align="center" style="font-family: Arial;">
    <div id="main-header-area" align="left">
        <a href="index.php">
            <img src="source/images/logo-new.png" alt="Air 7 Seas" style="float: left; position: relative;"></a>

        <div class="top-small-link" style=" vertical-align: middle">
            <table border="0">
                <tr style="vertical-align: top">
                    <td style="padding-top: 3px;">
                        <a href="cargo-tracking.php" style="color: #404040; font-family: Arial;"><b>Cargo
                                Tracking</b></a>|
                        <a href="about-air7seas.php">About Us</a>|
                        <a href="https://portal.cargoez.com/air7seas/login" target="_blank">Login</a>|
                        <a href="shipping-news.php">News &amp; Events</a>

                    </td>
                    <td style="vertical-align: top;"><img src="source/images/phone-ico.PNG" alt=""
                                                          style="margin-top: 0px;">
                    </td>
                    <td style="padding: 3px 0 0 5px; width: 185px;">
                        <span style="font-size: 13pt; float: right"><span style="font-size: 9pt;">Toll Free:</span>
                        <a href="tel:+18882477732"
                           style="padding-left: 0px; padding-right: 0px; margin-right: 0px; color: #026799;"><b>1-888-247-7732<b/></a></span>
                    </td>

                </tr>
                <tr>
                    <td colspan="3" style="">
                        <div id="SrCl" style="padding-top: 8px; float: right">
                            <form method="post" action="search-results.php">

                                <input type="text" id="find" name="find" autocomplete="off"
                                       class="searchbox txtSearchbox" placeholder="How can i help you...?">
                                <input type="submit" name="" style="border:0px; height: 28px;" class="searchbutton"
                                       alt="Search"/>

                            </form>
                        </div>
                    </td>
                </tr>
            </table>


        </div>


    </div>
</div>
<div id="menu-bar" style="width: 100%; background-color: #1e6a89;" align="center">
<div style="width: 980px;" align="left">
<ul class="nav-mainmenu clearfix animated">
<li><a href="index.php">Home</a></li>
<li>
    <a href="#">Services</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px; ">

            <ul class="menu-items">
                <li class="seperator"><a href="international-freight.php" style="font-weight: 600">International
                        Freight</a></li>
                <li class="seperator"><a href="domestic-freight.php">Domestic Freight</a></li>
                <li class="seperator"><a href="freight-forwarder.php">Freight Forwarding</a></li>
                <li class="seperator"><a href="freight-consultation.php">Consultation</a></li>

            </ul>
        </div>
    </div>
</li>
<li><a href="#">Products</a>

    <div class="container-2" style="width: 500px;">
        <table border="0">
            <tr>
                <td style="border-right:1px solid #ccc; vertical-align: top;">
                    <div class="col1" style="width: 250px;">

                        <ul class="menu-items">


                            <li class="seperator"><a href="shipping-to-vietnam.php"><img
                                        src="source/images/Vietnam-Flag-icon.png" alt="Vietnam Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Saigon Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-india.php"><img
                                        src="source/images/India-Flag-icon.png" alt="India Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">India Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-middle-east.php"><img
                                        src="source/images/MiddleEast-Flag-icon.png" alt="Shipping to Middle East"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Middle East Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-china.php"><img
                                        src="source/images/China-Flag-icon.png" alt="China Shipper"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">China Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-philippines.php"><img
                                        src="source/images/Philippines-Flag-icon.png" alt="Philippines Shipper"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Manila Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-spain.php"><img
                                        src="source/images/Spain-Flag-icon.png" alt="Spain Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Spain Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-mexico.php"><img
                                        src="source/images/Mexico-Flag-icon.png" alt="Mexico Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Mexico Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="autos-to-canada.php"><img
                                        src="source/images/Canada-Flag-icon.png" alt="Canada Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Autos to Canada</span></a>
                            </li>
  <li class="seperator"><a href="importers-logistics-rep.php">Importer&#39;s Rep</a></li>

                        </ul>
                    </div>
                </td>
                <td style="vertical-align: top;">
                    <div class="col1" style="width: 250px;">

                        <ul class="menu-items">
                            <li class="seperator"><a href="shipping-to-africa.php">
                                    <img src="source/images/Africa-Flag-icon.png" alt="AfriCargo Express" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">AfriCargo Express</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-latin-america.php">
                                    <img src="source/images/Latino-Flag-icon.png" alt="Latino Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Latino Shipper</span></a>
                            </li>
                              <li class="seperator"><a href="nvo.php">
                                    <img src="source/images/lcl-icon.jpg" alt="Latino Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Cargo-Coloader LCL</span></a>
                            </li>
                            <li class="seperator"><a href="a7s-pre-fulfilment-service.php"><img src="source/images/receiving-center-icon.png"
                                                                                      alt="Air7seas Pre-Fulfillment Service" width="22px"
                                                                                      style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Pre-Fulfillment &amp; Delivery </span></a></li>
                            <li class="seperator"><a href="receiving-center.php"><img src="source/images/receiving-center-icon.png"
                                                                                      alt="Mexico Shipper" width="22px"
                                                                                      style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Pre-Shipping Receiving Center</span></a></li>
                            <!--<li class="seperator"><a href="receiving-center.php">Receiving Center</a></li>-->
                            <li class="seperator"><a href="partners-agents.php"><img
                                        src="source/images/partners-agents-icon.png" alt="Canada Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Partners - Agents</span></a>
                            </li>
                            <li class="seperator"><a href="autos-vehicles-machinery.php"><img
                                        src="source/images/autos-vehicle-mechinery-icon.png" alt="Mexico Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Autos Vehicles Machinery</span></a>
                            </li>
                            <li class="seperator"><a href="transloading-transhipment.php">Transloading -
                                    Transhipment</a></li>
                            <li class="seperator"><a href="ship-hazardous-perishable-goods.php">Hazardous &amp;
                                    Perishable</a></li>


                        </ul>
                    </div>
                </td>
            </tr>
        </table>


    </div>
</li>
<li><a href="#">Mover &amp; Relocation</a>

    <div class="container-4" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="move-household-goods.php">Household Goods</a></li>
                <li class="seperator"><a href="ship-commercial-goods.php">Commercial Goods</a></li>
                <!--     <li class="seperator"><a href="#">Countries served</a></li> -->
            </ul>
        </div>
    </div>
</li>
<li><a href="#">Freight Carrier</a>

    <div class="container-4" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="air-freight-carrier.php">Air Freight Carrier</a></li>
                <li class="seperator"><a href="ocean-freight-carrier.php">Ocean Freight Carrier</a>
                </li>
                <li class="seperator"><a href="soc-movements.php">SOC Movements</a></li>
            </ul>
        </div>
    </div>
</li>
<li>
    <a href="#">Customs Release</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="export-import.php"">Export - Import</a></li>
                <li class="seperator"><a href="isf.php">ISF / AMS</a></li>
                <li class="seperator"><a href="importers-logistics-rep.php">Importer&#39;s Rep</a></li>
            </ul>
        </div>
    </div>
</li>

<li><a href="#">Insurance</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="cargo-insurance-coverage-types.php">Coverage Types</a></li>
                <li class="seperator"><a href="free-estimate-insurance.php">Free Estimate - Insurance</a>
                </li>
                <li class="seperator"><a href="order-online-insurance.php">Order Online - Insurance</a></li>
                <li class="seperator"><a href="claim-submission.php">Claim submission Form</a></li>
                <li class="seperator"><a href="faq-insurance.php">FAQ</a></li>
                <!--<li class="seperator"><a href="#">Resources - Insurance</a></li>-->
                <li class="seperator"><a href="damages-to-the-goods-by-customs.php">Damages to the goods by
                        Customs</a></li>

            </ul>
        </div>
    </div>
</li>
<li><a href="#">Contact Us</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="contact-us.php">Contacts</a></li>
                <li class="seperator"><a href="free-estimatesdetails.php">Get an Estimate</a></li>
                <li class="seperator"><a href="ordernowdetails.php">Book a Shipment</a></li>
                <li class="seperator"><a href="feedback.php">Feedback</a></li>
                <li class="seperator"><a href="complaint.php">Complaint</a></li>
                <li class="seperator"><a href="customer-review.php">Testimonial</a></li>
                <li class="seperator"><a href="claim-submission.php">Claim submission</a></li>
                <li class="seperator"><a href="terms-and-conditions.php">Terms &amp; Conditions</a></li>
                <li class="seperator"><a href="jobs.php">Jobs</a></li>
            </ul>
        </div>
    </div>
</li>
<li><a href="#" class="last-list">Tools &amp; Resources</a>

    <div class="container-1 right" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="forms-downloads.php">Documents &amp; Forms</a></li>
                <li class="seperator"><a href="payments.php">Payment options</a></li>
                <li class="seperator"><a href="moving-tips.php">Moving Tips</a></li>
                <li class="seperator"><a href="container-sizes.php">Container Sizes for Sea</a></li>
                <li class="seperator"><a href="faq.php">FAQs</a></li>
                <li class="seperator"><a href="shipping-news.php">News &amp; Events</a></li>
                <li class="seperator"><a href="ask-a-question.php">Ask a question</a></li>
            </ul>
        </div>
    </div>
</li>

</ul>
</div>

</div>
<div id="info-bar" style="box-shadow: 0px 3px 3px 0px rgba(0, 0, 0, 0.15); position: relative; z-index: 100;"
     align="center">
    <div id="info-bar-area" align="left">
        <div class="top-thin-links">
            <div class="thin-links-wrapper">
                <a class="review" href="free-estimatesdetails.php"><span class="icon"></span><span>Free Shipping Estimate</span></a>
                <a class="finance" href="estimate-sizeof-shipment.php"><span
                        class="icon"></span><span>Moving Calculator</span></a>
                <a class="facebook" href="moving-tips.php"><span class="icon"></span><span>Moving Tips</span></a>
                <a class="catalogue" href="ordernowdetails.php"><span class="icon"></span><span>Order Online</span></a>
                <a class="trade-account" href="ask-a-question.php"><span class="icon"></span><span>Shipping ?</span></a>
            </div>
        </div>
    </div>
</div>

</body>
</html>
<div id="contents" align="center">
<div id="contentsArea" align="left" style="padding-left: 20px;">

<!-- Top Information Bar -->
<div id="BreadcrumbWrapper" style="width: 940px;">
    <div id="Breadcrumb" class="Breadcrumb BoxSBB">
         <span itemscope itemtype='#'>
             <a href="index.php" itemprop='url' title="Air7seas Homepage">
                 <span itemprop='title'>Home</span>
             </a>
         </span>
        &rsaquo; <span itemscope itemtype='#'><span itemprop='title'><b>Cargo Tracking</b></span></span>
    </div>
</div>

<div id="BreadcrumbWrapper" class="FL HMenu" style="margin-top: 0px;">
<div class="section group"><br>

<h1 style="font-size: 18pt; font-family: 'open sans'; color: #3b3b3b;  font-weight: 600;">
    Cargo Tracking</h1><br>
    
    <div id="cez-tracker"></div>

<!--<div class="gray-box" style="width: 900px;">-->
<!--<div class="gray-box-in">-->
<!--<div id="indexTAbs" class="w100per">-->
<!--<div class="index-tabs" style="height: 50px;">-->
<!--    <ul>-->
<!--        <li class="active" style="width: 49.6%; height: 50px;">-->
<!--            <a href="javascript:void(0);" rel="indexTAbs-1"-->
<!--               style="font-family: 'open sans'; font-size: 11pt; font-weight: 700;">Air-->
<!--                Tracking</a>-->
<!--        </li>-->
<!--        <li class="last" style="width: 50.4%;">-->
<!--            <a href="javascript:void(0);" rel="indexTAbs-2"-->
<!--               style="font-family: 'open sans'; position: relative; font-size: 11pt; font-weight: 700;">Sea Tracking</a>-->
<!--        </li>-->
<!--    </ul>-->
<!--</div>-->
<!--<div class="index-tabs-detail">-->
<!--<div class="it-dtl" id="indexTAbs-1">-->
<!--<div style="width: 900px;">-->
<!--    <span style="position: relative; top:20px; left: 20px; right:20px;"> Through this online tracking facility you can get real time status information on your shipment. Simply select the airline, verify or change the prefix of your shipment number, enter the AWB number, click on the Submit button and this system will automatically retrieve and display the current status of your cargo.</span>-->
<!--</div>-->
<!--<br>-->

<!--<br>-->
<!--<hr style="border-bottom: 1px solid #cccccc;">-->
<!--<div style="margin: 15px 15px;">-->
<!--<div class="section group" style="padding-left: 10px;">-->
<!--<div class="col span_4_of_12">-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=EI&Pfx=053" class="resource-link"-->
<!--       class="resource-link" target="_blank">Aer Lingus </a><br>-->
<!--    <a href="http://www.aeroflot.com" class="resource-link" target="_blank">Aeroflot </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=IB&Pfx=044" class="resource-link"-->
<!--       target="_blank">Aerolineas-->
<!--        Argentinas </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=LM&Pfx=119" class="resource-link"-->
<!--       target="_blank">Air-->
<!--        ALM </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=AC&Pfx=014" class="resource-link"-->
<!--       target="_blank">Air-->
<!--        Canada </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=CA&Pfx=999" class="resource-link"-->
<!--       target="_blank">Air-->
<!--        China </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=AF&Pfx=057" class="resource-link"-->
<!--       target="_blank">Air-->
<!--        France </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=GN&Pfx=185" class="resource-link"-->
<!--       target="_blank">Air-->
<!--        Gabon </a><br>-->
<!--    <a href="http://www.AirIndia.com/" class="resource-link" target="_blank">Air India </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=JM&Pfx=201" class="resource-link"-->
<!--       target="_blank">Air-->
<!--        Jamaica </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=KM&Pfx=643" class="resource-link"-->
<!--       target="_blank">Air-->
<!--        Malta </a><br>-->
<!--    <a href="http://www.airnz.co.nz" class="resource-link" target="_blank">Air New Zealand </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=PX&Pfx=656" class="resource-link"-->
<!--       target="_blank">Air-->
<!--        Niugini </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=HM&Pfx=061" class="resource-link"-->
<!--       target="_blank">Air-->
<!--        Seychelles </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=AS&Pfx=027" class="resource-link"-->
<!--       target="_blank">Alaska-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=AZ&Pfx=055" class="resource-link"-->
<!--       target="_blank">Alitalia </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=NH&Pfx=205" class="resource-link"-->
<!--       target="_blank">All-->
<!--        Nippon Airways </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=AA&Pfx=001" class="resource-link"-->
<!--       target="_blank">American-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=AN&Pfx=090" class="resource-link"-->
<!--       target="_blank">Ansett-->
<!--        Australia </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=OZ&Pfx=988" class="resource-link"-->
<!--       target="_blank">Asiana-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=XM&Pfx=524" class="resource-link"-->
<!--       target="_blank">Australian-->
<!--        Air-->
<!--        Express </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=OS&Pfx=257" class="resource-link"-->
<!--       target="_blank">Austrian-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=LZ&Pfx=196" class="resource-link"-->
<!--       target="_blank">Balkan-Bulgarian-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=BG&Pfx=997" class="resource-link"-->
<!--       target="_blank">Biman-->
<!--        Bangladesh </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=BA&Pfx=125" class="resource-link"-->
<!--       target="_blank">British-->
<!--        Airways </a><br>-->
<!--        <a href="https://www.brusselsairlines.com/en-us/b2b/info-and-services/cargo/track-and-trace.aspx" class="resource-link"-->
<!--       target="_blank">Brussels Airways</a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=BW&Pfx=106" class="resource-link"-->
<!--       target="_blank">BWIA </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=UY&Pfx=604" class="resource-link"-->
<!--       target="_blank">Cameroon-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=CP&Pfx=018" class="resource-link"-->
<!--       target="_blank">Canadian-->
<!--        Airlines-->
<!--        International </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=CV&Pfx=172" class="resource-link"-->
<!--       target="_blank">Cargolux-->
<!--        Airlines </a><br>-->
<!--    <a href="https://www.cathaypacificcargo.com" class="resource-link"-->
<!--       target="_blank">Cathay Pacific-->
<!--        Airways</a><br>-->
<!--    <a href="https://cargo.china-airlines.com/CCNet/pgHome/index.aspx?userLang=en-US" class="resource-link"-->
<!--       target="_blank">China Airlines </a><br>-->
<!--</div>-->
<!--<div class="col span_4_of_12">-->

    
    
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=MU&Pfx=781" class="resource-link"-->
<!--       target="_blank">China-->
<!--        Eastern-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.unitedcargo.com" class="resource-link" target="_blank">Continental Airlines</a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=OK&Pfx=064" class="resource-link"-->
<!--       target="_blank">CSA-->
<!--        Czech Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=CY&Pfx=048" class="resource-link"-->
<!--       target="_blank">Cyprus-->
<!--        Airways </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=DL&Pfx=006" class="resource-link"-->
<!--       target="_blank">Delta-->
<!--        Air Lines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=P7&Pfx=215" class="resource-link"-->
<!--       target="_blank">East-->
<!--        Line Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=MS&Pfx=077" class="resource-link"-->
<!--       target="_blank">Egyptair </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=LY&Pfx=114" class="resource-link"-->
<!--       target="_blank">El-->
<!--        Al Israel-->
<!--        Airlines </a><br>-->
<!--    <a href="https://skychain.emirates.com/skychain/app?service=page/nwp:Login" class="resource-link"-->
<!--       target="_blank">Emirates-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=ET&Pfx=071" class="resource-link"-->
<!--       target="_blank">Ethiopian-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=BR&Pfx=695" class="resource-link"-->
<!--       target="_blank">EVA-->
<!--        Airways </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=FX&Pfx=023" class="resource-link"-->
<!--       target="_blank">Fedex </a><br>-->
    
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=AY&Pfx=105" class="resource-link"-->
<!--       target="_blank">Finnair </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=GA&Pfx=126" class="resource-link"-->
<!--       target="_blank">Garuda-->
<!--        Indonesia </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=GF&Pfx=072" class="resource-link"-->
<!--       target="_blank">Gulf-->
<!--        Air Company </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=CX&Pfx=043" class="resource-link"-->
<!--       target="_blank">Hong-->
<!--        Kong Dragonair</a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=IB&Pfx=075" class="resource-link"-->
<!--       target="_blank">Iberia </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=FI&Pfx=108" class="resource-link"-->
<!--       target="_blank">Icelandair </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=IR&Pfx=096" class="resource-link"-->
<!--       target="_blank">Iran-->
<!--        Air </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=JD&Pfx=234" class="resource-link"-->
<!--       target="_blank">Japan-->
<!--        Air Systems </a><br>-->
<!--    <a href="http://www.jal.co.jp/jalcargo/" class="resource-link" target="_blank">Japan Airlines </a><br>-->
<!--    <a href="http://www.kencargo.com" class="resource-link" target="_blank">Ken Cargo </a><br>-->
<!--    <a href="http://www.af-klm.com/cargo/portalb2b/track-trace" class="resource-link" target="_blank">KLM </a><br>-->
<!--    <a href="http://63.65.254.20/TRACKING/" class="resource-link" target="_blank">Kitty Hawk </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=KE&Pfx=180" class="resource-link"-->
<!--       target="_blank">Korean-->
<!--        Air Lines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=KU&Pfx=229" class="resource-link"-->
<!--       target="_blank">Kuwait-->
<!--        Airways </a><br>-->
<!--    <a href="" class="resource-link" target="_blank">Lan Chile </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=OS&Pfx=231" class="resource-link"-->
<!--       target="_blank">Lauda-->
<!--        Air </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=LO&Pfx=080" class="resource-link"-->
<!--       target="_blank">LOT-Polish-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.lufthansacargo.com/" class="resource-link" target="_blank">Lufthansa Cargo </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=MH&Pfx=232" class="resource-link"-->
<!--       target="_blank">Malaysia-->
<!--        Airlines</a><br>-->
<!--    <a href="http://www.malev.hu" class="resource-link" target="_blank">Malev Hungarian Airlines </a><br>-->
    
<!--</div>-->
<!--<div class="col span_4_of_12">-->
<!--<a href="http://www.cargoserv.com/tracking.asp?Carrier=KZ&Pfx=933" class="resource-link"-->
<!--       target="_blank">Nippon Cargo Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=NW&Pfx=012" class="resource-link"-->
<!--       target="_blank">Northwest-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=OA&Pfx=050" class="resource-link"-->
<!--       target="_blank">Olympic-->
<!--        Airways </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=PK&Pfx=214" class="resource-link"-->
<!--       target="_blank">Pakistan-->
<!--        International-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=PR&Pfx=079" class="resource-link"-->
<!--       target="_blank">Philippine-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=QF&Pfx=081" class="resource-link"-->
<!--       target="_blank">Qantas-->
<!--        Airways </a><br>-->
<!--        <a href="http://www.qrcargo.com/trackshipment" class="resource-link" target="_blank">Qatar Airways</a><br>-->
    <!--<a href="http://www.traxon.com/ram.htm" class="resource-link" target="_blank">Royal Air Maroc </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=BI&Pfx=672" class="resource-link"-->
<!--       target="_blank">Royal-->
<!--        Brunei-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=RJ&Pfx=512" class="resource-link"-->
<!--       target="_blank">Royal-->
<!--        Jordanian </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=SN&Pfx=082" class="resource-link"-->
<!--       target="_blank">Sabena </a><br>-->
<!--    <a href="http://www.sascargo.com/" class="resource-link" target="_blank">SAS </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=S2&Pfx=705" class="resource-link"-->
<!--       target="_blank">Sahara-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=SV&Pfx=065" class="resource-link"-->
<!--       target="_blank">Saudi-->
<!--        Arabian-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.siacargo.com" class="resource-link" target="_blank">Singapore-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=SA&Pfx=083" class="resource-link"-->
<!--       target="_blank">South-->
<!--        African-->
<!--        Airways </a><br>-->
<!--    <a href="http://www.southfloridacargo.com/" class="resource-link" target="_blank" class="resource-link"-->
<!--       target="_blank">South Florida Air Cargo </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=UL&Pfx=603" class="resource-link"-->
<!--       target="_blank">SriLankan-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=SR&Pfx=085" class="resource-link"-->
<!--       target="_blank">Swissair </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=RB&Pfx=070" class="resource-link"-->
<!--       target="_blank">Syrian-->
<!--        Arab Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=TP&Pfx=047" class="resource-link"-->
<!--       target="_blank">TAP-Air-->
<!--        Portugal </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=TG&Pfx=217" class="resource-link"-->
<!--       target="_blank">Thai-->
<!--        Airways Intl.-->
<!--        Ltd. </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=TL&Pfx=270" class="resource-link"-->
<!--       target="_blank">Trans-->
<!--        Mediterranean Airways </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=TW&Pfx=015" class="resource-link"-->
<!--       target="_blank">Trans-->
<!--        World Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=TH&Pfx=539" class="resource-link"-->
<!--       target="_blank">Transmile-->
<!--        Air-->
<!--        Services </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=TK&Pfx=235" class="resource-link"-->
<!--       target="_blank">Turkish-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=PS&Pfx=566" class="resource-link"-->
<!--       target="_blank">Ukraine-->
<!--        International-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=UA&Pfx=016" class="resource-link"-->
<!--       target="_blank">United-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.usairwayscargo.com/cargo/services/" class="resource-link" target="_blank">US-->
<!--        Airways </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=RG&Pfx=042" class="resource-link"-->
<!--       target="_blank">Varig </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=VN&Pfx=738" class="resource-link"-->
<!--       target="_blank">Vietnam-->
<!--        Airlines </a><br>-->
<!--    <a href="http://www.cargoserv.com/tracking.asp?Carrier=XS&Pfx=950" class="resource-link"-->
<!--       target="_blank">Test-->
<!--        Carrier - QIF </a><br>-->
    
<!--</div>-->
<!--<br>-->
<!--</div>-->
<!--</div>-->
<!--</div>-->
<!--<div class="it-dtl" id="indexTAbs-2" style="display:none;">-->
<!--<div class="bestseller-newlyadded" style="margin: 5px 10px 5px 25px; width: 660px; ">-->
<!--<div class="wrapper">-->
<!--<ul>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.apl.com/wps/portal/apl" target="_blank"><img src="source/images/sea-tracking/apl.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">APL</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="https://www.anl.com.au/" target="_blank"><img src="source/images/sea-tracking/anl.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">ANL</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.aclcargo.com/" target="_blank"><img src="source/images/sea-tracking/acl.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">ACL</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.shipmentlink.com/servlet/TDB1_CargoTracking.do" target="_blank"><img src="source/images/sea-tracking/bcl.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">BCL</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.shipmentlink.com/servlet/TDB1_CargoTracking.do" target="_blank"><img src="source/images/sea-tracking/bernuth.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Bernuth Lines</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.shipmentlink.com/servlet/TDB1_CargoTracking.do" target="_blank"><img src="source/images/sea-tracking/csal.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">CSAL</span>-->
<!--    </li>-->
<!--</ul>-->
<!--<ul style="padding-top: 10px;">-->

<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://ecom.ccni.cl/ecom/en/ecommerce_portal_ccni/track_trace_1/track__trace_1/ep_trackandtrace.xhtml?lang=EN" target="_blank"><img src="source/images/sea-tracking/ccni.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">CCNI</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.shipmentlink.com/servlet/TDB1_CargoTracking.do" target="_blank"><img src="source/images/sea-tracking/cscl.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">CSCL</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.cma-cgm.com/" target="_blank"><img src="source/images/sea-tracking/cma-cgm.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">CMA CGM</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://ebusiness.coscon.com/wps/portal/" target="_blank"><img src="source/images/sea-tracking/cosco.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">COSCO</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.shipmentlink.com/servlet/TDB1_CargoTracking.do" target="_blank"><img src="source/images/sea-tracking/crowley.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Crowley</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.shipmentlink.com/servlet/TDB1_CargoTracking.do" target="_blank"><img src="source/images/sea-tracking/dan-gulf.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">DAN GULF</span>-->
<!--    </li>-->
<!--</ul>-->
<!--<ul style="padding-top: 10px;">-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="https://www.delmas.com/ebusiness/tracking" target="_blank"><img src="source/images/sea-tracking/delmas.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Delmas</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.eukor.com/homepage/eukor/customer_tracking.jsp" target="_blank"><img src="source/images/sea-tracking/eukor.png" alt=""-->
<!--                                                                                                 style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Eukor</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.shipmentlink.com/servlet/TDB1_CargoTracking.do" target="_blank"><img src="source/images/sea-tracking/evergreen.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Evergreen</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.fesco.ru/en/clients/tracking/" target="_blank"><img src="source/images/sea-tracking/fesco.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Fesco</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.shipmentlink.com/servlet/TDB1_CargoTracking.do" target="_blank"><img src="source/images/sea-tracking/gearbulk.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Gearbulk</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="https://ecom.hamburgsud.com/ecom/en/ecommerce_portal/track_trace/track__trace/ep_trackandtrace.xhtml?lang=EN" target="_blank"><img src="source/images/sea-tracking/hamburg.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Hamburg</span>-->
<!--    </li>-->
<!--</ul>-->
<!--<ul style="padding-top: 10px;">-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.hapag-lloyd.com/en/home.html" target="_blank"><img src="source/images/sea-tracking/hapag.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Hapag-Lloyd</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.hoeghautoliners.com/customer-center/customer-center-menu/my-cargo" target="_blank"><img src="source/images/sea-tracking/hoegh.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Hoegh</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.shipmentlink.com/servlet/TDB1_CargoTracking.do" target="_blank"><img src="source/images/sea-tracking/horizon.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Horizon</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.hmm.co.kr/cms/company/engn/index.jsp" target="_blank"><img src="source/images/sea-tracking/hmm.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">HMM</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://ecom.kline.com/tracking" target="_blank"><img src="source/images/sea-tracking/k-line.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">"K" Line</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.maerskline.com/en-us/" target="_blank"><img src="source/images/sea-tracking/maersk.png" alt=""-->
<!--                                                                        style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Mearsk</span>-->
<!--    </li>-->

<!--</ul>-->
<!--<ul style="padding-top: 10px;">-->
    
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="https://www.matson.com/vcsc/VisibilityController" target="_blank"><img src="source/images/sea-tracking/matson.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Matson</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.mscgva.ch/tracking/index.html" target="_blank"><img src="source/images/sea-tracking/msc.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">MSC</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://cms.molpower.com/" target="_blank"><img src="source/images/sea-tracking/mol.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">MOL</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.bahri.sa/Online-Services.aspx" target="_blank"><img src="source/images/sea-tracking/nscsa.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">NSCSA</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.nordana.com/Equipment/USA%20Track%20,-a-,%20Trace.aspx" target="_blank"><img src="source/images/sea-tracking/nordana.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Nordana</span>-->
<!--    </li>-->
<!--<li style="height: 155px; width: 127px;">-->
<!--        <a href="https://ecomm.one-line.com/ecom/CUP_HOM_3301.do" target="_blank"><img src="source/images/sea-tracking/nyk.png" alt=""-->
<!--                                                                 style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">NYK</span>-->
<!--    </li>-->
<!--</ul>-->
<!--<ul style="padding-top: 10px;">-->
    
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.oocl.com/eng/ourservices/eservices/trackandtrace/pages/default.aspx" target="_blank"><img src="source/images/sea-tracking/oocl.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">OOCL</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="https://www.pilship.com/en-our-track-and-trace-pil-pacific-international-lines/120.html" target="_blank"><img src="source/images/sea-tracking/pil.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">PIL</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.shipmentlink.com/servlet/TDB1_CargoTracking.do" target="_blank"><img src="source/images/sea-tracking/pfl.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">PFL</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.shipmentlink.com/servlet/TDB1_CargoTracking.do" target="_blank"><img src="source/images/sea-tracking/rickmers.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Rickmers</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="https://www.safmarine.com/" target="_blank"><img src="source/images/sea-tracking/safmarine.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Safmarine</span>-->
<!--    </li>-->
<!--<li style="height: 155px; width: 127px;">-->
<!--        <a href="http://portal.seastarline.com/Account/Login?ReturnUrl=%2f" target="_blank"><img src="source/images/sea-tracking/sea-star.png" alt=""-->
<!--                                                                                                 style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Sea Star</span>-->
<!--    </li>-->
<!--</ul>-->
<!--<ul style="padding-top: 10px;">-->
    
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="https://portal.totemaritime.com/Account/Login?ReturnUrl=%2f" target="_blank"><img src="source/images/sea-tracking/tote.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">TOTE</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.shipmentlink.com/servlet/TDB1_CargoTracking.do" target="_blank"><img src="source/images/sea-tracking/trinity.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Trinity</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.tropical.com/external/en/" target="_blank"><img src="source/images/sea-tracking/tropical.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Tropical</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://uasconline.uasc.net/Home" target="_blank"><img src="source/images/sea-tracking/uasc.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">UASC</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="https://www.uslines.com/ebusiness/tracking" target="_blank"><img src="source/images/sea-tracking/usl.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">U.S Lines</span>-->
<!--    </li>-->
<!--<li style="height: 155px; width: 127px;">-->
<!--        <a href="https://www.2wglobal.com/webapps?frameId=149791475933839181&url=https%3A%2F%2Fatt.2wglobal.com%2Fgstattweb%2Focean.do%3Fmethod%3DgetDefaultOceanQuickSearchPage-->
<!--" target="_blank"><img src="source/images/sea-tracking/wwl.png" alt=""-->
<!--                                                                                                 style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">WWL</span>-->
<!--    </li>-->
<!--</ul>-->
<!--<ul style="padding-top: 10px;">-->
    
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.wanhai.com/views/cargoTrack/CargoTrack.xhtml" target="_blank"><img src="source/images/sea-tracking/wan-hai.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">WAN HAI</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.yangming.com/e-service/Track_Trace/track_trace_cargo_tracking.aspx-->
<!--" target="_blank"><img src="source/images/sea-tracking/yang-ming.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">Yang Ming</span>-->
<!--    </li>-->
<!--    <li style="height: 155px; width: 127px;">-->
<!--        <a href="http://www.zim.com/pages/default.aspx" target="_blank"><img src="source/images/sea-tracking/zim.png" alt=""-->
<!--                         style="width: 110px; height: 120px; padding-bottom: 5px;"></a>-->
<!--        <span style="font-size: 10pt; font-weight: 600; margin-top: 5px;">ZIM</span>-->
<!--    </li>-->
<!--</ul>-->
<!--</div>-->
<!--</div>-->
<!--</div>-->

<!--</div>-->
<!--</div>-->
<!--</div>-->
<!--</div>-->


<script>
    $(document).ready(function () {
        $('#indexTAbs .index-tabs li a').bind("click", function () {
            $('#indexTAbs .index-tabs li ').removeClass('active');
            $(this).parent().addClass('active');
            $('#indexTAbs-1, #indexTAbs-2, #indexTAbs-3').hide();
            var show2Tab = $('#' + $(this).attr('rel'));
            setTimeout(function () {
                show2Tab.show();
            });
        });
    });
</script>

<script src="https://cargoez.com/api/v1/cargoez.js"></script>

</div>
</div>
</div>
</div>
<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" lang="en">


<head>
    <!--Start of Zopim Live Chat Script
    <script type="text/javascript">
        window.$zopim || (function (d, s) {
            var z = $zopim = function (c) {
                z._.push(c)
            }, $ = z.s =
                d.createElement(s), e = d.getElementsByTagName(s)[0];
            z.set = function (o) {
                z.set.
                    _.push(o)
            };
            z._ = [];
            z.set._ = [];
            $.async = !0;
            $.setAttribute('charset', 'utf-8');
            $.src = '//v2.zopim.com/?2NBKvMLseKA8C45Gr5ywmelLErtAkht6';
            z.t = +new Date;
            $.
                type = 'text/javascript';
            e.parentNode.insertBefore($, e)
        })(document, 'script');
    </script>
    End of Zopim Live Chat Script-->
    
    <!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = '3kWxTfUv3x';var d=document;var w=window;function l(){
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
<!-- {/literal} END JIVOSITE CODE -->

    <link href="source/css/sole.css" rel="stylesheet">

<body class="vpform pgTrustPilot" lang="en-GB" align="center">


<div id="footerinfo" style="width: 100%; background-color: #cccccc" align="center">
    <div style="width: 980px; background-color: #ffffff; padding: 10px 0px;" align="left">
        <div id="BreadcrumbWrapper">
            <div class="section group">
                <div class="col span_12_of_12" style="line-height: 23px; border-right: 1px solid #dddddd; ">
                </div>
            </div>
            <hr>
        </div>
        <img src="source/images/logos.jpg" alt="" style="width: 980px;">
        <div style="margin-left:40px;">
            <a id="bbblink" class="ruvtbum" target="_blank" href="https://www.bbb.org/us/ca/milpitas/profile/logistics/air-7-seas-transport-logistics-1216-213698#bbbseal"
        title="AIR 7 SEAS Transport Logistics Inc, Logistics, Milpitas, CA"
        style="display: block;position: relative;overflow: hidden; width: 60px; height: 108px; margin: 0">
        <img style="padding: 0px; border: none;" id="bbblinkimg" src="https://seal-sanjose.bbb.org/logo/ruvtbum/air-7-seas-transport-logistics-213698.png" width="120" height="108" alt="AIR 7 SEAS Transport Logistics Inc, Logistics, Milpitas, CA" />
        </a>    
        </div>
        
        <script type="text/javascript">var bbbprotocol = ( ("https:" == document.location.protocol) ? "https://" : "http://" ); (function(){var s=document.createElement('script');s.src=bbbprotocol + 'seal-sanjose.bbb.org' + unescape('%2Flogo%2Fair-7-seas-transport-logistics-213698.js');s.type='text/javascript';s.async=true;var st=document.getElementsByTagName('script');st=st[st.length-1];var pt=st.parentNode;pt.insertBefore(s,pt.nextSibling);})();
        </script>
    </div>
</div>
<!--footer-->
<footer style="background-color: #4d4d4d">
    <div class="DB MMdLFtR">
        <div class="FL DB MMdLFtRa" style="padding-left: 75px;">

            <div id="FtR" class="LH20 footer-links">
                <div class="left-section FL">
                    <div class="left-wrapper FL">
                        <section class="ordering-fromus">
                            <div class="title">
                                AIR 7 SEAS
                            </div>
                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="about-air7seas.php" id="aContact">About Us</a>
                                    <a href="feedback.php" id="aFAQ">Feedback</a>
                                    <a href="shipping-news.php" id="aOrdertracking">News &amp;
                                        Events</a>
                                    <a href="#">Privacy Policy</a>
                                    <a href="terms-and-conditions.php">Terms &amp;
                                        Conditions</a>
                                    <a href="jobs.php">Jobs</a>
                                </li>
                            </ul>
                        </section>
                        <section class="help-support">
                            <div class="title">
                                SERVICES
                            </div>

                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="international-freight.php">International &#45;
                                        Freight</a>
                                    <a href="domestic-freight.php">Domestic &#45;
                                        Freight</a>
                                    <a href="autos-vehicles-machinery.php">Machinery &amp; Vehicles</a>
                                    <a href="freight-forwarder.php">Freight Forwarding</a>
                                    <a href="customs-release.php">Customs Release</a>
                                    <a href="moving.php">Movers</a>
                                </li>
                            </ul>
                        </section>
                        <section class="information">
                            <div class="title">
                                SUPPORT
                            </div>
                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="faq.php">Frequently Asked Questions</a>
                                    <a href="moving-tips.php">Moving Tips</a>

                                    <a href="payments.php" id="aFreeRecycle">Payment Options</a>
                                    <a href="procedural-steps-for-claim-submition.php">Claim
                                        Submission Procedures</a>
                                    <a href="isf.php">Importer Security Filing (ISF)</a>
                                    <a href="order-online-insurance.php">Order Online -
                                        Insurance</a>

                                </li>
                            </ul>
                        </section>
                    </div>
                    <div class="social-links">


                    </div>
                </div>
                <section class="newsletter">
                    <div class="title">CORPORATE OFFICE</div>
                    <div class="footer-contact">
                        <ul>
                            <li class="f-map"><a
                                    href="contact-us.php"
                                    target="_blank">1815 Houret Court, <br> Milpitas, CA 95035, US</a></li>
                            <li class="f-phone"><span><a href="tel:+18882477732">Call Us: 1-888-247-7732</a></span></li>
                            <li class="f-mail"><a href="mailto:info@air7seas.us">info (@) air7seas.us</a></li>
                        </ul>
                    </div>
                    <br><br>

                    <div>
                        <a href="https://www.facebook.com/pages/Air7Seas-Transport-Logistics-Inc/731149066945233" target="_blank">
                            <img src="source/images/icons/fb.png" style="margin-top: 7px; width: 25px;">
                        </a>&nbsp;
                        <a href="https://twitter.com/Air7seas" target="_blank">
                            <img src="source/images/icons/twitter.png" style="margin-top: 7px; width: 25px;">
                        </a>&nbsp;
                        <a href="https://www.google.com/maps/place/AIR+7+SEAS+Transport+Logistics+Inc/@37.405497,-121.8994427,17z/data=!3m1!4b1!4m5!3m4!1s0x808fceb215c020c3:0x183384c4fb534d3c!8m2!3d37.405497!4d-121.897254" target="_blank">
                            <img src="source/images/icons/gp.png" style="margin-top: 7px; width: 25px;">
                        </a>
                    </div>

                </section>
            </div>
        </div>
    </div>

</footer>

<div class="baseline-footer">
    <div class="baseline-footer-wrapper">
        <section class="FL" itemprop="provider" itemscope itemtype="http://schema.org/Organization">
            <div class="FL">

                <meta itemprop="url" content="http://www.air7seas.com/"/>
                <meta itemprop="name" content="Air 7 Seas Transport Logistics Pvt Ltd"/>
                <meta itemprop="email" content="info@air7seas.com "/>
                <div itemprop="location" itemscope itemtype="http://www.schema.org/LocalBusiness">

                    <meta itemprop="openingHours" content="Mo-Fr 08:00-16:00"/>
                    <meta itemprop="openingHours" content="Sa-Su Holiday"/>
                    <div itemprop="geo" itemscope itemtype="http://schema.org/GeoCoordinates">
                        <meta itemprop="latitude" content="53.55519"/>
                        <meta itemprop="longitude" content="-3.041651"/>
                    </div>
                </div>

            </div>
            <div class="contact-information">
                <div id="pnlUKFooter">

                    <div class="address" itemprop=address itemscope itemtype=http://schema.org/PostalAddress>
                        <span class="address-image"></span>

                        <div class="address-wrapper">
                            <span itemprop=streetAddress><a href="contact-us.php" style="color: #cfcfcf;">1815 Houret
                                    Court,<br> Milpitas, CA 95035</a></span>,
                            <span itemprop=addressLocality>USA</span>
                        </div>
                    </div>
                    <div class="phone-number">
                        <span class="phone-image"></span>
                        <span class="telephone" itemprop=telephone><a href="tel:+18882477732" style="color: #cfcfcf;">1-888-247-7732</a></span>
                        <span class="sales-support">(Customer Support)</span>
                    </div>
                    <div class="email-address">
                        <span class="email-img"></span>
                        <span itemprop=email><a class="mail-id"
                                                href="mailto:info@air7seas.us">info (@) air7seas.us</a></span>
                    </div>


                </div>

            </div>
        </section>


        <div itemprop="copyrightHolder" itemscope itemtype="http://www.schema.org/Organization"
             class="copywrite-holder">
            <meta itemprop="url" content="http://www.air7seas.com/"/>
            <meta itemprop="name" content="Air 7 Seas Transport Logistics Pvt Ltd"/>

            <meta itemprop="email" content="info@air7seas.com "/>

            Copyright <span class="copyrights">&copy;</span> AIR 7 SEAS 2014 &#45; 2015
        </div>
        <meta itemprop="copyrightYear" content="1986-2014"/>

        <div class="divAuthorisedText">Authorised and regulated by AIR 7 SEAS 95035</div>


    </div>
</div>

</body>
</html>

</body>
</html>
