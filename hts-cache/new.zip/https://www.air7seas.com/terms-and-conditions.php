<!DOCTYPE html>
<html>
<head>
    <title>Terms &amp; Conditions - AIR 7 SEAS</title>
    <link rel="shortcut icon" href="source/images/a7s-icon.ico"/>
    <meta charset="utf-8"/>
    <meta name="description"
          content="Air 7 seas is leading Freight Forwarder, NVOCC, OTI, Cargo Consolidator, Custom Broker, Carrier, and Shipping Agents for Ship Lines, Airlines, Truckers, Shipper & Consignee to handle International and Domestic transportation by Air Freight, Sea Freight or Road Freight.">
    <meta name="description"
          content="Air 7 Seas Overseas Relocation, Air 7 Seas Moving Overseas, Air 7 Seas Relocation Services, Air 7 Seas Shipping India, Air 7 Seas Shipping USA, Air 7 Seas Freight Forwarder, Air 7 Seas Air Freight, Air 7 Seas Air Cargo, Air 7 Seas Customs Clearance, Air 7 Seas International Shipping Companies, Air 7 Seas Moving Estimate, Air 7 Seas Shipping Quote, Air 7 Seas Moving International, Air 7 Seas Domestic Movers, Air 7 Seas Shipping Agent, Air 7 Seas Shipping International, Air 7 Seas International Moving Service, Air 7 Seas Cargo Agent, Air 7 Seas Customs Broker, Air 7 Seas International Mover, Air 7 Seas Household Goods, Air 7 Seas Commercial Goods, Air 7 Seas Breakbulk Cargo, Air 7 Seas Car Shipping, Air 7 Seas Motorbike Shipping, Air 7 Seas Auto Vehicle Mechinery, Air 7 Seas Cargo Consolidation, Air 7 Seas Freight Service Provider">
    <meta name="keywords"
          content="Overseas Relocation, Moving Overseas, Relocation Services, Shipping India, Shipping USA, Freight Forwarder, Air Freight, Air Cargo, Customs Clearance, International Shipping Companies, Moving Estimate, Shipping Quote, Moving International, Domestic Movers, Shipping Agent, Shipping International, International Moving Service, Cargo Agent, Customs Broker, International Mover, Household Goods, Commercial Goods, Breakbulk Cargo, Car Shipping, Motorbike Shipping, Auto Vehicle Mechinery, Cargo Consolidation, Freight Service Provider">
    <meta name="author" content="Air 7 Seas Transport Logistics Pvt Ltd">
    <!--  <base href="http://www.air7seas.com/"> -->

    <link href="source/css/responsive.css" rel="stylesheet">
    <link href="source/css/sole.css" rel="stylesheet" type="text/css" visible="true"/>

    <style type="text/css">

        ul.ff-service {
            font-size: 9pt;
            padding-left: 25px;
        }

        ul.ff-service li {
            margin: 10px;
            line-height: 1.5;
            list-style: square;
        }

        ol.tc-ocean-freight {
            font-size: 9pt;
            padding-left: 25px;
        }

        ol.tc-ocean-freight li {
            margin: 10px;
            line-height: 1.5;
        }

        ul.tc-international {
            font-size: 9pt;
            padding-left: 25px;
        }

        ul.tc-international li {
            margin: 10px 0 0 10px;
            line-height: 1.5;
            list-style: decimal;
        }

        p, h4 {
            margin: 10px 0px;
        }
    </style>
    <script type="text/javascript">
        function tcLoad(selected) {
            document.getElementById("freight-forward-tc").style.display = "none";
            document.getElementById("domestic-tc").style.display = "none";
            document.getElementById("intl-air-freight-tc").style.display = "none";
            document.getElementById("ocean-freight-tc").style.display = "none";
            document.getElementById("privacy-policy-tc").style.display = "none";
            document.getElementById("warehouse-limitation-tc").style.display = "none";
            document.getElementById("web-design-tc").style.display = "none";
            document.getElementById("slavery-human-trafficking-tc").style.display = "none";

            document.getElementById(selected).style.display = "block";
        }
    </script>

    <script>
        /*(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

        ga('create', 'UA-54008281-2', 'auto');
        ga('send', 'pageview');*/

    </script>

</head>
<body>
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link href="source/css/sole.css" rel="stylesheet" type="text/css" visible="true"/>
    <link href="source/css/skin.css" rel="stylesheet" type="text/css" visible="true"/>

    <link
        href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800'
        rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="source/css/megadrop.css"/>
    <script type="text/javascript" src="source/js/megascripts.js"></script>
    <style>
        .searchbox {
            height: 28px;
            width: 225px;
            border: 1px solid #dadada;
            border-top-left-radius: 3px;
            border-bottom-left-radius: 3px;
            padding-left: 10px;
            font-size: 12px;
            color: #9b9b9b
        }

        .searchbutton {
            cursor: pointer;
            background-image: url('source/images/search.GIF');
            height: 30px;
            width: 70px;
            margin-top: 0;
            color: transparent
        }

        .txtSearchbox::-webkit-input-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox:-moz-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox::-moz-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox:-ms-input-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }
    </style>
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NQDLZPP');</script>
<!-- End Google Tag Manager -->
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NQDLZPP"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div id="topLine">
</div>
<div id="main-header" align="center" style="font-family: Arial;">
    <div id="main-header-area" align="left">
        <a href="index.php">
            <img src="source/images/logo-new.png" alt="Air 7 Seas" style="float: left; position: relative;"></a>

        <div class="top-small-link" style=" vertical-align: middle">
            <table border="0">
                <tr style="vertical-align: top">
                    <td style="padding-top: 3px;">
                        <a href="cargo-tracking.php" style="color: #404040; font-family: Arial;"><b>Cargo
                                Tracking</b></a>|
                        <a href="about-air7seas.php">About Us</a>|
                        <a href="https://portal.cargoez.com/air7seas/login" target="_blank">Login</a>|
                        <a href="shipping-news.php">News &amp; Events</a>

                    </td>
                    <td style="vertical-align: top;"><img src="source/images/phone-ico.PNG" alt=""
                                                          style="margin-top: 0px;">
                    </td>
                    <td style="padding: 3px 0 0 5px; width: 185px;">
                        <span style="font-size: 13pt; float: right"><span style="font-size: 9pt;">Toll Free:</span>
                        <a href="tel:+18882477732"
                           style="padding-left: 0px; padding-right: 0px; margin-right: 0px; color: #026799;"><b>1-888-247-7732<b/></a></span>
                    </td>

                </tr>
                <tr>
                    <td colspan="3" style="">
                        <div id="SrCl" style="padding-top: 8px; float: right">
                            <form method="post" action="search-results.php">

                                <input type="text" id="find" name="find" autocomplete="off"
                                       class="searchbox txtSearchbox" placeholder="How can i help you...?">
                                <input type="submit" name="" style="border:0px; height: 28px;" class="searchbutton"
                                       alt="Search"/>

                            </form>
                        </div>
                    </td>
                </tr>
            </table>


        </div>


    </div>
</div>
<div id="menu-bar" style="width: 100%; background-color: #1e6a89;" align="center">
<div style="width: 980px;" align="left">
<ul class="nav-mainmenu clearfix animated">
<li><a href="index.php">Home</a></li>
<li>
    <a href="#">Services</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px; ">

            <ul class="menu-items">
                <li class="seperator"><a href="international-freight.php" style="font-weight: 600">International
                        Freight</a></li>
                <li class="seperator"><a href="domestic-freight.php">Domestic Freight</a></li>
                <li class="seperator"><a href="freight-forwarder.php">Freight Forwarding</a></li>
                <li class="seperator"><a href="freight-consultation.php">Consultation</a></li>

            </ul>
        </div>
    </div>
</li>
<li><a href="#">Products</a>

    <div class="container-2" style="width: 500px;">
        <table border="0">
            <tr>
                <td style="border-right:1px solid #ccc; vertical-align: top;">
                    <div class="col1" style="width: 250px;">

                        <ul class="menu-items">


                            <li class="seperator"><a href="shipping-to-vietnam.php"><img
                                        src="source/images/Vietnam-Flag-icon.png" alt="Vietnam Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Saigon Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-india.php"><img
                                        src="source/images/India-Flag-icon.png" alt="India Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">India Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-middle-east.php"><img
                                        src="source/images/MiddleEast-Flag-icon.png" alt="Shipping to Middle East"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Middle East Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-china.php"><img
                                        src="source/images/China-Flag-icon.png" alt="China Shipper"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">China Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-philippines.php"><img
                                        src="source/images/Philippines-Flag-icon.png" alt="Philippines Shipper"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Manila Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-spain.php"><img
                                        src="source/images/Spain-Flag-icon.png" alt="Spain Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Spain Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-mexico.php"><img
                                        src="source/images/Mexico-Flag-icon.png" alt="Mexico Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Mexico Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="autos-to-canada.php"><img
                                        src="source/images/Canada-Flag-icon.png" alt="Canada Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Autos to Canada</span></a>
                            </li>
  <li class="seperator"><a href="importers-logistics-rep.php">Importer&#39;s Rep</a></li>

                        </ul>
                    </div>
                </td>
                <td style="vertical-align: top;">
                    <div class="col1" style="width: 250px;">

                        <ul class="menu-items">
                            <li class="seperator"><a href="shipping-to-africa.php">
                                    <img src="source/images/Africa-Flag-icon.png" alt="AfriCargo Express" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">AfriCargo Express</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-latin-america.php">
                                    <img src="source/images/Latino-Flag-icon.png" alt="Latino Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Latino Shipper</span></a>
                            </li>
                              <li class="seperator"><a href="nvo.php">
                                    <img src="source/images/lcl-icon.jpg" alt="Latino Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Cargo-Coloader LCL</span></a>
                            </li>
                            <li class="seperator"><a href="a7s-pre-fulfilment-service.php"><img src="source/images/receiving-center-icon.png"
                                                                                      alt="Air7seas Pre-Fulfillment Service" width="22px"
                                                                                      style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Pre-Fulfillment &amp; Delivery </span></a></li>
                            <li class="seperator"><a href="receiving-center.php"><img src="source/images/receiving-center-icon.png"
                                                                                      alt="Mexico Shipper" width="22px"
                                                                                      style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Pre-Shipping Receiving Center</span></a></li>
                            <!--<li class="seperator"><a href="receiving-center.php">Receiving Center</a></li>-->
                            <li class="seperator"><a href="partners-agents.php"><img
                                        src="source/images/partners-agents-icon.png" alt="Canada Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Partners - Agents</span></a>
                            </li>
                            <li class="seperator"><a href="autos-vehicles-machinery.php"><img
                                        src="source/images/autos-vehicle-mechinery-icon.png" alt="Mexico Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Autos Vehicles Machinery</span></a>
                            </li>
                            <li class="seperator"><a href="transloading-transhipment.php">Transloading -
                                    Transhipment</a></li>
                            <li class="seperator"><a href="ship-hazardous-perishable-goods.php">Hazardous &amp;
                                    Perishable</a></li>


                        </ul>
                    </div>
                </td>
            </tr>
        </table>


    </div>
</li>
<li><a href="#">Mover &amp; Relocation</a>

    <div class="container-4" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="move-household-goods.php">Household Goods</a></li>
                <li class="seperator"><a href="ship-commercial-goods.php">Commercial Goods</a></li>
                <!--     <li class="seperator"><a href="#">Countries served</a></li> -->
            </ul>
        </div>
    </div>
</li>
<li><a href="#">Freight Carrier</a>

    <div class="container-4" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="air-freight-carrier.php">Air Freight Carrier</a></li>
                <li class="seperator"><a href="ocean-freight-carrier.php">Ocean Freight Carrier</a>
                </li>
                <li class="seperator"><a href="soc-movements.php">SOC Movements</a></li>
            </ul>
        </div>
    </div>
</li>
<li>
    <a href="#">Customs Release</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="export-import.php"">Export - Import</a></li>
                <li class="seperator"><a href="isf.php">ISF / AMS</a></li>
                <li class="seperator"><a href="importers-logistics-rep.php">Importer&#39;s Rep</a></li>
            </ul>
        </div>
    </div>
</li>

<li><a href="#">Insurance</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="cargo-insurance-coverage-types.php">Coverage Types</a></li>
                <li class="seperator"><a href="free-estimate-insurance.php">Free Estimate - Insurance</a>
                </li>
                <li class="seperator"><a href="order-online-insurance.php">Order Online - Insurance</a></li>
                <li class="seperator"><a href="claim-submission.php">Claim submission Form</a></li>
                <li class="seperator"><a href="faq-insurance.php">FAQ</a></li>
                <!--<li class="seperator"><a href="#">Resources - Insurance</a></li>-->
                <li class="seperator"><a href="damages-to-the-goods-by-customs.php">Damages to the goods by
                        Customs</a></li>

            </ul>
        </div>
    </div>
</li>
<li><a href="#">Contact Us</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="contact-us.php">Contacts</a></li>
                <li class="seperator"><a href="free-estimatesdetails.php">Get an Estimate</a></li>
                <li class="seperator"><a href="ordernowdetails.php">Book a Shipment</a></li>
                <li class="seperator"><a href="feedback.php">Feedback</a></li>
                <li class="seperator"><a href="complaint.php">Complaint</a></li>
                <li class="seperator"><a href="customer-review.php">Testimonial</a></li>
                <li class="seperator"><a href="claim-submission.php">Claim submission</a></li>
                <li class="seperator"><a href="terms-and-conditions.php">Terms &amp; Conditions</a></li>
                <li class="seperator"><a href="jobs.php">Jobs</a></li>
            </ul>
        </div>
    </div>
</li>
<li><a href="#" class="last-list">Tools &amp; Resources</a>

    <div class="container-1 right" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="forms-downloads.php">Documents &amp; Forms</a></li>
                <li class="seperator"><a href="payments.php">Payment options</a></li>
                <li class="seperator"><a href="moving-tips.php">Moving Tips</a></li>
                <li class="seperator"><a href="container-sizes.php">Container Sizes for Sea</a></li>
                <li class="seperator"><a href="faq.php">FAQs</a></li>
                <li class="seperator"><a href="shipping-news.php">News &amp; Events</a></li>
                <li class="seperator"><a href="ask-a-question.php">Ask a question</a></li>
            </ul>
        </div>
    </div>
</li>

</ul>
</div>

</div>
<div id="info-bar" style="box-shadow: 0px 3px 3px 0px rgba(0, 0, 0, 0.15); position: relative; z-index: 100;"
     align="center">
    <div id="info-bar-area" align="left">
        <div class="top-thin-links">
            <div class="thin-links-wrapper">
                <a class="review" href="free-estimatesdetails.php"><span class="icon"></span><span>Free Shipping Estimate</span></a>
                <a class="finance" href="estimate-sizeof-shipment.php"><span
                        class="icon"></span><span>Moving Calculator</span></a>
                <a class="facebook" href="moving-tips.php"><span class="icon"></span><span>Moving Tips</span></a>
                <a class="catalogue" href="ordernowdetails.php"><span class="icon"></span><span>Order Online</span></a>
                <a class="trade-account" href="ask-a-question.php"><span class="icon"></span><span>Shipping ?</span></a>
            </div>
        </div>
    </div>
</div>

</body>
</html>
<div id="contents" align="center">
<div id="contentsArea" align="left" style="padding-left: 20px;">

<!-- Top Information Bar -->
<div id="BreadcrumbWrapper" style="width: 940px; margin-bottom: 10px;">
    <div id="Breadcrumb" class="Breadcrumb BoxSBB">
         <span itemscope itemtype='#'>
             <a href="index.php" itemprop='url' title="Air7seas Homepage">
                 <span itemprop='title'>Home</span>
             </a>
         </span>
        &rsaquo; <span itemscope itemtype='#'><span itemprop='title'><b>Contact Us</b></span></span>
        &rsaquo; <span itemscope itemtype='#'><span itemprop='title'><b>Terms &amp; Conditions</b></span></span>
    </div>

</div>
<div style="padding-left: 20px;">
    <span style="font-size: 11pt; font-weight: 600;">Terms &amp; conditions for</span>
    <select style="margin: 0px 20px 30px 20px; padding: 5px 5px; font-weight: 600; color: #444444;"
            onchange="tcLoad(this.value);">
        <option value="freight-forward-tc" selected>Freight Forwarder</option>
        <option value="domestic-tc">Domestic Air Freight</option>
        <option value="intl-air-freight-tc">International Air Freight</option>
        <option value="ocean-freight-tc">Ocean Freight</option>
        <option>Truck Limitation</option>
        <option value="warehouse-limitation-tc">Wherehouse Limitations</option>
        <option value="web-design-tc">Website Disclaimer</option>
        <option value="privacy-policy-tc">Privacy Policy</option>
        <option value="slavery-human-trafficking-tc">Slavery & Human Trafficking</option>
    </select>
</div>
<hr style="margin-right: 20px;">
<br>

<div id="BreadcrumbWrapper" class="FL HMenu" style="margin-top: 0px;">
<div class="section group">
<div class="col span_9_of_12" style="vertical-align: top; padding-right: 20px;">

<div id="freight-forward-tc" style="display: block;">
<h1 style="font-size: 18pt; font-family: 'open sans'; color: #3b3b3b; margin-bottom: 20px; font-weight: 600;">
    Freight Forwarder Terms and Conditions
</h1>

<p id="ff-0">These terms and conditions of service constitute a legally binding contract between the
    &quot;Company&quot; and the &quot;Customer&quot;. In the event the Company renders services and
    issues a document containing Terms and Conditions governing such services, the Terms and
    Conditions set forth in such other document(s) shall govern those services.</p>
<h4 class="title">1. Definitions.</h4>
<ul class="ff-service" style="background-color: #F4F4F4;">
    <li style="padding-top: 15px;">&quot;Company&quot; shall mean AIR 7 SEAS Transport Logistics Inc, its subsidiaries,
        related
        companies,
        agents and/or representatives;
    </li>
    <li>&quot;Customer&quot; shall mean the person for which the Company is rendering service, as
        well as its
        principals, agents and/or representatives, including, but not limited to, shippers,
        importers,
        exporters, carriers, secured parties, warehousemen, buyers and/or sellers, shipper's agents,
        insurers and underwriters, break&#45;bulk agents, consignees, etc. It is the responsibility
        of the
        Customer to provide notice and copy(s) of these terms and conditions of service to all such
        agents or representatives;
    </li>
    <li>&quot;Documentation&quot; shall mean all information received directly or indirectly from
        Customer,
        whether in paper or electronic form;
    </li>
    <li>&quot;Ocean Transportation Intermediaries&quot; (&quot;OTI&quot;) shall include an &quot;ocean
        freight forwarder&quot;
        and a
        &quot;non&#45;vessel operating carrier&quot;;
    </li>
    <li style="padding-bottom: 15px;">&quot;Third parties&quot; shall include, but not be limited to, the following:
        &quot;carriers,
        truckmen,
        cartmen, lightermen, forwarders, OTIs, customs brokers, agents, warehousemen and others to
        which
        the goods are entrusted for transportation, cartage, handling and/or delivery and/or storage
        or
        otherwise&quot;.
    </li>
</ul>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">2. Company as agent.</h4>

<p id="ff-1">The Company acts as the &quot;agent&quot; of the Customer for the purpose of performing
    duties in connection with the entry and release of goods, post entry services, the securing of
    export licenses, the filing of export and security documentation on behalf of the Customer and
    other dealings with Government Agencies, or for arranging for transportation services or other
    logistics services in any capacity other than as a carrier.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">3. Limitation of Actions.</h4>
<ul style="background-color: #F4F4F4; list-style: square; line-height: 2; padding-left: 30px;">
    <li style="padding-top: 15px;">Unless subject to a specific statute or international convention, all claims against
        the
        Company
        for a potential or actual loss, must be made in writing and received by the Company, within
        60
        days of the event giving rise to claim; the failure to give the Company timely notice shall
        be a
        complete defense to any suit or action commenced by Customer.
    </li>
    <li>
        All suits against Company must be filed and properly served on Company as follows:
        <ul style="list-style: disc; line-height: 2;">
            <li>For claims arising out of ocean transportation, within one year from
                the
                date of the
                loss;
            </li>
            <li>For claims arising out of air transportation, within one year from
                the
                date of the loss;
            </li>
            <li>For claims arising out of the preparation and/or submission of an
                import
                entry(s), within 60 days from the date of liquidation of the entry(s);
            </li>
            <li style="padding-bottom: 15px;">For any and all other claims of any other type, within one years from the
                date of the loss or damage.
            </li>
        </ul>
    </li>
</ul>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">4. No Liability For The Selection or
    Services of Third Parties and/or Routes.</h4>

<p id="ff-2">Unless services are performed by persons or firms engaged pursuant to express written
    instructions from the Customer, Company shall use reasonable care in its selection of third
    parties, or in selecting the means, route and procedure to be followed in the handling,
    transportation, clearance and delivery of the shipment; advice by the Company that a particular
    person or firm has been selected to render services with respect to the goods, shall not be
    construed to mean that the Company warrants or represents that such person or firm will render
    such services nor does Company assume responsibility or liability for any actions(s) and/or
    inaction(s) of such third parties and/or its agents, and shall not be liable for any delay or
    loss of any kind, which occurs while a shipment is in the custody or control of a third party or
    the agent of a third party; all claims in connection with the Act of a third party shall be
    brought solely against such party and/or its agents; in connection with any such claim, the
    Company shall reasonably cooperate with the Customer, which shall be liable for any charges or
    costs incurred by the Company.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">5. Quotations Not Binding.</h4>

<p id="ff-3">Quotations as to fees, rates of duty, freight charges, insurance premiums or other
    charges given by the Company to the Customer are for informational purposes only and are subject
    to change without notice; no quotation shall be binding upon the Company unless the Company in
    writing agrees to undertake the handling or transportation of the shipment at a specific rate or
    amount set forth in the quotation and payment arrangements are agreed to between the Company and
    the Customer.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">6. Reliance On Information
    Furnished.</h4>
<ul class="ff-service" style="background-color: #F4F4F4;">
    <li style="padding-top: 15px;">Customer acknowledges that it is required to review all documents and declarations
        prepared
        and/or filed with U.S. Customs &amp; Border Protection, other Government Agency and/or third
        parties, and will immediately advise the Company of any errors, discrepancies, incorrect
        statements, or omissions on any declaration or other submission filed on Customers behalf;
    </li>
    <li>In preparing and submitting customs entries, export declarations, applications,
        security
        filings, documentation and/or other required data, the Company relies on the correctness of
        all
        documentation, whether in written or electronic format, and all information furnished by
        Customer; Customer shall use reasonable care to ensure the correctness of all such
        information
        and shall indemnify and hold the Company harmless from any and all claims asserted and/or
        liability or losses suffered by reason of the Customer&#39;s failure to disclose information
        or any
        incorrect, incomplete or false statement by the Customer or its agent, representative or
        contractor upon which the Company reasonably relied. The Customer agrees that the Customer
        has
        an affirmative non&#45;delegable duty to disclose any and all information required to
        import, export
        or enter the goods.
    </li>
    <li style="padding-bottom: 15px;">Customer acknowledges that it is required to provide verified weights obtained on calibrated, certified equipment of all cargo that is to be tendered to steamship lines and represents that Company is entitled to rely on the accuracy of such weights and to counter-sign or endorse it as agent of Customer in order to provide the certified weight to the steamship lines.  The Customer agrees that it shall indemnify and hold the Company harmless from any and all claims, losses, penalties or other costs resulting from any incorrect or questionable statements of the weight provided by the Customer or its agent or contractor on which the Company relies.
    </li>
</ul>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">7. Declaring Higher Value To Third Parties.</h4>

<p id="ff-4">Third parties to whom the goods are entrusted may limit liability for loss or damage;
    the Company will request excess valuation coverage only upon specific written instructions from
    the Customer, which must agree to pay any charges therefore; in the absence of written
    instructions or the refusal of the third party to agree to a higher declared value, at Company&#39;s
    discretion, the goods may be tendered to the third party, subject to the terms of the third
    party&#39;s limitations of liability and/or terms and conditions of service.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">8. Insurance.</h4>

<p id="ff-5">Unless requested to do so in writing and confirmed to Customer in writing, Company is
    under no obligation to procure insurance on Customer&#39;s behalf; in all cases, Customer shall
    pay all premiums and costs in connection with procuring requested insurance.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">9. Disclaimers; Limitation of Liability.</h4>
<ul style="background-color: #F4F4F4; list-style: square; line-height: 2; padding-left: 30px;">
    <li style="padding-top: 15px;">Except as specifically set forth herein, Company makes no express or implied
        warranties in
        connection with its services;
    </li>
    <li>In connection with all services performed by the Company, Customer may obtain additional
        liability coverage, up to the actual or declared value of the shipment or transaction, by
        requesting such coverage and agreeing to make payment therefor, which request must be confirmed
        in writing by the Company prior to rendering services for the covered transaction(s).
    </li>
    <li>In the absence of additional coverage under (b) above, the Company&#39;s liability shall be limited
        to the following:
        <ul style="list-style: disc; ">
            <li>where the claim arises from activities other than those relating to
                customs business,
                $100 per shipment or transaction, or
            </li>
            <li>where the claim arises from activities relating to &quot;Customs business&quot;,
                $100 per entry or
                the amount of brokerage fees paid to Company for the entry, whichever is less;
            </li>
        </ul>
    </li>
    <li style="padding-bottom: 15px;">In no event shall Company be liable or responsible for consequential, indirect,
        incidental,
        statutory or punitive damages, even if it has been put on notice of the possibility of such
        damages, or for the acts of third parties.
    </li>
</ul>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">10. Advancing Money.</h4>

<p id="ff-6">All charges must be paid by Customer in advance unless the Company agrees
    in writing to extend credit to customer; the granting of credit to a Customer in connection with a
    particular transaction shall not be considered a waiver of this provision by the Company.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">11. Indemnification/Hold Harmless.</h4>

<p id="ff-7">The Customer agrees to indemnify, defend, and hold the Company harmless
    from any claims and/or liability, fines, penalties and/or attorneys&#39; fees arising from the
    importation or exportation of customers merchandise and/or any conduct of the Customer, including
    but not limited to the inaccuracy of entry, export or security data supplied by Customer or its
    agent or representative, which violates any Federal, State and/or other laws, and further agrees to
    indemnify and hold the Company harmless against any and all liability, loss, damages, costs, claims,
    penalties, fines and/or expenses, including but not limited to reasonable attorney&#39;s fees, which the
    Company may hereafter incur, suffer or be required to pay by reason of such claims; in the event
    that any claim, suit or proceeding is brought against the Company, it shall give notice in writing
    to the Customer by mail at its address on file with the Company.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">12. C.O.D. or Cash Collect Shipments.</h4>

<p id="ff-8">Company shall use reasonable care regarding written instructions relating to &quot;Cash/Collect on Deliver
    (C.O.D.)&quot; shipments, bank drafts, cashier&#39;s and/or certified checks, letter(s) of credit and other similar
    payment documents and/or instructions regarding collection of monies but shall not have liability if the bank or
    consignee refuses to pay for the shipment.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">13. Costs of Collection.</h4>

<p id="ff-9">In any dispute involving monies owed to Company, the Company shall be entitled to all
    costs of collection, including reasonable attorney&#39;s fees and interest at 12% per annum or the highest rate
    allowed by law, whichever is less unless a lower amount is agreed to by Company.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">14. General Lien and Right To Sell Customer&#39;s
    Property.</h4>
<ul class="ff-service" style="background-color: #F4F4F4;">
    <li style="padding-top: 15px;">Company shall have a continuing lien on any and all property and documents relating thereto of Customer coming into Company's actual or constructive possession, custody or control or enroute, which lien shall survive delivery, for all charges, expenses or advances owed to Company with regard to the shipment on which the lien is claimed, a prior shipment(s) and/or both. Customs duties, transportation charges, and related payments advanced by the Company shall be deemed paid in trust on behalf of the Customer and treated as pass through payments made on behalf of the Customer for which the Company is acting as a mere conduit. 
    </li>
    <li>Company shall provide written notice to Customer of its intent to exercise such lien, the exact amount of monies
        due and owing, as well as any on-going storage or other charges; Customer shall notify all parties having an
        interest in its shipment(s) of Company&#39;s rights and/or the exercise of such lien.
    </li>
    <li style="padding-bottom: 15px;">Unless, within thirty days of receiving notice of lien, Customer posts cash or
        letter of credit at sight, or, if
        the amount due is in dispute, an acceptable bond equal to 110% of the value of the total amount due, in favor of
        Company, guaranteeing payment of the monies owed, plus all storage charges accrued or to be accrued, Company
        shall have the right to sell such shipment(s) at public or private sale or auction and any net proceeds
        remaining thereafter shall be refunded to Customer.
    </li>
</ul>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">15. No Duty To Maintain Records For Customer.</h4>

<p id="ff-10">Customer acknowledges that pursuant to Sections 508 and 509 of the Tariff Act, as
    amended, (19 USC �1508 and 1509) it has the duty and is solely liable for maintaining all records required under the
    Customs and/or other Laws and Regulations of the United States; unless otherwise agreed to in writing, the Company
    shall only keep such records that it is required to maintain by Statute(s) and/or Regulation(s), but not act as a
    &quot;recordkeeper&quot; or &quot;recordkeeping agent&quot; for Customer.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">16. Obtaining Binding Rulings, Filing Protests, etc.</h4>

<p id="ff-11">Unless requested by Customer in writing and agreed to by Company in writing, Company shall be under no
    obligation to undertake any pre&#45; or post Customs release action, including, but not limited to, obtaining
    binding rulings, advising of liquidations, filing of petition(s) and/or protests, etc.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">17. No Duty To Provide Licensing Authority.</h4>

<p id="ff-11">Unless requested by Customer in writing and agreed to by the Company in writing, Company shall not be responsible for determining licensing authority or obtaining any license or other authority pertaining to the export from or import into the United States.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">

<h4 class="title">18. Preparation and Issuance of Bills of Lading.</h4>

<p id="ff-12">Where Company prepares and/or issues a bill of lading, Company shall be under no
    obligation to specify thereon the number of pieces, packages and/or cartons, etc.; unless specifically requested to
    do so in writing by Customer or its agent and Customer agrees to pay for same, Company shall rely upon and use the
    cargo weight supplied by Customer.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">19. No Modification or Amendment Unless Written.</h4>

<p id="ff-13">These terms and conditions of service may only be modified, altered or amended in writing signed by both
    Customer and Company; any attempt to unilaterally modify, alter or amend same shall be null and void.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">20. Compensation of Company.</h4>

<p id="ff-14">The compensation of the Company for its services shall be included with and is in
    addition to the rates and charges of all carriers and other agencies selected by the Company to transport and deal
    with the goods and such compensation shall be exclusive of any brokerage, commissions, dividends, or other revenue
    received by the Company from carriers, insurers and others in connection with the shipment. On ocean exports, upon
    request, the Company shall provide a detailed breakout of the components of all charges assessed and a true copy of
    each pertinent document relating to these charges. In any referral for collection or action against the Customer for
    monies due the Company, upon recovery by the Company, the Customer shall pay the expenses of collection and/or
    litigation, including a reasonable attorney fee.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">21. Force Majeure.</h4>

<p> Company shall not be liable for losses, damages, delays, wrongful or missed deliveries or
    nonperformance, in whole or in part, of its responsibilities under the Agreement, resulting from circumstances
    beyond the control of either Company or its sub&#45;contractors, including but not limited to:</p><br>
<ul style="background-color: #F4F4F4; list-style: square; line-height: 2; padding-left: 30px;">

    <li style="padding-top: 10px;">Acts of God,
        including flood, earthquake, storm, hurricane, power failure or other natural disaster;
    </li>
    <li>War, hijacking,
        robbery, theft or terrorist activities;
    </li>
    <li>Incidents or deteriorations to means of transportation,</li>
    <li>Embargoes</li>
    <li>Civil commotions or riots</li>
    <li>Defects, nature or inherent vice of the goods;</li>
    <li>Acts, breaches
        of contract or omissions by Customer, Shipper, Consignee or anyone else who may have an interest in the
        shipment,
    </li>
    <li>Acts by any government or any agency or subdivision thereof, including denial or cancellation of any
        import/export or other necessary license; or
    </li>
    <li style="padding-bottom: 15px;">Strikes, lockouts or other labor conflicts.</li>
</ul>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">22. Severability.</h4>

<p id="ff-15">In the event any Paragraph(s) and/or portion(s) hereof is found to be invalid and/or unenforceable, then
    in such event the remainder hereof shall remain in Full force and effect. Company&#39;s decision to waive any
    provision herein, either by conduct or otherwise, shall not be deemed to be a further or continuing waiver of such
    provision or to otherwise waive or invalidate any other provision herein.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">23. Governing Law; Consent to Jurisdiction and Venue</h4>

<p id="ff-16">These terms and conditions of service and the relationship of the parties shall be construed according to
    the laws of the State of California without giving consideration to principles of conflict of law.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">Customer and Company</h4>
<ul class="ff-service" style="background-color:#F4F4F4;">
    <li style="padding-top: 15px;">irrevocably consent to the jurisdiction of the United States District Court and the
        State courts of California;
    </li>
    <li>agree that any action relating to the services performed by Company, shall only be brought in said courts;</li>
    <li>consent to the exercise of in personam jurisdiction by said courts over it, and
    </li>
    <li style="padding-bottom: 15px;">further agree that any action to enforce a judgment may be instituted in any
        jurisdiction.
    </li>
</ul>
</div>
<div id="domestic-tc" style="display: none;">
<h1 style="font-size: 18pt; font-family: 'open sans'; color: #3b3b3b; margin-bottom: 20px; font-weight: 600;">
    Domestic Terms and Conditions
</h1>

<p id="tc-0">By tendering materials for shipment via A7S (AIR 7 SEAS TRANSPORT LOGISTICS, Inc), the Shipper agrees to
    the terms and conditions stated herein and to A7S�s STANDARD CONDITIONS OF CARRIAGE which are incorporated into this
    contract by reference and which are available from or for inspection at any A7S associated offices. No agent or
    employee of
    A7S of the Shipper may alter or modify these items and conditions.</p>

<h4 class="title">1. THE AIRBILL.</h4>

<p id="tc-1">This A7S AIRBILL is NON-NEGOTIABLE, and the Shipper acknowledges that it has been prepared by the Shipper
    or by A7S
    on behalf of the Shipper. The Shipper warrants that it is the owner of the goods transported hereunder, or it is the
    authorized
    agent of the owner of the goods, and that it hereby accepts A7S terms and conditions for itself and as agent for and
    on behalf
    of any other person having any interest in the shipment.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">2. a. SHIPPER�S OBLIGATIONS AND ACKNOWLEDGEMENTS.</h4>

<p id="tc-1" style="padding-left: 30px;">The Shipper warrants that each article in the shipment is properly described on
    the AIRBILL and has not
    been declared by
    A7S to be unacceptable for transport, and that the shipment is properly marked and addressed and packed to ensure
    safe
    transportation with ordinary care in handling.
    The Shipper shall be liable for all costs and expenses related to the shipment and for costs incurred in either
    returning the
    shipment to the Shipper or warehousing the shipment pending disposition.</p>

<h4 class="title" style="padding-left: 15px;">b. CHANGES ON CARRIER/ROUTING.</h4>

<p id="tc-1" style="padding-left: 30px;">A7S shall have the right to (i) substitute alternate carriers or other means of
    transportation, and (ii)
    select the routing or
    deviate from that shown on the face hereof.</p>

<h4 class="title" style="padding-left: 15px;">c. RIGHT OF INSPECTION OF SHIPMENT.</h4>

<p style="padding-left: 30px;" id="tc-1">A7S has the right, but not the obligation, to inspect any shipment including,
    without limitation, opening
    the shipment.</p>

<h4 style="padding-left: 15px;" class="title">d. LIEN ON GOODS SHIPPED.</h4>

<p style="padding-left: 30px;" id="tc-1">A7S shall have a lien on any goods shipped for all freight charges, customs
    duties, advances or other
    charges of any kind
    arising out of the transportation hereunder and may refuse to surrender possession of the goods until such charges
    are paid.</p>

<h4 style="padding-left: 15px;" class="title">e. RATES/CHARGES.</h4>

<p style="padding-left: 30px;" id="tc-1">Rates and charges for this shipment will be based on actual or dimensional
    weight, whichever is
    greater.</p>

<h4 style="padding-left: 15px;" class="title">f. OTHER CHARGES.</h4>

<p style="padding-left: 30px;" id="tc-1">The Shipper and the Consignee shall be liable jointly and severally for all
    unpaid charges payable on
    account of this shipment
    pursuant to this contract and to pay or indemnify A7S for claims, fines, penalties, damages, costs (storage,
    handling,
    reconsignment, return of freight to Shipper, etc.) or other sums which may be incurred by A7S by reason of any
    violation of
    this contract or any other default of the Shipper or Consignee or their agents. A7S shall have a lien on any goods
    shipped for
    failure to pay for charges due and payable on account. A7S may refuse to surrender possession of the goods until
    such
    charges are paid. Should A7S bring legal action for the enforcement of this contract or collection of any sums due
    and
    payable under this contract, A7S shall be entitled to reasonable attorney fees and costs.
    g. Should A7S successfully defend itself for any legal actions brought by any party with an interest in this
    shipment, A7S shall
    be entitled to reasonable attorney fees and costs.</p>

<hr style="border: 0px; border-bottom:1px solid #dedede;">

<h4 class="title">3. LIMITATION OF LIABILITY.</h4>

<p id="tc-1">
    A7S�S LIABILITY, IN THE ABSENCE OF A HIGHER DECLARED VALUE FOR CARRIAGE, IS LIMITED TO A MINIMUM OF
    $50.00 PER SHIPMENT OR $1.00 PER POUND, PER PIECE, OF CARGO LOST, DAMAGED, MISDELIVERED OR
    OTHERWISE ADVERSELY AFFECTED. THIS LIMITATION IS SUBJECT TO PROVISIONS AS PUBLISHED IN A7S�S
    GOVERNING TARIFFS IN EFFECT AT THE TIME OF THIS SHIPMENT. DECLARED VALUES FOR CARRIAGE IN EXCESS
    OF $1.00 PER POUND, PER PIECE, SHALL BE SUBJECT TO AN EXCESS VALUATION CHARGE.
</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">

<h4 class="title">4. Collect on Delivery (C.O.D.) service is provided under these conditions:</h4>

<ul class="ff-service" style="background-color: #F4F4F4;">
    <li style="padding-top: 15px;">SHIPPER MUST IDENTIFY the shipment as a C.O.D. shipment by entering the amount to be
        collected in the Shippers
        C.O.D. Box on the front of this bill;
    </li>
    <li>SHIPPER MUST SPECIFY THE TYPE OF PAYMENT to be received (e.g. cash, check, money order or cashier�s check) IN
        THE SPECIAL SERVICES BOX on the front of this bill;
    </li>
    <li style="padding-bottom: 15px;">
        A7S and Shipper agree that A7S DOST NOT GUARANTEE nor does it verify that a check, money order, cashier�s check
        or
        other such financial instrument is valid or negotiable. All payments are collected at shipper�s risk.
    </li>
</ul>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">5. CONSEQUENTIAL DAMAGES EXCLUDED.</h4>

<p id="tc-2">A7S shall not be liable, in any event, for any consequential or special damages or other indirect loss,
    however arising,
    whether or not A7S had knowledge that such damages might be incurred, but not limited to, loss of income, profits,
    interest,
    utility or loss of market.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">6. LIABILITIES NOT ASSUMED.</h4>

<p id="tc-3">While A7S will endeavor to exercise its best expeditious delivery in accordance with regular delivery
    schedules, A7S WILL
    NOT, UNDER ANY CIRCUMSTANCES, BE LIABLE FOR DELAY IN PICK-UP, TRANSPORTATION OR DELIVERY OF ANY
    SHIPMENT, REGARDLESS OF THE CAUSE OF SUCH DELAY.<br><br>
    Further A7S shall not be liable for any loss, damage, mis-delivery or non-delivery:

<ul style="padding-left: 30px; list-style: lower-alpha">
    <li>due to act of GOD, force majeure occurrence or any cause reasonably beyond the control of A7S, or</li>
    <li>caused by:<br><br>
        <ul style="padding-left: 30px; list-style: lower-roman;">
            <li style="padding-bottom: 10px;">
                The act, default or omission of the Shipper, the Consignee or any other party who claims an interest in
                the shipment
                (including violation of any term or condition hereof), or of any person other than A7S or of any
                Customs� or other Government
                Officials, or of any Postal Service, forwarder or other entity or person to whom a shipment is tendered
                by A7S for
                transportation to any location not regularly served by A7S, regardless of whether the Shipper requested
                or had knowledge of
                such third-party delivery arrangement.
            </li>
            <li style="padding-bottom: 10px;">
                The nature of the shipment or any defect, characteristic, or inherent vice thereof:
            </li>
            <li>Electrical or magnetic injury, erasure, or other such damage to electronic or photographic images or
                recordings in any
                form.
            </li>
        </ul>
    </li>
</ul>
</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">7. CLAIMS.</h4>

<p id="tc-4">OVERCHARGE CLAIMS MUST BE RECEIVED IN WRITING BY A7S WITHIN TWO YEARS AFTER DATE OF
    ACCEPTANCE OF THE SHIPMENT BY A7S. ALL OTHER CLAIMS (EXCEPT CONCEALED LOSS/DAMAGED CLAIMS)
    MUST BE RECEIVED IN WRITING BY A7S WITHIN 90 DAYS AFTER A7S ACCEPTED THE SHIPMENT. CONCEALED
    LOSS/DAMAGED CLAIMS (I.E., CASH FOR LOSS OR DAMAGE DISCOVERED BY THE CONSIGNEE AFTER DELIVERY
    AND AFTER A CLEAR RECEIPT HAS BEEN GIVEN) MUST BE RECEIVED IN WRITING BY A7S WITHIN 14 DAYS AFTER
    DELIVERY. FOR DAMAGE CLAIMS AND CONCEALED LOSS CLAIMS, A7S MUST BE NOTIFIED OF THE DAMAGE OR
    CONCEALED LOSS WITHIN 14 DAYS OF DELIVERY AND A7S MUST BE ALLOWED THE PRIVILEGE TO MAKE
    INSPECTION OF THE SHIPMENT AND ITS CONTAINER(S) AND PACKAGING MATERIAL(S) AT THE DELIVERY
    LOCATION SHOWN ON THIS AIR BILL. NO CLAIMS WILL BE ENTERTAINED UNTIL ALL TRANSPORTATION CHARGES
    HAVE BEEN PAID. CLAIMS MAY NOT BE DEDUCTED FROM TRANSPORTATION CHARGES AND NO CHARGES AND
    NO CLAIMS MAY BE DEDUCTED FROM ANY CHARGES OWED A7S. LEGAL ACTION TO ENFORCE A CLAIM MUST BE
    BROUGHT WITHIN ONE YEAR AFTER THE CLAIM HAS BEEN DENIED IN WRITING BY A7S, IN WHOLE OR IN PART.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">

<h4 class="title">8. APPLICABILITY.</h4>

<p id="tc-5">These terms and conditions shall apply to, and inure to the benefit of A7S and its authorized agents and
    affiliated companies,
    and their officers, directors and employees.</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">

<h4 class="title">9. MATERIALS NOT ACCEPTABLE FOR TRANSPORT.</h4>

<p>
    A7S will not carry: Currency, Jewelry, Bullion, Cashier�s checks, Antiques, Pharmaceutical, Liquor, Stamps, Precious
    metals,
    Fire Arms, Money orders, Plants, Drugs, Tobacco, Works of Art, Precious Stones, Explosives, Travelers checks,
    Animals,
    Foodstuffs, Perishables, Negotiable instruments in bearer form Lewd, obscene or pornographic materials, Industrial
    carbons
    and diamonds, Restricted articles, including hazardous or combustible materials, Property the carriage of which is
    prohibited
    by any law regulation or statute of any federal, state or local government.
</p>

<hr style="border: 0px; border-bottom:1px solid #dedede;">
<h4 class="title">10. COLLECT SHIPMENTS.</h4>

<p id="tc-6">Where the consignee is to be billed for cost of shipment, A7S reserves the right to refuse delivery until
    all transportation and
    other charges have been paid. If the consignee refuses to pay, the shipper will be liable for all such charges,
    including, without
    limitation, cost of returning the shipment if required..</p>
<hr style="border: 0px; border-bottom:1px solid #dedede;">


<h4 class="title">11. INSURANCE.</h4>

<ul class="ff-service" style="background-color: #F4F4F4;">
    <li style="padding-top: 15px;">CAt the request of the Shipper and upon payment therefor, A7S will arrange insurance
        on behalf of the Shipper.
    </li>
    <li>The insurance coverage shall be governed by all of the terms and conditions contained in the policy of insurance
        issued by
        the insurance carrier.
    </li>
    <li style="padding-bottom: 15px;">CONSEQUENTIAL DAMAGES AND LOSS OR DAMAGE RESULTING FROM DELAYS IN TRANSPORTATION
        ARE NOT
        COVERED BY ANY SUCH POLICY OF INSURANCE.
    </li>
</ul>
<hr style="border: 0px; border-bottom:1px solid #dedede;">
</div>
<div id="intl-air-freight-tc" style="display: none;">
<h1 style="font-size: 18pt; font-family: 'open sans'; color: #3b3b3b; margin-bottom: 20px; font-weight: 600;">
    International Air Freight Terms &amp; Conditions
</h1>
<h4 class="title">NOTICE CONCERNING CARRIERS&#39; LIMITATION OF LIABILITY</h4>

<p>If the carriage involves an ultimate destination or stop in a country other than the country of departure, the
    Montreal Convention or the Warsaw Convention may be applicable to the liability of the Carrier in respect of
    loss of, damage or delay to cargo. Carrier&#39;s limitation of liability in accordance with those Conventions
    shall
    be as set forth in subparagraph 4 unless a higher value is declared.</p>
<h4 class="title">CONDITIONS OF CONTRACT</h4>
<ul class="tc-international" style="padding-left: 20px; list-style: decimal;">
    <li><b>In this contract and the Notices appearing hereon:</b> CARRIER includes the air carrier issuing this air
        waybill and all carriers that carry or undertake to carry the cargo or perform any other services related to
        such carriage. SPECIAL DRAWING RIGHT (SDR) is a Special Drawing Right as defined by the International
        Monetary Fund.<br>
        <b>WARSAW CONVENTION means whichever of the following instruments is applicable to the contract of
            carriage:</b> the Convention for the Unification of Certain Rules Relating to International Carriage by
        Air, signed at Warsaw. 12 October 1929; that Convention as amended at The Hague on 28 September 1955; that
        Convention as amended at The Hague 1955 and by Montreal Protocol No. 1, 2, or 4 (1975) as the case may be.
        MONTREAL CONVENTION means the Convention for the Unification of Certain Rules for International Carriage by
        Air, done at Montreal on 28 May 1999.
    </li>
    <li>
        <div style="background-color: #f4f4f4;">
            <ul style="padding:8px 8px 12px 20px; list-style: none;">
                <li>Carriage is subject to the rules relating to liability established by the Warsaw Convention or
                    the
                    Montreal Convention unless such carriage is not &#39;international carriage&#39; as defined by
                    the
                    applicable Conventions.
                </li>
                <li><b>To the extent not in conflict with the foregoing, carriage and other related services performed
                        by each Carrier are subject to:</b>
                    <ul style="padding-left: 25px;">
                        <li>Applicable laws and government regulations;</li>
                        <li>Provisions contained in the air waybill, Carrier&#39;s conditions of carriage and
                            related
                            rules, regulations, and timetables (but not the times of departure and arrival stated
                            therein) and applicable tariffs of such Carrier, which are made part hereof, and which
                            may
                            be inspected at any airports or other cargo sales offices from which it operates regular
                            services. When carriage is to/from the USA, the shipper and the consignee are entitled,
                            upon
                            request, to receive a free copy of the Carrier&#39;s conditions of carriage. The Carrier&#39;s
                            conditions of carriage include, but are not limited to:
                            <ul style="padding-left: 20px;">
                                <li>Limits on the Carrier&#39;s liability for loss, damage or delay of goods,
                                    including
                                    fragile or perishable goods:
                                </li>
                                <li>Claims restrictions, including time periods within which shippers or consignees
                                    must
                                    file a claim or bring an action against the Carrier for its acts or omissions,
                                    or
                                    those of its agents;
                                </li>
                                <li>Rights, if any, of the Carrier to change the terms of the contract;</li>
                                <li>Rules about Carrier&#39;s right to refuse to carry;</li>
                                <li>Rights of the Carrier and limitations concerning delay or failure to perform
                                    service, including schedule changes, substitution of alternate Carrier or
                                    aircraft
                                    and rerouting.
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </li>
    <li>The agreed stopping places (which may be altered by Carrier in case of necessity) are those places, except
        the place of departure and place of destination, set forth on the face hereof or shown in Carrier's
        timetables as scheduled stopping places for the route. Carriage to be performed hereunder by several
        successive Carriers is regarded as a single operation.
    </li>
    <hr style="border: 0px; border-bottom:1px solid #ebebeb; margin-top: 10px;">
    <li>For carriage to which the Montreal Convention does not apply, Carrier&#39;s liability limitation for cargo
        lost, damaged or delayed shall be 19 SD/Rs per kilogram unless a greater per kilogram monetary limit is
        provided in any applicable Convention or in Carrier&#39;s tariffs or general conditions of carriage.
    </li>
    <hr style="border: 0px; border-bottom:1px solid #ebebeb; margin-top: 10px;">
    <li>
        <ul style="padding-left: 20px;">
            <li>Except when the Carrier has extended credit to the consignee without the written consent of the
                shipper, the shipper guarantees payment of all charges for the carriage due in accordance with
                Carrier&#39;s tariff, conditions of carriage and related regulations, applicable laws (including
                national laws implementing the Warsaw Convention and the Montreal Convention), government
                regulations, orders and requirements.
            </li>
            <li>When no part of the consignment is delivered, a claim with respect to such consignment will be
                considered even though transportation charges thereon are unpaid.
            </li>
        </ul>
    </li>
    <hr style="border: 0px; border-bottom:1px solid #ebebeb; margin-top: 10px;">
    <li>
        <ul style="padding-left: 20px;">
            <li>For cargo accepted for carriage, the Warsaw Convention and the Montreal Convention permit shipper to
                increase the limitation of liability by declaring a higher value for carriage and paying a
                supplemental charge if required.
            </li>
            <li>In carriage to which neither the Warsaw Convention nor the Montreal Convention applies Carrier
                shall, in accordance with the procedures set forth in its general conditions of carriage and
                applicable tariffs, permit shipper to increase the limitation of liability by declaring a higher
                value for carriage and paying a supplemental charge if so required.
            </li>
        </ul>
    </li>
    <li>
        <div style="background-color: #f4f4f4;">
            <ul style="padding: 8px 8px 12px 20px;">
                <li>In cases of loss of, damage or delay to part of the cargo, the weight to be taken into account
                    in
                    determining Carrier&#39;s limit of liability shall be only the weight of the package or packages
                    concerned.
                </li>
                <li>Notwithstanding any other provisions, for &quot;foreign air transportation&quot; as defined by
                    the
                    U,S. Transportation Code:
                    <ul style="padding-left: 20px;">
                        <li>1 in the case of loss of. damage or delay to a shipment, the weight to be used in
                            determining Carrier&#39;s limit of liability shall be the weight which is used to
                            determine
                            the
                            charge for carriage of such shipment; and
                        </li>
                        <li>in the case of loss of, damage or delay to a part of a shipment, the shipment weight in
                            7.2.1 shall be prorated to the packages covered by the same air waybill whose value is
                            affected by the loss, damage or delay. The weight applicable in the case of loss or
                            damage
                            to one or more articles in a package shall be the weight of the entire package.
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </li>
    <li>Any exclusion or limitation of liability applicable to Carrier shall apply to Carrier&#39;s agents,
        employees, and representatives and to any person whose aircraft or equipment is used by Carrier for carriage
        and such person&#39;s agents, employees and representatives.
    </li>
    <hr style="border: 0px; border-bottom:1px solid #ebebeb; margin-top: 10px;">
    <li>Carrier undertakes to complete the carriage with reasonable dispatch. Where permitted by applicable laws,
        tariffs and government regulations, Carrier may use alternative carriers, aircraft or modes of transport
        without notice but with due regard to the interests of the shipper. Carrier is authorized by the shipper to
        select the routing and all intermediate stopping places that it deems appropriate or to change or deviate
        from the routing shown on the face hereof.
    </li>
    <li>
        <div style="background-color: #f4f4f4; padding-left: 10px; padding-top: 10px;">
            <span>Receipt by the person entitled to delivery of the cargo without complaint shall be prima facie evidence
            that the cargo has been delivered in good condition and in accordance with the contract of carriage.</span>
            <ul style="padding: 0px 12px 12px 20px; ">
                <li>In the case of loss of, damage or delay to cargo a written complaint must be made to Carrier by the
                    person entitled to delivery. <b>Such complaint must be made:</b>
                    <ul style="padding-left: 20px;">
                        <li>In the case of damage to the cargo, immediately after discovery of the damage and at the
                            latest within 14 days from the date of receipt of the cargo;
                        </li>
                        <li>In the case of delay, within 21 days from the date on which the cargo was placed at the
                            disposal of the person entitled to delivery.
                        </li>
                        <li>In the case of non&#45;delivery of the cargo, within 120 days from the date of issue of
                            the
                            air
                            waybill. or if an air waybill has not been issued, within 120 days from the date of
                            receipt
                            of the cargo for transportation by the Carrier.
                        </li>
                    </ul>
                </li>
                <li>Such complaint may be made to the Carrier whose air waybill was used, or to the first Carrier or
                    to
                    the last Carrier or to the Carrier, which performed the carriage during which the loss, damage
                    or
                    delay took place.
                </li>
                <li>Unless a written complaint is made within the time limits specified in 10.1 no action may be
                    brought
                    against Carrier.
                </li>
                <li>Any rights to damages against Carrier shall be extinguished unless an action is brought within
                    two
                    years from the date of arrival at the destination, or from the date on which the aircraft ought
                    to
                    have arrived, or from the date on which the carriage stopped.
                </li>
            </ul>
        </div>
    </li>
    <li>Shipper shall comply with all applicable laws and government regulations of any country to or from which
        the cargo may be carried. including those relating to the packing, carriage or delivery of the cargo, and
        shall furnish such information and attach such documents to the air waybill as may be necessary to comply
        with such laws and regulations. Carrier is not liable to shipper and shipper shall indemnify Carrier for
        loss or expense due to shipper&#39;s failure to comply with this provision.
    </li>
    <hr style="border: 0px; border-bottom:1px solid #ebebeb; margin-top: 10px;">
    <li>No agent, employee or representative of Carrier has authority to alter, modify or waive any provisions of
        this contract.
    </li>
</ul>

</div>
<div id="ocean-freight-tc" style="display: none;">
<h1 style="font-size: 18pt; font-family: 'open sans'; color: #3b3b3b; margin-bottom: 20px; font-weight: 600;">
    Ocean Freight Terms &amp; Conditions
</h1>

<p>
Notwithstanding the heading "Combined Transport BILL OF LADING" the provisions set out and referred to in this document shall also apply if the transport as described on the face of the BILL OF LADING is performed by one mode of transport only. These provisions
constitute a contract between Merchant and Carrier and may be used by Carrier only with the consent of the National Customs Brokers and Forwarders Association of America, Inc.
</p>

<h4 class="title" style="margin-top: 15px;">1. CLAUSE PARAMOUNT:</h4>
<p>
	All carriage under this BILL OF LADING to or from the United States shall have effect subject to the provisions of the Carriage of
Goods by Sea Act of the United States, 46 U.S.C. sections 1300-1315 (hereafter, "COGSA"). All carriage to and from other States
shall be governed by the law of any state making the Hague Rules or Hague-Visby Rules compulsorily applicable to this BILL OF
LADING or if there be no such law, in accordance with the Hague Rules. The provisions of applicable law as set forth above shall
apply to carriage of goods by inland waterways and reference to carriage by sea in such Rules or legislation shall be deemed to
include reference to inland waterways. Except as may be otherwise specifically provided herein, said law shall govern before the
goods are loaded on and after they are discharged from the vessel whether the goods are carried on deck or under deck and
throughout the entire time the goods are in the custody of the carrier.

</p>
<h4 class="title" style="margin-top: 15px;">2. DEFINITIONS:</h4>
<ol class="tc-ocean-freight">
    <li>"Ship" means the vessel named in this BILL OF LADING, or any conveyance owned, chartered, towed or operated by
Carrier or used by Carrier for the performance of this contract.</li>
<li>"Carrier" means AIR 7 SEAS Transport Logistics Inc, on whose behalf this BILL OF LADING has been signed.
</li>
<li>"Merchant" includes the Shipper, the Receiver, the Consignor, the Consignee, the Holder of this BILL OF LADING and any
person having a present or future interest in the Goods or any person acting on behalf of any of the above-mentioned
persons</li>
<li>"Package" is the largest individual unit of partially or completely covered or contained cargo made up by or for the Shipper
which is delivered and entrusted to Carrier, including palletized units and each container stuffed and sealed by the Shipper
or on its behalf, although the Shipper may have furnished a description of the contents of such sealed container on this BILL
OF LADING.</li>
<li>"Container" includes any container, trailer, transportable tank, lift van, flat, pallet, or any similar article of transport used to
consolidate goods</li>
<li>"Carrier's container or carrier's equipment" includes containers or equipment owned, leased or used by Carrier in the
transportation of Merchant's goods.
</li>
<li>"Goods" mean the cargo described on the face of this BILL OF LADING and, if the cargo is packed into container(s)
supplied or furnished by or on behalf of the Merchant, include the container(s) as well.
</li>
</ol>
<h4 class="title" style="margin-top: 15px;">3. SUBCONTRACTING:</h4>
<p>Carrier shall be entitled to subcontract directly or indirectly on any terms the whole or any part of the handling, storage, or carriage
of the goods and all duties undertaken by Carrier in relation to the goods. Every servant, agent, subcontractor (including subsubcontractors), or other person whose services have been used to perform this contract shall be entitled to the rights,
exemptions from, or limitations of, liability, defenses and immunities set forth herein. For these purposes, Carrier shall be deemed
to be acting as agent or trustee for such servants, agents, subcontractors, or other persons who shall be deemed to be parties to
this contract.</p>
<h4 class="title" style="margin-top: 15px;">4. ROUTE OF TRANSPORT:</h4>
<p>Carrier is entitled to perform the transport in any reasonable manner and by any reasonable means, methods and routes. The
Ship shall have the liberty, either with or without the goods on board, to at any time, adjust navigational instruments, make trial
trips, dry dock, go to repair yards, shift berths, take in fuel or stores, embark or disembark any persons, carry contraband and
hazardous goods, sail with or without pilots and save or attempt to save life or property. Delays resulting from such activities shall
not be deemed a deviation.
</p>
<h4 class="title" style="margin-top: 15px;">5. HINDRANCES AFFECTING PERFORMANCE:</h4>
<ol class="tc-ocean-freight">
	<li>Carrier shall use reasonable endeavors to complete transport and to deliver the goods at the place designated for delivery</li>
	<li>If at any time the performance of this contract as evidenced by this BILL OF LADING in the opinion of Carrier is or will be
affected by any hindrance, risk, delay, injury, difficulty or disadvantage of any kind, including strike, and if by virtue of the
above it has rendered or is likely to render it in any way unsafe, impracticable, unlawful, or against the interest of Carrier to
complete the performance of the contract, Carrier, whether or not the transport is commenced, may without notice to
Merchant elect to: (a) treat the performance of this contract as terminated and place the goods at Merchant's disposal at
any place Carrier shall deem safe and convenient, or (b) deliver the goods at the place of delivery.In any event, Carrier shall be entitled to, and Merchant shall pay, full freight for any goods received for transportation and
additional compensation for extra costs and expenses resulting from the circumstances referred to above
</li>
	<li>If, after storage, discharge, or any actions according to sub-part 5.2 above Carrier makes arrangements to store and/or
forward the goods, it is agreed that he shall do so only as agent for and at the sole risk and expense of Merchant without
any liability whatsoever in respect of such agency</li>
	<li>Carrier, in addition to all other liberties provided for in this Article, shall have liberty to comply with orders, directions,
regulations or suggestions as to navigation or the carriage or handling of the goods or the ship howsoever given, by any
actual or purported government or public authority, or by any committee or person having under the terms of any insurance
on the Ship, the right to give such order, direction, regulation, or suggestion. If by reason of and/or in compliance with any
such order, direction, regulation, or suggestions, anything is done or is not done the same shall be deemed to be included
within the contract of carriage and shall not be a deviation.
</li>
</ol>
<h4 class="title" style="margin-top: 15px;">6. BASIC LIABILITY:</h4>
<ol class="tc-ocean-freight">
	<li>Carrier shall be liable for loss of or damage to the goods occurring between the time when it takes goods into its custody
and the time of delivery but shall not be liable for any consequential or special damages arising from such loss or damage.</li>
	<li>If it is established that the loss of or damage to the goods occurred during sea carriage or during carriage by land in the
United States, liability shall be governed by the legal rules applicable as provided in Section 1 of this BILL OF LADING.</li>
	<li>Notwithstanding Section 1 of this BILL OF LADING, if the loss or damage occurred outside of the United States not during
sea carriage and it can be proved where the loss or damage occurred, the liability of Carrier in respect of such loss or
damage shall be determined by the provisions contained in any international convention or national law, which provisions:
cannot be departed from by private contract to the detriment of Merchant, and would have applied if Merchant had made a
separate and direct contract with Carrier in respect of the particular stage of transport where the loss or damage occurred
and received as evidence thereof any particular document which must be issued in order to make such international
convention or national law applicable.
</li>
	<li>If it cannot be determined when the loss of or damage to the goods occurred, liability shall be governed as provided in
Section 6.2 above.
</li>
	<li>Carrier does not undertake that the goods shall be delivered at any particular time or for any particular market and shall not
be liable for any direct or indirect losses caused by any delay.</li>
	<li>
		Carrier shall not be liable for any loss or damage arising from:
		<ol style="list-style-type: lower-alpha;">
			<li> an act or omission of Merchant or person other than Carrier acting on behalf of Merchant from whom Carrier took the
goods in charge,
</li>
			<li> compliance with the instructions of any person authorized to give them,
</li>
			<li> handling, loading, stowage or unloading of the goods by or on behalf of Merchant,</li>
			<li> inherent vice of the goods or concealed damage to or shortage of goods packed by Merchant,</li>
			<li> lack or insufficiency of or defective condition of packing in the case of goods, which by their nature are liable to
wastage or damage when not packed or when not properly packed,
</li>
			<li> insufficiency or inadequacy of marks or numbers on the goods, coverings or unit loads,</li>
			<li> fire, unless caused by actual fault or privity of Carrier,</li>
			<li> any cause or event which Carrier could not avoid and the consequences of which he could not prevent by the exercise
of due diligence.
</li>
		</ol>
	</li>
	<li>When Carrier pays claims to Merchant, Carrier shall automatically be subrogated to all rights of Merchant against all others,
including Inland Carriers, on account of the losses or damages for which such claims are paid.
</li>
	<li>The defenses and limits of liability provided for in this BILL OF LADING shall apply in any action or claim against Carrier
relating to the goods, or the receipt, transportation, storage or delivery thereof, whether the action be founded in contract,
tort or otherwise</li>
</ol>
<h4 class="title" style="margin-top: 15px;">7. COMPENSATION FOR LOSS AND DAMAGE:</h4>
<ol class="tc-ocean-freight">
	<li>Unless otherwise mandated by compulsorily applicable law, Carrier's liability for compensation for loss of or damage to
goods shall in no case exceed the amount of US$500 per package or per customary freight unit, unless Merchant, with the
consent of Carrier, has declared a higher value for the goods in the space provided on the front of this BILL OF LADING
and paid extra freight per Carrier's tariff, in which case such higher value shall be the limit of Carrier's liability. Any partial
loss or damage shall be adjusted pro rata on the basis of such declared value. Where a container is stuffed by Shipper or
on its behalf, and the container is sealed when received by Carrier for shipment, Carrier's liability will be limited to US$500
with respect to the contents of each such container, except when the Shipper declares the value on the face hereof and
pays additional charges on such declared value as stated in Carrier's tariff. The freight charged on sealed containers when
no higher valuation is declared by the Shipper is based on a value of US$500 per container. However, Carrier shall not, in
any case, be liable for an amount greater than the actual loss to the person entitled to make the claim. Carrier shall have
the option of replacing lost goods or repairing damaged goods</li>
	<li>In any case where Carrier's liability for compensation may exceed the amounts set forth in Section 7.1 above, compensation
shall be calculated by reference to the value of the goods, according to their current market price, at the time and place they
are delivered, or should have been delivered, in accordance with this contract.</li>
	<li>If the value of the goods is less than US$500 per package or per customary freight unit, their value for compensation
purposes shall be deemed to be the invoice value, plus freight and insurance, if paid.
</li>
	<li>Carrier shall not be liable to any extent for any loss of or damage to or in connection with precious metals, stones, or
chemicals, jewelry, currency, negotiable instruments, securities, writings, documents, works of art, curios, heirlooms, or any
other valuable goods, including goods having particular value only for Merchant, unless the true nature and value of the
goods have been declared in writing by Merchant before receipt of the goods by the Carrier or Inland Carrier, the same is
inserted on the face of this BILL OF LADING and additional freight has been paid as required.</li>
	<li>Carrier will not arrange for insurance on the goods except upon express instructions from the Consignor and then only at
Consignor’s expense and presentation of a declaration of value for insurance purposes prior to shipment.
</li>
</ol>
<h4 class="title" style="margin-top: 15px;">8. DESCRIPTION OF GOODS AND INFORMATION FOR U.S. CUSTOMS:
:
</h4>
<p>Carrier is responsible for transmitting information to U.S. Customs and Border Protection prior to lading of the Goods including,
without limitation, precise commodity descriptions, numbers and quantities of the lowest external packaging unit, the shipper’s
complete name and address, the consignee’s or the owner’s or owner’s representative’s complete name and address, hazardous
materials codes, and container seal numbers. For this, and other purposes, Carrier relies on information provided by Merchant in
a timely fashion. Merchant warrants to Carrier that all particulars of the goods, including, without limitation, the precise
descriptions, marks, number, quantity, weight, seal numbers, identities of shipper and consignee and hazardous materials codes
furnished by Merchant are correct and Merchant shall indemnify Carrier against all claims, penalties, losses or damages arising
from any inaccuracy</p>
<h4 class="title" style="margin-top: 15px;">9. CARRIER'S CONTAINERS:
</h4>
<p>If goods are not received by Carrier already in containers, Carrier may pack them in any type container. Merchant shall be liable
to Carrier for damage to Carrier's containers or equipment if such damage occurs while such equipment is in control of Merchant
or his agents. Merchant indemnifies Carrier for any damage or injury to persons or property caused by Carrier's containers or
equipment during handling by or when in possession or control of Merchant.
</p>
<h4 class="title" style="margin-top: 15px;">10. CONTAINER PACKED BY MERCHANT:
</h4>
<ol class="tc-ocean-freight">
	<li>This BILL OF LADING is prima facie evidence of the receipt of the particular number of containers set forth, and that
number only. Carrier accepts no responsibility with respect to the order and condition of the contents of the containers;</li>
	<li>Merchant warrants that the stowage and seals of the containers are safe and proper and suitable for handling and carriage
and indemnifies Carrier for any injury, loss or damage caused by breach of this warranty;</li>
	<li>Delivery shall be deemed as full and complete performance when the containers are delivered by Carrier with the seals
intact; and</li>
	<li>Carrier has the right but not the obligation to open and inspect the containers at any time without notice to Merchant, and
expenses resulting from such inspections shall be borne by Merchant; and</li>
	<li>Merchant shall inspect containers before stuffing them and the use of the containers shall be prima facie evidence of their
being sound and suitable for use.</li>
</ol>
<h4 class="title" style="margin-top: 15px;">11. DANGEROUS GOODS:</h4>
<ol class="tc-ocean-freight">
	<li>Merchant may not tender goods of a dangerous nature without written application to Carrier and Carrier's acceptance of the
same. In the application, Merchant must identify the nature of the goods with reasonable specificity as well as the names
and addresses of the shippers and consignees.</li>
	<li>Merchant shall distinctly and permanently mark the nature of the goods on the outside of the package and container in a
form and manner as required by law and shall submit to Carrier or to the appropriate authorities all necessary documents
required by law or by Carrier for the transportation of such goods</li>
	<li>If the goods subsequently, in the judgment of Carrier, become a danger to Carrier, the Ship, or other cargo, Carrier may
dispose of the goods without compensation to Merchant and Merchant shall indemnify Carrier for any loss or expenses
arising from such action.
</li>
</ol>
<h4 class="title" style="margin-top: 15px;">12. DECK CARGO:
</h4>
<p>Carrier has the right to carry the goods in any container under deck or on deck. Carrier is not required to note "on deck stowage"
on the face of this BILL OF LADING and goods so carried shall constitute under deck stowage for all purposes including General
Average. Except as otherwise provided by any law applicable to this contract, if this BILL OF LADING states that the cargo is
stowed on deck, then Carrier shall not be liable for any non-delivery, misdelivery, delay or loss to goods carried on deck, whether
or not caused by Carrier's negligence or the ship's unseaworthiness.
</p>
<h4 class="title" style="margin-top: 15px;">13. SOLAS WEIGHT CERTIFICATION:
</h4>
<p>Merchant acknowledges that it is required to provide verified weights obtained on calibrated, certified equipment of all cargo that
is to be tendered to steamship lines. Shipper agrees that Carrier is entitled to rely on the accuracy of such weights and to countersign or endorse it as Carrier’s own certified weight to the steamship line carrying the cargo. The Merchant agrees that it shall
indemnify and hold the Carrier harmless from any and all claims, losses, penalties or other costs resulting from any incorrect or
questionable verification of the weight provided by Merchant or its agent or contractor on which the Carrier relies.
</p>
<h4 class="title" style="margin-top: 15px;">14. HEAVY LIFT:
</h4>
<ol class="tc-ocean-freight">
	<li>Single packages with a weight exceeding 2,240 pounds gross not presented to Carrier in enclosed containers must be
declared in writing by Merchant before receipt of the packages by Carrier. The weight of such packages must be clearly and
durably marked on the outside of the package in letters and figures not less than two inches high.
</li>
	<li>If Merchant fails to comply with the above provisions, Carrier shall not be liable for any loss of or damage to the goods,
persons or property, and Merchant shall be liable for any loss of or damage to persons or property resulting from such
failure and Merchant shall indemnify Carrier against any loss or liability suffered or incurred by Carrier as a result of such
failure.
</li>
	<li>Merchant agrees to comply with all laws or regulations concerning overweight containers and Merchant shall indemnify
Carrier against any loss or liability suffered or incurred by Carrier as a result of Merchant's failure to comply with such laws
or regulations.
</li>
</ol>
<h4 class="title" style="margin-top: 15px;">15. DELIVERY:</h4>
<p>Carrier shall have the right to deliver the goods at any time at any place designated by Carrier within the commercial or
geographic limits of the port of discharge or place of delivery shown in this BILL OF LADING. Carrier's responsibility shall cease
when delivery has been made to Merchant, any person authorized by Merchant to receive the goods, or in any manner or to any
other person in accordance with the custom and usage of the port of discharge or place of delivery. If goods should remain in
Carrier's custody after discharge from the ship and possession is not taken by Merchant, after notice, within the time allowed in
Carrier's applicable tariff, the goods may be considered to have been delivered to Merchant or abandoned at Carrier's option, and
may be disposed of or stored at Merchant's expense.</p>
<h4 class="title" style="margin-top: 15px;">16. NOTICE OF CLAIM:
</h4>
<p>Written notice of claims for loss of or damage to goods occurring or presumed to have occurred while in the custody of Carrier
must be given to Carrier at the port of discharge before or at the time of removal of the goods by one entitled to delivery. If such
notice is not provided, removal shall be prima facie evidence of delivery by Carrier. If such loss or damage is not apparent, Carrier
must be given written notice within 3 days of the delivery.
</p>
<h4 class="title" style="margin-top: 15px;">17. FREIGHT AND CHARGES:
</h4>
<ol class="tc-ocean-freight">
	<li>Freight may be calculated on the basis of the particulars of the goods furnished by Merchant, who shall be deemed to have
guaranteed to Carrier the accuracy of the contents, weight, measure, or value as furnished by him at the time of receipt of
the goods by the Carrier or Inland Carrier, but Carrier for the purpose of ascertaining the actual particulars may at any time
and at the risk and expense of Merchant open the container or package and examine contents, weight, measure, and value
of the goods. In case of incorrect declaration of the contents, weight, measure and or value of the goods, Merchant shall be
liable for and bound to pay to Carrier: (a) the balance of freight between the freight charged and that which would have
been due had the correct details been given, plus (b) expenses incurred in determining the correct details, plus (c) as
liquidated and ascertained damages, an additional sum equal to the correct freight. Quotations as to fees, rates of duty,
freight charges, insurance premiums or other charges given by Carrier to Merchant are for informational purposes only and
are subject to change without notice and shall not under any circumstances be binding upon Carrier unless Carrier in writing
specifically undertakes the handling of transportation of the shipment at a specific rate and that rate is filed in Carrier’s tariff.
</li>
	<li>Freight shall be deemed earned on receipt of goods by Carrier, the goods lost or not lost, whether the freight is intended to
be prepaid or collected at destination. Payment shall be in full and in cash without any offset, counterclaim, or deduction, in
the currency named in this BILL OF LADING, or another currency at Carrier's option. Interest at 1% per month shall run
from the date when freight and charges are due. Payment of freight charges to a freight forwarder, broker or anyone other
than directly to Carrier shall not be deemed payment to the Carrier. Merchant shall remain liable for all charges hereunder
notwithstanding any extension of credit to the freight forwarder or broker by Carrier. Full freight shall be paid on damaged or
unsound goods.
</li>
	<li>Merchant shall be liable for all dues, fees, duties, fines, taxes and charges, including consular fees, levied on the goods.
Merchant shall be liable for return freight and charges on the goods if they are refused export or import by any government.
Merchant shall be liable for all demurrage, detention or other charges imposed on the goods or their containers by third
parties.
</li>
	<li>The Shipper, consignee, holder hereof, and owner of the goods, and their principals, shall be jointly and severally liable to
Carrier for the payment of all freight and charges, including advances and shall, in any referral for collection or action for
monies due to Carrier, upon recovery by Carrier, pay the expenses of collection and litigation, including reasonable
attorneys' fees. This provision shall apply regardless of whether the front of this BILL OF LADING has been marked
"prepaid" or "freight prepaid" so long as freight and charges remain unpaid.</li>
	<li>The Shipper, consignee, holder hereof, and owner of the goods, and their principals, shall jointly and severally indemnify
Carrier for all claims, fines, penalties, damages, costs and other amounts which may be incurred or imposed upon Carrier
by reason of any breach of any of the provisions of this BILL OF LADING Lading or of any statutory or regulatory
requirements.
</li>
</ol>
<h4 class="title" style="margin-top: 15px;">18. LIEN: </h4>
<p>Carrier shall have a lien on any and all property (and documents relating thereto) of Merchant in its actual or constructive
possession, custody or control or en route, which lien shall survive delivery, for all claims for charges, expenses or advances
incurred by Carrier in connection with this shipment, or any previous shipment, of Merchant, or both, which lien shall survive
delivery, and if such claim remains unsatisfied for 30 days after demand for its payment is made, Carrier may sell at public auction
or private sale, upon 10 days written notice, registered mail to Merchant, the goods, wares and/or merchandise or so much as
may be necessary to satisfy such lien and the costs of recovery, and apply the net proceeds of such sale to the payment of the
amount due Carrier. Any surplus from such sale shall be transmitted to Merchant, and Merchant shall be liable for any deficiency
in the sale.
</p>
<h4 class="title" style="margin-top: 15px;">19. TIME BAR:
</h4>
<p>Carrier shall be discharged from all liability for loss of or damage to goods unless suit is brought within one (1) year after delivery
of the goods or the date when the goods should have been delivered. Suit shall not be deemed brought against Carrier until
jurisdiction shall have been obtained over Carrier by service of summons. The time bar for overcharge claims shall be <b> 90 days. </b></p>
<h4 class="title" style="margin-top: 15px;">20. JURISDICTION:
</h4>
<p>The courts of Santa Clara County shall have exclusive jurisdiction over any dispute arising from the carriage evidenced by this
BILL OF LADING Lading. Merchant and Carrier each hereby agree to the personal jurisdiction of the forum having jurisdiction
over their disputes under this clause. Except as otherwise provided in this BILL OF LADING, the laws of the State of State of
California shall apply.
</p>
<h4 class="title" style="margin-top: 15px;">21. GENERAL AVERAGE:
</h4>
<ol class="tc-ocean-freight">
	<li>General Average shall be adjusted at New York, or any other port at Carrier's option, according to the York-Antwerp Rules of
1994. The General Average statement shall be prepared by adjusters appointed by Carrier.
</li>
	<li>In the event of accident, damage, danger or disaster after commencement of the voyage resulting from any cause
whatsoever, whether due to negligence or not, for the consequence of which Carrier is not responsible by statute, contract
or otherwise, Merchant shall contribute with Carrier in General Average to the payment of any sacrifice, loss or expense of a
General Average nature that may be made or incurred, and shall pay salvage or special charges incurred in respect of the
goods. If a salving vessel is owned or operated by Carrier, salvage shall be paid for as fully as if the salving vessel or
vessels belonged to strangers.
</li>
</ol>
<h4 class="title" style="margin-top: 15px;">22. BOTH-TO-BLAME COLLISION CLAUSE:
</h4>
<p>If the ship comes into collision with another vessel as a result of negligence of the other vessel and any negligence or fault on the
part of Carrier or its servants or subcontractors, Merchant shall indemnify Carrier against all loss or liability to the other or noncarrying vessel or her owners, insofar as such loss or liability represents loss of, or damage to, or any claim whatsoever of
Merchant paid or payable by the other or non-carrying vessel or her owners to Merchant and set-off, recouped or recovered by
the other or non-carrying vessel or her owners as part of their claim against the carrying ship or her owner. This provision shall
apply as well where the owners, operators or those in charge of any ship or ships or objects other than, or in addition to, the
colliding ships or objects are at fault with respect to a collision or contact.</p>
<h4 class="title" style="margin-top: 15px;">23. CARRIERS' TARIFFS:
</h4>
<p>The goods carried under this BILL OF LADING are also subject to all the terms and conditions of tariff(s) published pursuant to
the regulations of the United States Federal Maritime Commission or any other regulatory agency which governs a particular
portion of the carriage and the terms are incorporated herein as part of the terms and conditions of this BILL OF LADING. Copies
of Carriers' tariffs may be obtained from Carrier or its agents or from Carriers’ web-site, the address of which is set forth on the
U.S. Federal Maritime Commission’s web-site at www.fmc.gov. Carrier may enter into Negotiated Rate Arrangements with
Merchant in lieu of publishing the applicable rates and charges for services provided in its rate tariff.</p>
<h4 class="title" style="margin-top: 15px;">24. PERISHABLE CARGO:
</h4>
<ol class="tc-ocean-freight">
	<li>Goods of a perishable nature shall be carried in ordinary containers without special protection, services or other measures
unless there is noted on the reverse side of this BILL OF LADING that the goods will be carried in a refrigerated, heated,
electrically ventilated or otherwise specially equipped container or are to receive special attention in any way. Carrier shall
not be liable for any loss of or damage to goods in a special hold or container arising from latent defects, breakdown, or
stoppage of the refrigeration, ventilation or heating machinery, insulation, ship’s plant, or other such apparatus of the vessel
or container, provided that Carrier shall before or at the beginning of the transport exercise due diligence to maintain the
special hold or container in an efficient state.</li>
	<li>Merchant undertakes not to tender for transportation any goods that require refrigeration without given written notice of their
nature and the required temperature setting of the thermostatic controls before receipt of the goods by Carrier. In case of
refrigerated containers packed by or on behalf of Merchant, Merchant warrants that the goods have been properly stowed in
the container and that the thermostatic controls have been adequately set before receipt of the goods by Carrier</li>
	<li>Merchant's attention is drawn to the fact that refrigerated containers are not designed to freeze down cargo which has not
been presented for stuffing at or below its designated carrying temperature. Carrier shall not be responsible for the
consequences of cargo tendered at a higher temperature than that required for the transportation.</li>
	<li>If the above requirements are not complied with, Carrier shall not be liable for any loss of or damage to the goods
whatsoever.
</li>
</ol>
<h4 class="title" style="margin-top: 15px;">25. SEVERABILITY:
</h4>
<p>The terms of this BILL OF LADING shall be severable, and, if any part or term hereof shall be held invalid, such holding shall not
affect the validity or enforceability of any other part or term hereof.</p>
<h4 class="title" style="margin-top: 15px;">26. VARIATION OF THE CONTRACT::
</h4>
<p>This contract supersedes all prior agreement between the parties with respect to its subject matter. No servant or agent of Carrier
shall have power to waive or vary any of the terms hereof unless such variation is in writing and is specifically authorized or
ratified in writing by Carrier.
</p>
</div>
<div id="truck-limitation-tc" style="display: none;"></div>
<div id="warehouse-limitation-tc" style="display: none;">
    <h1 style="font-size: 18pt; font-family: 'open sans'; color: #3b3b3b; margin-bottom: 20px; font-weight: 600;">
        Warehouse Disclaimer
    </h1>

    <p>The liability, in the absence of higher value declared for carriage (subject to an excess valuation charge), is
        limited to a maximum of $100 per piece/shipment or $0.10/Lb for cargo lost, damaged, misdelivered or otherwise
        adversely effected.</p>

    <p>One can cover/insure higher values for their goods by asking that in writing to us over an email or thru our SLI
        form before the arrival/pickup of the shipment/package and agree to pay the premium amount thereof. Insurance is
        covered only if we get the breakdown valuation of carton/package by documentation cutoff date and that must be
        before the loss/damage is found.</p>
</div>
<div id="web-design-tc" style="display: none;">
    <h1 style="font-size: 18pt; font-family: 'open sans'; color: #3b3b3b; margin-bottom: 20px; font-weight: 600;">
        Website Disclaimer
    </h1>
    <h4 class="title" style="margin-top: 15px;">No Liability for Information</h4>

    <p>Air7Seas and all its affiliates, subsidiaries or other related companies (hereinafter called &quot;Air7Seas&quot;)
        have
        used and will use all reasonable efforts to include accurate and up&#45;to&#45;date information on its website.
        However,
        Air7Seas makes no warranties or representations, express or implied, as to the timeliness, accuracy or
        completeness of the information contained or referenced therein.</p>

    <p>All access and use of this site and any site linked to this site is at the risk of each user. Air7Seas is not
        liable in any manner whatsoever for any direct, indirect or consequential errors or omissions in the content of
        any such site or for the result obtained from the use of this information.</p>

    <p>Air7Seas reserves the right to make changes I any way, at any time, for any reason without prior notice, to the
        contents and information on this site, including materials, equipment, specifications, prices &amp;/or
        availability.</p>

    <p>Material contained in this website may pertain to products and services for certain markets only. Air7Seas
        explicitly disclaims any liability in connections with such charges. Links to third-party websites are provided
        for convenience only and are completely beyond the control of Air7Seas. We do not express any opinion on the
        content of any third&#45;party websites and expressly disclaim any liability for all third&#45;party information
        and use
        thereof. Air7Seas accepts no responsibility for the content, accuracy, completeness, legality or function of
        these websites.</p>
    <h4 class="title" style="margin-top: 20px;">Copyright</h4>

    <p>The entire content of this website is either the property of Air7Seas, or is used with the authorization of the
        owners, and is subject to copyright with all rights reserved. Reproduction of part or all the contents of the
        Air7Seas website in any form is prohibited other than for individual use only. For permission to reproduce any
        contents of this website for any public or commercial purpose, please <a href="mailto:info@air7seas.us"
                                                                                 style="font-size: 10pt; font-weight: 700;"
                                                                                 class="resource-link">send
            Email</a> our corporate
        communications department.</p>
    <h4 class="title" style="margin-top: 20px;">Applicable Law</h4>

    <p>Subject to the terms and conditions set forth herein, any use of this website and all legal disputes arising in
        connections therewith shall exclusively be governed by Swiss law.</p>
</div>
<div id="privacy-policy-tc" style="display: none;">
    <h1 style="font-size: 18pt; font-family: 'open sans'; color: #3b3b3b; margin-bottom: 20px; font-weight: 600;">
        Privacy Policy
    </h1>
    <h4 class="title">Privacy Notice</h4>

    <p>This privacy notice discloses the privacy practices for (air7seas.com). This privacy notice applies solely to
        information collected by this web site.</p>
    <h4 class="title">It will notify you of the following:</h4>

    <div style="padding-left: 15px; background-color: #f4f4f4;">
        <ul style="list-style: decimal; line-height: 2; padding: 15px;">
            <li>What personally identifiable information is collected from you through the web site, how it is used and
                with whom it may be shared.
            </li>
            <li>What choices are available to you regarding the use of your data.</li>
            <li>The security procedures in place to protect the misuse of your information.</li>
            <li>How you can correct any inaccuracies in the information.</li>
        </ul>
    </div>
    <h4 class="title">Information Collection, Use, and Sharing</h4>

    <p>We are the sole owners of the information collected on this site. We only have access to/collect information that
        you voluntarily give us via email or other direct contact from you. We will not sell or rent this information to
        anyone.</p>

    <p>We will use your information to respond to you, regarding the reason you contacted us. We will not share your
        information with any third party outside of our organization, other than as necessary to fulfill your request,
        e.g. to ship an order.</p>

    <p>Unless you ask us not to, we may contact you via email in the future to tell you about specials, new products or
        services, or changes to this privacy policy.</p>
    <h4 class="title">Your Access to and Control Over Information</h4>

    <p>You may opt out of any future contacts from us at any time. You can do the following at any time by contacting us
        via the email address or phone number given on our website:</p>

    <div style="padding-left: 15px; background-color: #f4f4f4;">
        <ul style="list-style: none; line-height: 2; padding: 15px;">
            <li>See what data we have about you, if any.</li>
            <li>Change/correct any data we have about you.</li>
            <li>Have us delete any data we have about you.</li>
            <li>Express any concern you have about our use of your data.</li>
        </ul>
    </div>
    <h4 class="title">Security</h4>

    <p>We take precautions to protect your information. When you submit sensitive information via the website, your
        information is protected both online and offline.</p>

    <p>Wherever we collect sensitive information (such as credit card data), that information is encrypted and
        transmitted to us in a secure way. You can verify this by looking for a closed lock icon at the bottom of your
        web browser, or looking for &quot;https&quot; at the beginning of the address of the web page.</p>

    <p>While we use encryption to protect sensitive information transmitted online, we also protect your information
        offline. Only employees who need the information to perform a specific job (for example, billing or customer
        service) are granted access to personally identifiable information. The computers/servers in which we store
        personally identifiable information are kept in a secure environment.</p>

    <p>If you feel that we are not abiding by this privacy policy, you should contact us immediately via telephone
        at<br>
        1-888-247-7732 or via email at <a href="mailto:info@air7seas.com" class="resource-link">info@air7seas.com</a>.
    </p>
    <h4 class="title">Links</h4>

    <p>This web site contains links to other sites. Please be aware that we are not responsible for the content or
        privacy practices of such other sites. We encourage our users to be aware when they leave our site and to read
        the privacy statements of any other site that collects personally identifiable information.</p>
</div>

<div id="slavery-human-trafficking-tc" style="display: none;">
    <h1 style="font-size: 18pt; font-family: 'open sans'; color: #3b3b3b; margin-bottom: 20px; font-weight: 600;">
         Slavery & Human Trafficking Policy
    </h1>
    <h4 class="title">Our policies on slavery and human trafficking</h4>
    <p>
         AIR7SEAS are committed in ensuring that there is no slavery by any means and human trafficking is not what we believe, which
        led to the success of our supply chain and logistics management. We have an Anti-Slavery policy where a group of members
        actively involved in making sure that there is no such kind of slavery and human trafficking in the services that we offer
        to our customers.
    </p>
    <h4 class="title">Due diligence processes for slavery and human trafficking</h4>
    <p>
         All our agents throughout the globe are well equipped with the policies which we maintain in our premises. There is no room
        for any kind of slavery inside or outside the management. Group of members are assigned for maintaining the diligence in
        the services which we offer to our beloved users.
    </p>
    <h4 class="title">Supplier adherence to our values</h4>
    <p>
         In order to tolerate towards slavery, we choose agents who are responsible, focused and straight forward. We sign agreement
        with our agents who will abide by the rules in the management. We conduct training programs for our staff regarding slavery
        and human trafficking where a group of expertise share their views and experience regarding these things which makes all
        our staff well equipped with Anti-Slavery policy.
    </p>
</div>
</div>
<div class="col span_3_of_12">
    

<link href="source/css/controls.css" rel="stylesheet" type="text/css" visible="true"/>
<style>
    table.estimate tr > td {
        padding: 2px 0px;
    }

    .txtborder {
        border: 1px solid #cccccc;
    }
</style>

<script>
    function f_t_Countries(value) {
        var f_country = document.getElementById('from_country').value;
        var t_country = document.getElementById('to_country').value;
        if (value == 'to_country') {
            if (t_country != 'US') {

            }
        } else if (value == 'from_country') {

        }
    }
</script>

<!--  DATE CALANDER  -->
<link rel="stylesheet" type="text/css" href="source/css/jquery.datetimepicker.css"/>
<script src="source/js/jquery-1.11.1.js"></script>


<script>
    $(function () {
        $("#txt_moving_date").datepicker();
    });
</script>

<div style="width: 225px; height: auto; background-color: #fafafa; margin-bottom: 20px;" align="center">
    <form method="post" action="sidebar-free-estimate-action.php">
        <div
            style="width: 223px;background-color: #056598; border: 1px solid #056598; padding: 5px 0px; font-family: arial; font-size: 10pt; color: #ffffff; font-weight: bold;">
            Get FREE Quotation
        </div>
        <table class="estimate" style="width: 100%; font-family: arial; font-size: 10pt;  border: 1px solid #cccccc;"
               cellspacing="0" cellpadding="0" border="0">
            <tr>
                <td style="padding-left: 10px; padding-top: 10px; font-size: 9pt; color: #666666; padding-bottom: 0px;">

                </td>
            </tr>
            <tr style="height: 33px;">
                <td align="center">
                    <select type="text" id="mode_transport" name="mode_transport" style="width: 90%; margin-top: 0px; "
                            class="form-textbox">
                        <option>Select Mode of Transport</option>
                        <option>By Air</option>
                        <option>By Sea</option>
                        <option>By Land</option>
                        <option>Not Sure</option>
                    </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">Select Commodity</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="center">
                    <select type="text" id="commodity" name="commodity" style="width: 90%; margin-top: 0px;"
                            class="form-textbox">
                        <option>Select From</option>
                        <option value="Select Commodity" selected="selected">Select Commodity</option><option value="Automobile/s">Automobile/s</option><option value="Boat">Boat</option><option value="Charity Goods">Charity Goods</option><option value="Computer/Electronics">Computer/Electronics</option><option value="General Cargo">General Cargo</option><option value="Hazardous Cargo">Hazardous Cargo</option><option value="Machinery">Machinery</option><option value="Metal Scrap">Metal Scrap</option><option value="Motorcycle/s">Motorcycle/s</option><option value="Perishable Cargo">Perishable Cargo</option><option value="Residential">Residential</option><option value="Residential with Vehicle (Auto, Motorcycle etc)">Residential with Vehicle (Auto, Motorcycle etc)</option><option value="Vehicle/s">Vehicle/s</option><option value="Waste Paper">Waste Paper</option><option value="Used Clothing">Used Clothing</option>

                    </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">From Country</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="center">
                    <select type="text" style="width: 90%; margin-top: 0px;" class="form-textbox" id="from_country"
                            name="from_country">
                        <OPTION Value="0">Select From</OPTION>
                                                    <option value="Afghanistan">
                                Afghanistan                            </option>
                                                    <option value="Alaska">
                                Alaska                            </option>
                                                    <option value="Albania">
                                Albania                            </option>
                                                    <option value="Algeria">
                                Algeria                            </option>
                                                    <option value="Angola">
                                Angola                            </option>
                                                    <option value="Antigua">
                                Antigua                            </option>
                                                    <option value="Argentina">
                                Argentina                            </option>
                                                    <option value="Aruba">
                                Aruba                            </option>
                                                    <option value="Australia">
                                Australia                            </option>
                                                    <option value="Austria">
                                Austria                            </option>
                                                    <option value="Bahamas">
                                Bahamas                            </option>
                                                    <option value="Bahrain">
                                Bahrain                            </option>
                                                    <option value="Bangladesh">
                                Bangladesh                            </option>
                                                    <option value="Barbados">
                                Barbados                            </option>
                                                    <option value="Belgium">
                                Belgium                            </option>
                                                    <option value="Belize">
                                Belize                            </option>
                                                    <option value="Benin">
                                Benin                            </option>
                                                    <option value="Brazil">
                                Brazil                            </option>
                                                    <option value="Brunei">
                                Brunei                            </option>
                                                    <option value="Bulgaria">
                                Bulgaria                            </option>
                                                    <option value="Cambodia">
                                Cambodia                            </option>
                                                    <option value="Cameroon">
                                Cameroon                            </option>
                                                    <option value="Canada">
                                Canada                            </option>
                                                    <option value="Canary Islands">
                                Canary Islands                            </option>
                                                    <option value="Caroline">
                                Caroline                            </option>
                                                    <option value="Chile">
                                Chile                            </option>
                                                    <option value="China">
                                China                            </option>
                                                    <option value="Columbia">
                                Columbia                            </option>
                                                    <option value="Comoros Islands">
                                Comoros Islands                            </option>
                                                    <option value="Congo">
                                Congo                            </option>
                                                    <option value="Croatia">
                                Croatia                            </option>
                                                    <option value="Cuba">
                                Cuba                            </option>
                                                    <option value="Cyprus">
                                Cyprus                            </option>
                                                    <option value="Czechoslovakia">
                                Czechoslovakia                            </option>
                                                    <option value="Denmark">
                                Denmark                            </option>
                                                    <option value="Djibouti">
                                Djibouti                            </option>
                                                    <option value="Dominica">
                                Dominica                            </option>
                                                    <option value="Dominican Republic">
                                Dominican Republic                            </option>
                                                    <option value="Ecuador">
                                Ecuador                            </option>
                                                    <option value="Egypt">
                                Egypt                            </option>
                                                    <option value="El Salvador">
                                El Salvador                            </option>
                                                    <option value="Estonia">
                                Estonia                            </option>
                                                    <option value="Ethiopia">
                                Ethiopia                            </option>
                                                    <option value="Fiji">
                                Fiji                            </option>
                                                    <option value="Finland">
                                Finland                            </option>
                                                    <option value="France">
                                France                            </option>
                                                    <option value="Gabon">
                                Gabon                            </option>
                                                    <option value="Gambia">
                                Gambia                            </option>
                                                    <option value="Germany">
                                Germany                            </option>
                                                    <option value="Ghana">
                                Ghana                            </option>
                                                    <option value="Gilbert">
                                Gilbert                            </option>
                                                    <option value="Grand Cayman">
                                Grand Cayman                            </option>
                                                    <option value="Greece">
                                Greece                            </option>
                                                    <option value="Grenada">
                                Grenada                            </option>
                                                    <option value="Guam">
                                Guam                            </option>
                                                    <option value="Guatemala">
                                Guatemala                            </option>
                                                    <option value="Guinea">
                                Guinea                            </option>
                                                    <option value="Guyana">
                                Guyana                            </option>
                                                    <option value="Haiti">
                                Haiti                            </option>
                                                    <option value="Hawaii">
                                Hawaii                            </option>
                                                    <option value="Honduras">
                                Honduras                            </option>
                                                    <option value="Hungary">
                                Hungary                            </option>
                                                    <option value="Iceland">
                                Iceland                            </option>
                                                    <option value="India">
                                India                            </option>
                                                    <option value="Indonesia">
                                Indonesia                            </option>
                                                    <option value="Iran">
                                Iran                            </option>
                                                    <option value="Iraq">
                                Iraq                            </option>
                                                    <option value="Ireland">
                                Ireland                            </option>
                                                    <option value="Israel">
                                Israel                            </option>
                                                    <option value="Italy">
                                Italy                            </option>
                                                    <option value="Ivory Coast">
                                Ivory Coast                            </option>
                                                    <option value="Jamaica">
                                Jamaica                            </option>
                                                    <option value="Japan">
                                Japan                            </option>
                                                    <option value="Jordan">
                                Jordan                            </option>
                                                    <option value="Kenya">
                                Kenya                            </option>
                                                    <option value="Kuwait">
                                Kuwait                            </option>
                                                    <option value="Latvia">
                                Latvia                            </option>
                                                    <option value="Lebanon">
                                Lebanon                            </option>
                                                    <option value="Liberia">
                                Liberia                            </option>
                                                    <option value="Libya">
                                Libya                            </option>
                                                    <option value="Macau">
                                Macau                            </option>
                                                    <option value="Madagascar">
                                Madagascar                            </option>
                                                    <option value="Malagasy">
                                Malagasy                            </option>
                                                    <option value="Malawi">
                                Malawi                            </option>
                                                    <option value="Malaysia">
                                Malaysia                            </option>
                                                    <option value="Maldives">
                                Maldives                            </option>
                                                    <option value="Malta">
                                Malta                            </option>
                                                    <option value="Mariana">
                                Mariana                            </option>
                                                    <option value="Marshall">
                                Marshall                            </option>
                                                    <option value="Martinique">
                                Martinique                            </option>
                                                    <option value="Mauritania">
                                Mauritania                            </option>
                                                    <option value="Mauritius">
                                Mauritius                            </option>
                                                    <option value="Mexico">
                                Mexico                            </option>
                                                    <option value="Micronesia">
                                Micronesia                            </option>
                                                    <option value="Montserrat">
                                Montserrat                            </option>
                                                    <option value="Morocco">
                                Morocco                            </option>
                                                    <option value="Mozambique">
                                Mozambique                            </option>
                                                    <option value="Myanmar">
                                Myanmar                            </option>
                                                    <option value="Namibia">
                                Namibia                            </option>
                                                    <option value="Netherlands">
                                Netherlands                            </option>
                                                    <option value="Netherlands Antilles">
                                Netherlands Antilles                            </option>
                                                    <option value="New Caledonia">
                                New Caledonia                            </option>
                                                    <option value="New Herbrides">
                                New Herbrides                            </option>
                                                    <option value="New Zealand">
                                New Zealand                            </option>
                                                    <option value="Nicaragua">
                                Nicaragua                            </option>
                                                    <option value="Nigeria">
                                Nigeria                            </option>
                                                    <option value="Norway">
                                Norway                            </option>
                                                    <option value="Oman">
                                Oman                            </option>
                                                    <option value="Pakistan">
                                Pakistan                            </option>
                                                    <option value="Panama">
                                Panama                            </option>
                                                    <option value="Papua New Gunea">
                                Papua New Gunea                            </option>
                                                    <option value="Peru">
                                Peru                            </option>
                                                    <option value="Philippines">
                                Philippines                            </option>
                                                    <option value="Poland">
                                Poland                            </option>
                                                    <option value="Portugal">
                                Portugal                            </option>
                                                    <option value="Puerto Rico">
                                Puerto Rico                            </option>
                                                    <option value="Qatar">
                                Qatar                            </option>
                                                    <option value="Reunion Islands">
                                Reunion Islands                            </option>
                                                    <option value="Romania">
                                Romania                            </option>
                                                    <option value="Russia">
                                Russia                            </option>
                                                    <option value="Saudi Arabia">
                                Saudi Arabia                            </option>
                                                    <option value="Scotland">
                                Scotland                            </option>
                                                    <option value="Senegal">
                                Senegal                            </option>
                                                    <option value="Seychelles">
                                Seychelles                            </option>
                                                    <option value="Sierra Leone">
                                Sierra Leone                            </option>
                                                    <option value="Singapore">
                                Singapore                            </option>
                                                    <option value="Solomon Islands">
                                Solomon Islands                            </option>
                                                    <option value="Somalia">
                                Somalia                            </option>
                                                    <option value="South Africa">
                                South Africa                            </option>
                                                    <option value="South Korea">
                                South Korea                            </option>
                                                    <option value="Spain">
                                Spain                            </option>
                                                    <option value="Sri Lanka">
                                Sri Lanka                            </option>
                                                    <option value="St. Kitts">
                                St. Kitts                            </option>
                                                    <option value="St. Maarten">
                                St. Maarten                            </option>
                                                    <option value="St. Vincent">
                                St. Vincent                            </option>
                                                    <option value="Sudan">
                                Sudan                            </option>
                                                    <option value="Surinam">
                                Surinam                            </option>
                                                    <option value="Sweden">
                                Sweden                            </option>
                                                    <option value="Switzerland">
                                Switzerland                            </option>
                                                    <option value="Syria">
                                Syria                            </option>
                                                    <option value="Tahiti">
                                Tahiti                            </option>
                                                    <option value="Taiwan">
                                Taiwan                            </option>
                                                    <option value="Tanzania">
                                Tanzania                            </option>
                                                    <option value="Thailand">
                                Thailand                            </option>
                                                    <option value="Togo">
                                Togo                            </option>
                                                    <option value="Tonga">
                                Tonga                            </option>
                                                    <option value="Trinidad">
                                Trinidad                            </option>
                                                    <option value="Tunisia">
                                Tunisia                            </option>
                                                    <option value="Turkey">
                                Turkey                            </option>
                                                    <option value="Tuvalu">
                                Tuvalu                            </option>
                                                    <option value="UAE">
                                UAE                            </option>
                                                    <option value="Uganda">
                                Uganda                            </option>
                                                    <option value="UK">
                                UK                            </option>
                                                    <option value="Ukraine">
                                Ukraine                            </option>
                                                    <option value="Uruguay">
                                Uruguay                            </option>
                                                    <option value="US">
                                US                            </option>
                                                    <option value="Venezuela">
                                Venezuela                            </option>
                                                    <option value="Vietnam">
                                Vietnam                            </option>
                                                    <option value="Western Samoa">
                                Western Samoa                            </option>
                                                    <option value="Yemen">
                                Yemen                            </option>
                                                    <option value="Yugoslavia">
                                Yugoslavia                            </option>
                                                    <option value="Zaire">
                                Zaire                            </option>
                                                    <option value="Zambia">
                                Zambia                            </option>
                                                    <option value="Zimbabwe">
                                Zimbabwe                            </option>
                                            </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">To Country</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="center"><select type="text" style="width: 90%; margin-top: 0px;" class="form-textbox"
                                           id="to_country" name="to_country">
                        <OPTION Value="0">Select To</OPTION>
                                                    <option value="Afghanistan">
                                Afghanistan                            </option>
                                                    <option value="Alaska">
                                Alaska                            </option>
                                                    <option value="Albania">
                                Albania                            </option>
                                                    <option value="Algeria">
                                Algeria                            </option>
                                                    <option value="Angola">
                                Angola                            </option>
                                                    <option value="Antigua">
                                Antigua                            </option>
                                                    <option value="Argentina">
                                Argentina                            </option>
                                                    <option value="Aruba">
                                Aruba                            </option>
                                                    <option value="Australia">
                                Australia                            </option>
                                                    <option value="Austria">
                                Austria                            </option>
                                                    <option value="Bahamas">
                                Bahamas                            </option>
                                                    <option value="Bahrain">
                                Bahrain                            </option>
                                                    <option value="Bangladesh">
                                Bangladesh                            </option>
                                                    <option value="Barbados">
                                Barbados                            </option>
                                                    <option value="Belgium">
                                Belgium                            </option>
                                                    <option value="Belize">
                                Belize                            </option>
                                                    <option value="Benin">
                                Benin                            </option>
                                                    <option value="Brazil">
                                Brazil                            </option>
                                                    <option value="Brunei">
                                Brunei                            </option>
                                                    <option value="Bulgaria">
                                Bulgaria                            </option>
                                                    <option value="Cambodia">
                                Cambodia                            </option>
                                                    <option value="Cameroon">
                                Cameroon                            </option>
                                                    <option value="Canada">
                                Canada                            </option>
                                                    <option value="Canary Islands">
                                Canary Islands                            </option>
                                                    <option value="Caroline">
                                Caroline                            </option>
                                                    <option value="Chile">
                                Chile                            </option>
                                                    <option value="China">
                                China                            </option>
                                                    <option value="Columbia">
                                Columbia                            </option>
                                                    <option value="Comoros Islands">
                                Comoros Islands                            </option>
                                                    <option value="Congo">
                                Congo                            </option>
                                                    <option value="Croatia">
                                Croatia                            </option>
                                                    <option value="Cuba">
                                Cuba                            </option>
                                                    <option value="Cyprus">
                                Cyprus                            </option>
                                                    <option value="Czechoslovakia">
                                Czechoslovakia                            </option>
                                                    <option value="Denmark">
                                Denmark                            </option>
                                                    <option value="Djibouti">
                                Djibouti                            </option>
                                                    <option value="Dominica">
                                Dominica                            </option>
                                                    <option value="Dominican Republic">
                                Dominican Republic                            </option>
                                                    <option value="Ecuador">
                                Ecuador                            </option>
                                                    <option value="Egypt">
                                Egypt                            </option>
                                                    <option value="El Salvador">
                                El Salvador                            </option>
                                                    <option value="Estonia">
                                Estonia                            </option>
                                                    <option value="Ethiopia">
                                Ethiopia                            </option>
                                                    <option value="Fiji">
                                Fiji                            </option>
                                                    <option value="Finland">
                                Finland                            </option>
                                                    <option value="France">
                                France                            </option>
                                                    <option value="Gabon">
                                Gabon                            </option>
                                                    <option value="Gambia">
                                Gambia                            </option>
                                                    <option value="Germany">
                                Germany                            </option>
                                                    <option value="Ghana">
                                Ghana                            </option>
                                                    <option value="Gilbert">
                                Gilbert                            </option>
                                                    <option value="Grand Cayman">
                                Grand Cayman                            </option>
                                                    <option value="Greece">
                                Greece                            </option>
                                                    <option value="Grenada">
                                Grenada                            </option>
                                                    <option value="Guam">
                                Guam                            </option>
                                                    <option value="Guatemala">
                                Guatemala                            </option>
                                                    <option value="Guinea">
                                Guinea                            </option>
                                                    <option value="Guyana">
                                Guyana                            </option>
                                                    <option value="Haiti">
                                Haiti                            </option>
                                                    <option value="Hawaii">
                                Hawaii                            </option>
                                                    <option value="Honduras">
                                Honduras                            </option>
                                                    <option value="Hungary">
                                Hungary                            </option>
                                                    <option value="Iceland">
                                Iceland                            </option>
                                                    <option value="India">
                                India                            </option>
                                                    <option value="Indonesia">
                                Indonesia                            </option>
                                                    <option value="Iran">
                                Iran                            </option>
                                                    <option value="Iraq">
                                Iraq                            </option>
                                                    <option value="Ireland">
                                Ireland                            </option>
                                                    <option value="Israel">
                                Israel                            </option>
                                                    <option value="Italy">
                                Italy                            </option>
                                                    <option value="Ivory Coast">
                                Ivory Coast                            </option>
                                                    <option value="Jamaica">
                                Jamaica                            </option>
                                                    <option value="Japan">
                                Japan                            </option>
                                                    <option value="Jordan">
                                Jordan                            </option>
                                                    <option value="Kenya">
                                Kenya                            </option>
                                                    <option value="Kuwait">
                                Kuwait                            </option>
                                                    <option value="Latvia">
                                Latvia                            </option>
                                                    <option value="Lebanon">
                                Lebanon                            </option>
                                                    <option value="Liberia">
                                Liberia                            </option>
                                                    <option value="Libya">
                                Libya                            </option>
                                                    <option value="Macau">
                                Macau                            </option>
                                                    <option value="Madagascar">
                                Madagascar                            </option>
                                                    <option value="Malagasy">
                                Malagasy                            </option>
                                                    <option value="Malawi">
                                Malawi                            </option>
                                                    <option value="Malaysia">
                                Malaysia                            </option>
                                                    <option value="Maldives">
                                Maldives                            </option>
                                                    <option value="Malta">
                                Malta                            </option>
                                                    <option value="Mariana">
                                Mariana                            </option>
                                                    <option value="Marshall">
                                Marshall                            </option>
                                                    <option value="Martinique">
                                Martinique                            </option>
                                                    <option value="Mauritania">
                                Mauritania                            </option>
                                                    <option value="Mauritius">
                                Mauritius                            </option>
                                                    <option value="Mexico">
                                Mexico                            </option>
                                                    <option value="Micronesia">
                                Micronesia                            </option>
                                                    <option value="Montserrat">
                                Montserrat                            </option>
                                                    <option value="Morocco">
                                Morocco                            </option>
                                                    <option value="Mozambique">
                                Mozambique                            </option>
                                                    <option value="Myanmar">
                                Myanmar                            </option>
                                                    <option value="Namibia">
                                Namibia                            </option>
                                                    <option value="Netherlands">
                                Netherlands                            </option>
                                                    <option value="Netherlands Antilles">
                                Netherlands Antilles                            </option>
                                                    <option value="New Caledonia">
                                New Caledonia                            </option>
                                                    <option value="New Herbrides">
                                New Herbrides                            </option>
                                                    <option value="New Zealand">
                                New Zealand                            </option>
                                                    <option value="Nicaragua">
                                Nicaragua                            </option>
                                                    <option value="Nigeria">
                                Nigeria                            </option>
                                                    <option value="Norway">
                                Norway                            </option>
                                                    <option value="Oman">
                                Oman                            </option>
                                                    <option value="Pakistan">
                                Pakistan                            </option>
                                                    <option value="Panama">
                                Panama                            </option>
                                                    <option value="Papua New Gunea">
                                Papua New Gunea                            </option>
                                                    <option value="Peru">
                                Peru                            </option>
                                                    <option value="Philippines">
                                Philippines                            </option>
                                                    <option value="Poland">
                                Poland                            </option>
                                                    <option value="Portugal">
                                Portugal                            </option>
                                                    <option value="Puerto Rico">
                                Puerto Rico                            </option>
                                                    <option value="Qatar">
                                Qatar                            </option>
                                                    <option value="Reunion Islands">
                                Reunion Islands                            </option>
                                                    <option value="Romania">
                                Romania                            </option>
                                                    <option value="Russia">
                                Russia                            </option>
                                                    <option value="Saudi Arabia">
                                Saudi Arabia                            </option>
                                                    <option value="Scotland">
                                Scotland                            </option>
                                                    <option value="Senegal">
                                Senegal                            </option>
                                                    <option value="Seychelles">
                                Seychelles                            </option>
                                                    <option value="Sierra Leone">
                                Sierra Leone                            </option>
                                                    <option value="Singapore">
                                Singapore                            </option>
                                                    <option value="Solomon Islands">
                                Solomon Islands                            </option>
                                                    <option value="Somalia">
                                Somalia                            </option>
                                                    <option value="South Africa">
                                South Africa                            </option>
                                                    <option value="South Korea">
                                South Korea                            </option>
                                                    <option value="Spain">
                                Spain                            </option>
                                                    <option value="Sri Lanka">
                                Sri Lanka                            </option>
                                                    <option value="St. Kitts">
                                St. Kitts                            </option>
                                                    <option value="St. Maarten">
                                St. Maarten                            </option>
                                                    <option value="St. Vincent">
                                St. Vincent                            </option>
                                                    <option value="Sudan">
                                Sudan                            </option>
                                                    <option value="Surinam">
                                Surinam                            </option>
                                                    <option value="Sweden">
                                Sweden                            </option>
                                                    <option value="Switzerland">
                                Switzerland                            </option>
                                                    <option value="Syria">
                                Syria                            </option>
                                                    <option value="Tahiti">
                                Tahiti                            </option>
                                                    <option value="Taiwan">
                                Taiwan                            </option>
                                                    <option value="Tanzania">
                                Tanzania                            </option>
                                                    <option value="Thailand">
                                Thailand                            </option>
                                                    <option value="Togo">
                                Togo                            </option>
                                                    <option value="Tonga">
                                Tonga                            </option>
                                                    <option value="Trinidad">
                                Trinidad                            </option>
                                                    <option value="Tunisia">
                                Tunisia                            </option>
                                                    <option value="Turkey">
                                Turkey                            </option>
                                                    <option value="Tuvalu">
                                Tuvalu                            </option>
                                                    <option value="UAE">
                                UAE                            </option>
                                                    <option value="Uganda">
                                Uganda                            </option>
                                                    <option value="UK">
                                UK                            </option>
                                                    <option value="Ukraine">
                                Ukraine                            </option>
                                                    <option value="Uruguay">
                                Uruguay                            </option>
                                                    <option value="US">
                                US                            </option>
                                                    <option value="Venezuela">
                                Venezuela                            </option>
                                                    <option value="Vietnam">
                                Vietnam                            </option>
                                                    <option value="Western Samoa">
                                Western Samoa                            </option>
                                                    <option value="Yemen">
                                Yemen                            </option>
                                                    <option value="Yugoslavia">
                                Yugoslavia                            </option>
                                                    <option value="Zaire">
                                Zaire                            </option>
                                                    <option value="Zambia">
                                Zambia                            </option>
                                                    <option value="Zimbabwe">
                                Zimbabwe                            </option>
                                            </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">Moving Date</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="left">
                    <input type="text" id="txt_moving_date" name="txt_moving_date" class="form-textbox"
                           style="width: 77%; margin-left: 12px;" placeholder="Expected date to ship">
                    <img src="source/images/calendar.PNG" style="position: absolute; padding-top: 3px;">
                </td>
            </tr>
            <tr style="height: 33px;">
                <td align="right" style="padding: 5px 13px 10px 10px;">
                    <input type="submit" id="submit_quote" name="submit_quote" class="naviBlue"
                           value="SUBMIT" style="height: 25px; padding-top: 3px"></td>
            </tr>
        </table>
        <script src="source/js/jquery.datetimepicker.js"></script>
        <script>
            $('#txt_moving_date').datetimepicker({
                lang: 'en',
                timepicker: false,
                closeOnDateSelect: true,
                format: 'm/d/Y',
                formatDate: 'Y/m/d',
                minDate: '2017/01/01', // yesterday is minimum date
                //startDate: '2015/01/01',
                autodateonstart: true,
                maxDate: '2030/12/31' // and tommorow is maximum date calendar
            });
        </script>
    </form>
</div>


<a href="cargo-tracking.php"><img src="source/images/cargo-tracking.png" style="margin-bottom: 20px;"></a>
<a href="about-air7seas.php"><img src="source/images/exp.png" style="margin-bottom: 20px;"></a>
<a href="customer-review.php"><img src="source/images/tp-logo-customer-review.PNG" style="margin-bottom: 20px;"></a>
</div>
</div>
</div>
</div>
</div>
<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" lang="en">


<head>
    <!--Start of Zopim Live Chat Script
    <script type="text/javascript">
        window.$zopim || (function (d, s) {
            var z = $zopim = function (c) {
                z._.push(c)
            }, $ = z.s =
                d.createElement(s), e = d.getElementsByTagName(s)[0];
            z.set = function (o) {
                z.set.
                    _.push(o)
            };
            z._ = [];
            z.set._ = [];
            $.async = !0;
            $.setAttribute('charset', 'utf-8');
            $.src = '//v2.zopim.com/?2NBKvMLseKA8C45Gr5ywmelLErtAkht6';
            z.t = +new Date;
            $.
                type = 'text/javascript';
            e.parentNode.insertBefore($, e)
        })(document, 'script');
    </script>
    End of Zopim Live Chat Script-->
    
    <!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = '3kWxTfUv3x';var d=document;var w=window;function l(){
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
<!-- {/literal} END JIVOSITE CODE -->

    <link href="source/css/sole.css" rel="stylesheet">

<body class="vpform pgTrustPilot" lang="en-GB" align="center">


<div id="footerinfo" style="width: 100%; background-color: #cccccc" align="center">
    <div style="width: 980px; background-color: #ffffff; padding: 10px 0px;" align="left">
        <div id="BreadcrumbWrapper">
            <div class="section group">
                <div class="col span_12_of_12" style="line-height: 23px; border-right: 1px solid #dddddd; ">
                </div>
            </div>
            <hr>
        </div>
        <img src="source/images/logos.jpg" alt="" style="width: 980px;">
        <div style="margin-left:40px;">
            <a id="bbblink" class="ruvtbum" target="_blank" href="https://www.bbb.org/us/ca/milpitas/profile/logistics/air-7-seas-transport-logistics-1216-213698#bbbseal"
        title="AIR 7 SEAS Transport Logistics Inc, Logistics, Milpitas, CA"
        style="display: block;position: relative;overflow: hidden; width: 60px; height: 108px; margin: 0">
        <img style="padding: 0px; border: none;" id="bbblinkimg" src="https://seal-sanjose.bbb.org/logo/ruvtbum/air-7-seas-transport-logistics-213698.png" width="120" height="108" alt="AIR 7 SEAS Transport Logistics Inc, Logistics, Milpitas, CA" />
        </a>    
        </div>
        
        <script type="text/javascript">var bbbprotocol = ( ("https:" == document.location.protocol) ? "https://" : "http://" ); (function(){var s=document.createElement('script');s.src=bbbprotocol + 'seal-sanjose.bbb.org' + unescape('%2Flogo%2Fair-7-seas-transport-logistics-213698.js');s.type='text/javascript';s.async=true;var st=document.getElementsByTagName('script');st=st[st.length-1];var pt=st.parentNode;pt.insertBefore(s,pt.nextSibling);})();
        </script>
    </div>
</div>
<!--footer-->
<footer style="background-color: #4d4d4d">
    <div class="DB MMdLFtR">
        <div class="FL DB MMdLFtRa" style="padding-left: 75px;">

            <div id="FtR" class="LH20 footer-links">
                <div class="left-section FL">
                    <div class="left-wrapper FL">
                        <section class="ordering-fromus">
                            <div class="title">
                                AIR 7 SEAS
                            </div>
                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="about-air7seas.php" id="aContact">About Us</a>
                                    <a href="feedback.php" id="aFAQ">Feedback</a>
                                    <a href="shipping-news.php" id="aOrdertracking">News &amp;
                                        Events</a>
                                    <a href="#">Privacy Policy</a>
                                    <a href="terms-and-conditions.php">Terms &amp;
                                        Conditions</a>
                                    <a href="jobs.php">Jobs</a>
                                </li>
                            </ul>
                        </section>
                        <section class="help-support">
                            <div class="title">
                                SERVICES
                            </div>

                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="international-freight.php">International &#45;
                                        Freight</a>
                                    <a href="domestic-freight.php">Domestic &#45;
                                        Freight</a>
                                    <a href="autos-vehicles-machinery.php">Machinery &amp; Vehicles</a>
                                    <a href="freight-forwarder.php">Freight Forwarding</a>
                                    <a href="customs-release.php">Customs Release</a>
                                    <a href="moving.php">Movers</a>
                                </li>
                            </ul>
                        </section>
                        <section class="information">
                            <div class="title">
                                SUPPORT
                            </div>
                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="faq.php">Frequently Asked Questions</a>
                                    <a href="moving-tips.php">Moving Tips</a>

                                    <a href="payments.php" id="aFreeRecycle">Payment Options</a>
                                    <a href="procedural-steps-for-claim-submition.php">Claim
                                        Submission Procedures</a>
                                    <a href="isf.php">Importer Security Filing (ISF)</a>
                                    <a href="order-online-insurance.php">Order Online -
                                        Insurance</a>

                                </li>
                            </ul>
                        </section>
                    </div>
                    <div class="social-links">


                    </div>
                </div>
                <section class="newsletter">
                    <div class="title">CORPORATE OFFICE</div>
                    <div class="footer-contact">
                        <ul>
                            <li class="f-map"><a
                                    href="contact-us.php"
                                    target="_blank">1815 Houret Court, <br> Milpitas, CA 95035, US</a></li>
                            <li class="f-phone"><span><a href="tel:+18882477732">Call Us: 1-888-247-7732</a></span></li>
                            <li class="f-mail"><a href="mailto:info@air7seas.us">info (@) air7seas.us</a></li>
                        </ul>
                    </div>
                    <br><br>

                    <div>
                        <a href="https://www.facebook.com/pages/Air7Seas-Transport-Logistics-Inc/731149066945233" target="_blank">
                            <img src="source/images/icons/fb.png" style="margin-top: 7px; width: 25px;">
                        </a>&nbsp;
                        <a href="https://twitter.com/Air7seas" target="_blank">
                            <img src="source/images/icons/twitter.png" style="margin-top: 7px; width: 25px;">
                        </a>&nbsp;
                        <a href="https://www.google.com/maps/place/AIR+7+SEAS+Transport+Logistics+Inc/@37.405497,-121.8994427,17z/data=!3m1!4b1!4m5!3m4!1s0x808fceb215c020c3:0x183384c4fb534d3c!8m2!3d37.405497!4d-121.897254" target="_blank">
                            <img src="source/images/icons/gp.png" style="margin-top: 7px; width: 25px;">
                        </a>
                    </div>

                </section>
            </div>
        </div>
    </div>

</footer>

<div class="baseline-footer">
    <div class="baseline-footer-wrapper">
        <section class="FL" itemprop="provider" itemscope itemtype="http://schema.org/Organization">
            <div class="FL">

                <meta itemprop="url" content="http://www.air7seas.com/"/>
                <meta itemprop="name" content="Air 7 Seas Transport Logistics Pvt Ltd"/>
                <meta itemprop="email" content="info@air7seas.com "/>
                <div itemprop="location" itemscope itemtype="http://www.schema.org/LocalBusiness">

                    <meta itemprop="openingHours" content="Mo-Fr 08:00-16:00"/>
                    <meta itemprop="openingHours" content="Sa-Su Holiday"/>
                    <div itemprop="geo" itemscope itemtype="http://schema.org/GeoCoordinates">
                        <meta itemprop="latitude" content="53.55519"/>
                        <meta itemprop="longitude" content="-3.041651"/>
                    </div>
                </div>

            </div>
            <div class="contact-information">
                <div id="pnlUKFooter">

                    <div class="address" itemprop=address itemscope itemtype=http://schema.org/PostalAddress>
                        <span class="address-image"></span>

                        <div class="address-wrapper">
                            <span itemprop=streetAddress><a href="contact-us.php" style="color: #cfcfcf;">1815 Houret
                                    Court,<br> Milpitas, CA 95035</a></span>,
                            <span itemprop=addressLocality>USA</span>
                        </div>
                    </div>
                    <div class="phone-number">
                        <span class="phone-image"></span>
                        <span class="telephone" itemprop=telephone><a href="tel:+18882477732" style="color: #cfcfcf;">1-888-247-7732</a></span>
                        <span class="sales-support">(Customer Support)</span>
                    </div>
                    <div class="email-address">
                        <span class="email-img"></span>
                        <span itemprop=email><a class="mail-id"
                                                href="mailto:info@air7seas.us">info (@) air7seas.us</a></span>
                    </div>


                </div>

            </div>
        </section>


        <div itemprop="copyrightHolder" itemscope itemtype="http://www.schema.org/Organization"
             class="copywrite-holder">
            <meta itemprop="url" content="http://www.air7seas.com/"/>
            <meta itemprop="name" content="Air 7 Seas Transport Logistics Pvt Ltd"/>

            <meta itemprop="email" content="info@air7seas.com "/>

            Copyright <span class="copyrights">&copy;</span> AIR 7 SEAS 2014 &#45; 2015
        </div>
        <meta itemprop="copyrightYear" content="1986-2014"/>

        <div class="divAuthorisedText">Authorised and regulated by AIR 7 SEAS 95035</div>


    </div>
</div>

</body>
</html>

</body>
</html>