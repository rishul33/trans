
<!DOCTYPE html>
<html>
<head>
    <title>Shipping to Vietnam - AIR 7 SEAS</title>
    <link rel="shortcut icon" href="source/images/a7s-icon.ico"/>
    <meta charset="utf-8"/>
    <meta name="description"
          content="shipping to vietnam, shipping from us to vietnam, shipping to vietnam from usa, cheap shipping overseas, international movers, shipping household goods, air freight to vietnam, sea freight to vietnam, international freight shipping quote, international freight companies, low cost international shipping, cheap shipping to vietnam, cheap shipping companies">
    <meta name="keywords"
          content="Overseas Relocation, Moving Overseas, Relocation Services, Shipping vietnam, Shipping USA, Freight Forwarder, Air Freight, Air Cargo, Customs Clearance, International Shipping Companies, Moving Estimate, Shipping Quote, Moving International, Domestic Movers, Shipping Agent, Shipping International, International Moving Service, Cargo Agent, Customs Broker, International Mover, Household Goods, Commercial Goods, Breakbulk Cargo, Car Shipping, Motorbike Shipping, Auto Vehicle Mechinery, Cargo Consolidation, Freight Service Provider">
    <meta name="author" content="Air 7 Seas Transport Logistics Pvt Ltd">
    <meta name="google-translate-customization" content="724f46ee59082123-f680bb4c38d4a98b-g3f7ff65b8c80c329-28"></meta>
    <!--  <base href="http://www.air7seas.com/"> -->

    <link href="source/css/responsive.css" rel="stylesheet">
    <link href="source/css/sole.css" rel="stylesheet" type="text/css" visible="true"/>

    <script src="source/modal-popup/jquery-1.4.3.min.js" type="text/javascript"></script>
    <link href="source/css/modal-popup.css" rel="stylesheet">
    <style>

        .goog-te-banner-frame.skiptranslate {
            display: none !important;
        }

        .goog-te-gadget.icon {
            display: none;
        }

        body {
            top: 0px !important;
        }

        p, h4 {
            margin: 10px 0px;;
        }

        ul.ff-service {
            line-height: 2;
            list-style: square;
            padding-left: 15px;
        }

        ul.ff-service li {
            margin: 5px;
            line-height: 1.5;
            list-style: square;

        }

        #mab_bg {
            top: 0;
            width: 100%;
            background-color: rgba(0, 0, 0, 0.6);
            position: fixed;
            z-index: 999;
            height: 100%;
            display: none;
        }

        #map_expand {
            opacity: 1.6;
            margin-top: 10px;
            position: relative;
            z-index: 999999;
        }
    </style>

    <script>
        /*(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

        ga('create', 'UA-54008281-2', 'auto');
        ga('send', 'pageview');*/

    </script>

    <script>
        $(function () {
            $("#show_map").click(function () {
                $("#mab_bg").show(400);
            });
            $("#close_info").click(function () {
                $("#mab_bg").hide(400);
            });
            $("#mab_bg").click(function () {
                $("#mab_bg").hide(400);
            });
        });
    </script>
</head>
<body>
  <!-- Google Code for Shipping to Vietnam Conversion Page -->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 975958229;
var google_conversion_language = "en";
var google_conversion_format = "3";
var google_conversion_color = "ffffff";
var google_conversion_label = "I3OuCOrv2mQQ1eGv0QM";
var google_remarketing_only = false;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/975958229/?label=I3OuCOrv2mQQ1eGv0QM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>
<div class="notranslate">
    <!DOCTYPE html>
<html>
<head>
    <title></title>
    <link href="source/css/sole.css" rel="stylesheet" type="text/css" visible="true"/>
    <link href="source/css/skin.css" rel="stylesheet" type="text/css" visible="true"/>

    <link
        href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800'
        rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="source/css/megadrop.css"/>
    <script type="text/javascript" src="source/js/megascripts.js"></script>
    <style>
        .searchbox {
            height: 28px;
            width: 225px;
            border: 1px solid #dadada;
            border-top-left-radius: 3px;
            border-bottom-left-radius: 3px;
            padding-left: 10px;
            font-size: 12px;
            color: #9b9b9b
        }

        .searchbutton {
            cursor: pointer;
            background-image: url('source/images/search.GIF');
            height: 30px;
            width: 70px;
            margin-top: 0;
            color: transparent
        }

        .txtSearchbox::-webkit-input-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox:-moz-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox::-moz-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox:-ms-input-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }
    </style>
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NQDLZPP');</script>
<!-- End Google Tag Manager -->
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NQDLZPP"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div id="topLine">
</div>
<div id="main-header" align="center" style="font-family: Arial;">
    <div id="main-header-area" align="left">
        <a href="index.php">
            <img src="source/images/logo-new.png" alt="Air 7 Seas" style="float: left; position: relative;"></a>

        <div class="top-small-link" style=" vertical-align: middle">
            <table border="0">
                <tr style="vertical-align: top">
                    <td style="padding-top: 3px;">
                        <a href="cargo-tracking.php" style="color: #404040; font-family: Arial;"><b>Cargo
                                Tracking</b></a>|
                        <a href="about-air7seas.php">About Us</a>|
                        <a href="https://portal.cargoez.com/air7seas/login" target="_blank">Login</a>|
                        <a href="shipping-news.php">News &amp; Events</a>

                    </td>
                    <td style="vertical-align: top;"><img src="source/images/phone-ico.PNG" alt=""
                                                          style="margin-top: 0px;">
                    </td>
                    <td style="padding: 3px 0 0 5px; width: 185px;">
                        <span style="font-size: 13pt; float: right"><span style="font-size: 9pt;">Toll Free:</span>
                        <a href="tel:+18882477732"
                           style="padding-left: 0px; padding-right: 0px; margin-right: 0px; color: #026799;"><b>1-888-247-7732<b/></a></span>
                    </td>

                </tr>
                <tr>
                    <td colspan="3" style="">
                        <div id="SrCl" style="padding-top: 8px; float: right">
                            <form method="post" action="search-results.php">

                                <input type="text" id="find" name="find" autocomplete="off"
                                       class="searchbox txtSearchbox" placeholder="How can i help you...?">
                                <input type="submit" name="" style="border:0px; height: 28px;" class="searchbutton"
                                       alt="Search"/>

                            </form>
                        </div>
                    </td>
                </tr>
            </table>


        </div>


    </div>
</div>
<div id="menu-bar" style="width: 100%; background-color: #1e6a89;" align="center">
<div style="width: 980px;" align="left">
<ul class="nav-mainmenu clearfix animated">
<li><a href="index.php">Home</a></li>
<li>
    <a href="#">Services</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px; ">

            <ul class="menu-items">
                <li class="seperator"><a href="international-freight.php" style="font-weight: 600">International
                        Freight</a></li>
                <li class="seperator"><a href="domestic-freight.php">Domestic Freight</a></li>
                <li class="seperator"><a href="freight-forwarder.php">Freight Forwarding</a></li>
                <li class="seperator"><a href="freight-consultation.php">Consultation</a></li>

            </ul>
        </div>
    </div>
</li>
<li><a href="#">Products</a>

    <div class="container-2" style="width: 500px;">
        <table border="0">
            <tr>
                <td style="border-right:1px solid #ccc; vertical-align: top;">
                    <div class="col1" style="width: 250px;">

                        <ul class="menu-items">


                            <li class="seperator"><a href="shipping-to-vietnam.php"><img
                                        src="source/images/Vietnam-Flag-icon.png" alt="Vietnam Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Saigon Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-india.php"><img
                                        src="source/images/India-Flag-icon.png" alt="India Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">India Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-middle-east.php"><img
                                        src="source/images/MiddleEast-Flag-icon.png" alt="Shipping to Middle East"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Middle East Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-china.php"><img
                                        src="source/images/China-Flag-icon.png" alt="China Shipper"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">China Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-philippines.php"><img
                                        src="source/images/Philippines-Flag-icon.png" alt="Philippines Shipper"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Manila Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-spain.php"><img
                                        src="source/images/Spain-Flag-icon.png" alt="Spain Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Spain Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-mexico.php"><img
                                        src="source/images/Mexico-Flag-icon.png" alt="Mexico Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Mexico Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="autos-to-canada.php"><img
                                        src="source/images/Canada-Flag-icon.png" alt="Canada Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Autos to Canada</span></a>
                            </li>
  <li class="seperator"><a href="importers-logistics-rep.php">Importer&#39;s Rep</a></li>

                        </ul>
                    </div>
                </td>
                <td style="vertical-align: top;">
                    <div class="col1" style="width: 250px;">

                        <ul class="menu-items">
                            <li class="seperator"><a href="shipping-to-africa.php">
                                    <img src="source/images/Africa-Flag-icon.png" alt="AfriCargo Express" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">AfriCargo Express</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-latin-america.php">
                                    <img src="source/images/Latino-Flag-icon.png" alt="Latino Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Latino Shipper</span></a>
                            </li>
                              <li class="seperator"><a href="nvo.php">
                                    <img src="source/images/lcl-icon.jpg" alt="Latino Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Cargo-Coloader LCL</span></a>
                            </li>
                            <li class="seperator"><a href="a7s-pre-fulfilment-service.php"><img src="source/images/receiving-center-icon.png"
                                                                                      alt="Air7seas Pre-Fulfillment Service" width="22px"
                                                                                      style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Pre-Fulfillment &amp; Delivery </span></a></li>
                            <li class="seperator"><a href="receiving-center.php"><img src="source/images/receiving-center-icon.png"
                                                                                      alt="Mexico Shipper" width="22px"
                                                                                      style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Pre-Shipping Receiving Center</span></a></li>
                            <!--<li class="seperator"><a href="receiving-center.php">Receiving Center</a></li>-->
                            <li class="seperator"><a href="partners-agents.php"><img
                                        src="source/images/partners-agents-icon.png" alt="Canada Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Partners - Agents</span></a>
                            </li>
                            <li class="seperator"><a href="autos-vehicles-machinery.php"><img
                                        src="source/images/autos-vehicle-mechinery-icon.png" alt="Mexico Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Autos Vehicles Machinery</span></a>
                            </li>
                            <li class="seperator"><a href="transloading-transhipment.php">Transloading -
                                    Transhipment</a></li>
                            <li class="seperator"><a href="ship-hazardous-perishable-goods.php">Hazardous &amp;
                                    Perishable</a></li>


                        </ul>
                    </div>
                </td>
            </tr>
        </table>


    </div>
</li>
<li><a href="#">Mover &amp; Relocation</a>

    <div class="container-4" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="move-household-goods.php">Household Goods</a></li>
                <li class="seperator"><a href="ship-commercial-goods.php">Commercial Goods</a></li>
                <!--     <li class="seperator"><a href="#">Countries served</a></li> -->
            </ul>
        </div>
    </div>
</li>
<li><a href="#">Freight Carrier</a>

    <div class="container-4" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="air-freight-carrier.php">Air Freight Carrier</a></li>
                <li class="seperator"><a href="ocean-freight-carrier.php">Ocean Freight Carrier</a>
                </li>
                <li class="seperator"><a href="soc-movements.php">SOC Movements</a></li>
            </ul>
        </div>
    </div>
</li>
<li>
    <a href="#">Customs Release</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="export-import.php"">Export - Import</a></li>
                <li class="seperator"><a href="isf.php">ISF / AMS</a></li>
                <li class="seperator"><a href="importers-logistics-rep.php">Importer&#39;s Rep</a></li>
            </ul>
        </div>
    </div>
</li>

<li><a href="#">Insurance</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="cargo-insurance-coverage-types.php">Coverage Types</a></li>
                <li class="seperator"><a href="free-estimate-insurance.php">Free Estimate - Insurance</a>
                </li>
                <li class="seperator"><a href="order-online-insurance.php">Order Online - Insurance</a></li>
                <li class="seperator"><a href="claim-submission.php">Claim submission Form</a></li>
                <li class="seperator"><a href="faq-insurance.php">FAQ</a></li>
                <!--<li class="seperator"><a href="#">Resources - Insurance</a></li>-->
                <li class="seperator"><a href="damages-to-the-goods-by-customs.php">Damages to the goods by
                        Customs</a></li>

            </ul>
        </div>
    </div>
</li>
<li><a href="#">Contact Us</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="contact-us.php">Contacts</a></li>
                <li class="seperator"><a href="free-estimatesdetails.php">Get an Estimate</a></li>
                <li class="seperator"><a href="ordernowdetails.php">Book a Shipment</a></li>
                <li class="seperator"><a href="feedback.php">Feedback</a></li>
                <li class="seperator"><a href="complaint.php">Complaint</a></li>
                <li class="seperator"><a href="customer-review.php">Testimonial</a></li>
                <li class="seperator"><a href="claim-submission.php">Claim submission</a></li>
                <li class="seperator"><a href="terms-and-conditions.php">Terms &amp; Conditions</a></li>
                <li class="seperator"><a href="jobs.php">Jobs</a></li>
            </ul>
        </div>
    </div>
</li>
<li><a href="#" class="last-list">Tools &amp; Resources</a>

    <div class="container-1 right" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="forms-downloads.php">Documents &amp; Forms</a></li>
                <li class="seperator"><a href="payments.php">Payment options</a></li>
                <li class="seperator"><a href="moving-tips.php">Moving Tips</a></li>
                <li class="seperator"><a href="container-sizes.php">Container Sizes for Sea</a></li>
                <li class="seperator"><a href="faq.php">FAQs</a></li>
                <li class="seperator"><a href="shipping-news.php">News &amp; Events</a></li>
                <li class="seperator"><a href="ask-a-question.php">Ask a question</a></li>
            </ul>
        </div>
    </div>
</li>

</ul>
</div>

</div>
<div id="info-bar" style="box-shadow: 0px 3px 3px 0px rgba(0, 0, 0, 0.15); position: relative; z-index: 100;"
     align="center">
    <div id="info-bar-area" align="left">
        <div class="top-thin-links">
            <div class="thin-links-wrapper">
                <a class="review" href="free-estimatesdetails.php"><span class="icon"></span><span>Free Shipping Estimate</span></a>
                <a class="finance" href="estimate-sizeof-shipment.php"><span
                        class="icon"></span><span>Moving Calculator</span></a>
                <a class="facebook" href="moving-tips.php"><span class="icon"></span><span>Moving Tips</span></a>
                <a class="catalogue" href="ordernowdetails.php"><span class="icon"></span><span>Order Online</span></a>
                <a class="trade-account" href="ask-a-question.php"><span class="icon"></span><span>Shipping ?</span></a>
            </div>
        </div>
    </div>
</div>

</body>
</html>
</div>
<div id="contents" align="center">
<!--       MODAL POPUP STARTS      -->
<div id="mab_bg" style="">
    <div id="map_expand" style="opacity: 100;">
        <table style="border: 2px solid #336699; background-color: #FFFFFF;"
               cellpadding="3" cellspacing="0">
            <tr>
                <td class="web_dialog_title">Vietnam Cargo Service Map</td>
                <td class="web_dialog_title align_right">
                    <a href="#" id="close_info">Close</a>
                </td>
            </tr>
            <tr style="height: 0px;">
                <td colspan="2"></td>
            </tr>
            <tr>
                <td colspan="2" style="padding: 5px;">
                    <img src="source/documents/maps/vietnam-map.jpg" alt="Vietnam Cargo Service Map"
                         style="width: 600px; height: 590px; ">
                </td>
            </tr>
            <tr>
                <td colspan="2" align="right"
                    style="padding-right: 20px; font-size: 11pt; font-weight: 600;">
                    <a href="source/documents/maps/vietnam-map.jpg" class="resource-link"></a>
                </td>
            </tr>
        </table>
    </div>
</div>
<!--       MODAL POPUP ENDS      -->

<div id="contentsArea" align="left" style="padding-left: 20px;">

<!-- Top Information Bar -->
<div id="BreadcrumbWrapper" style="width: 940px;">
    <div id="Breadcrumb" class="Breadcrumb BoxSBB notranslate">
         <span itemscope itemtype='#'>
             <a href="index.php" itemprop='url' title="Air7seas Homepage">
                 <span itemprop='title'>Home</span>
             </a>
         </span>
        &rsaquo; <span itemscope itemtype='#'><span itemprop='title'><b>Products</b></span></span>
        &rsaquo; <span itemscope itemtype='#'><span itemprop='title'><b>Shipping to Vietnam</b></span></span>
    </div>

</div>

<div id="BreadcrumbWrapper" class="FL HMenu" style="margin-top: 0px;">
<div class="section group">

<div class="col span_9_of_12" style="vertical-align: top; padding-right: 20px;">
<table style="width: 100%; margin-bottom: 10px;">
    <tr>
        <td style="width: 50%;">
            <h1 style="font-size: 18pt; font-family: 'open sans'; color: #3b3b3b; margin-bottom: 20px; font-weight: 600;">
                Shipping to Vietnam</h1>
        </td>
        <td style="width: 50%" align="right">
            <div>
                <div id="google_translate_element"></div>
                <script type="text/javascript">
                    function googleTranslateElementInit() {
                        new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'en,vi', layout: google.translate.TranslateElement.InlineLayout.SIMPLE, autoDisplay: false}, 'google_translate_element');
                    }
                </script>
                <script type="text/javascript"
                        src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
            </div>

            <br>
            <a href="http://export.gov/faq/eg_main_028022.asp" class="resource-link"
               style="font-size: 10pt;" target="_blank">Personal Goods
                &amp; Gift Exports</a>
        </td>
    </tr>
</table>

<div style="width: 700px; height: 120px; margin-bottom: 20px;"><img
        src="source/images/vietnam-banner.jpg" alt="Shipping to Vietnam" width="660px"/></div>
<p id="sv-0">We have wide range of freight service both via air and ocean freight specifically
    design to Vietnam. We take care of every process of the shipping, due to the safe delivery and
    unpacking of the goods, our dedicated team will even organize all packing and paperwork together
    with all those documents, leaving much time to focus on all the other areas of the move to
    Vietnam.</p>

<p id="sv-1">There are a variety of containers available for transporting to Vietnam, depending on
    customer&#39;s individual needs, our move coordinators will advise customer on the most suitable
    container size for shipping their household goods and personal effects and commercial cargos to
    Vietnam. However big or small, customer can be sure that everything will be stress free and that
    their belongings will arrive at their new destination exactly as they left. We offer budget
    friendly shipping to Vietnam by shared container or for large consignments; we can provide a
    sole use container for shipping to Vietnam.</p>


<!--<p id="sv-2">When shipping to Vietnam, shipping inventory should be written in English and detailed
    with information about all of the cargo that customer are shipping. We can provide quoted for a
    full container service and a share a container service for shipping to all major Vietnam ports.
    If any customer wants to ship electronic items to Vietnam, then they should plan to provide
    detailed information about the brand, model and serial number of their items. Whatever the
    customer send to Vietnam it would normally travel by a shipping container. And make sure that
    their name is written on all of the packages that they are shipping to Vietnam and appears the
    same is listed on their passport.</p>-->

<table style="width: 100%;">
    <tr>
        <td style="width: 55%;">
            <div style="width: 100%; margin: 7px 0px;">
                <img id="show_map" src="source/documents/maps/vietnam-map.jpg" alt="Vietnam Cargo Service Map"
                     style="width: 370px; cursor: pointer; border: 1px solid #00a7eb;">
            </div>
        </td>
        <td style="width: 45%; vertical-align: top; padding-left: 10px;">
            <h4 class="title">The Benefit of choosing us</h4>
            <ul class="ff-service">
                <li>We have specialist in Vietnam shipping.</li>
                <li>We have shipping services at low cost comparing to others.</li>
                <li>Door to door services.</li>
                <li>Door to port services.</li>
                <li>Port to door services.</li>
                <li>Port to port services.</li>
                <li>No hidden charges apply</li>
            </ul>
        </td>
    </tr>
</table>

<h4 style="color: #015176; font-size: 11pt; font-weight: 700;">Air freight to Vietnam</h4>

<p id="sv-3">We can also arrange air cargo for customer&#39;s business or residence. We take pride
    in offering flexible and convenient air fright shipping options to locations in Vietnam. We
    accept a wide variety of cargo for international air shipping. All air cargo and air freight
    must be properly boxed, crated. All shipments should be packaged properly in order to accept the
    shipment. On air shipping to Vietnam, our standard box rate covers warehouse receiving, tallying
    and loading customer&#39;s cargo. It also covers documentation costs and air shipment charges.
    Air shipping rates to Vietnam vary depending on the chargeable weight. Some of our shipping
    services in air freight are given below.</p>
<h4 style="color: #015176; font-size: 11pt; font-weight: 700;">Sea Freight Shipping to Vietnam</h4>

<p id="sv-4">We provide ocean transportations services, freight forwarding and logistics services.
    Every step of shipping process is handled very carefully by our experts from booking to final
    delivery at the destination, we also help our customers to follow up the status of every
    shipment easily with fast process, that is to create comfortable and trust when the customer
    using our services to Vietnam. We can even arrange shipping to Vietnam from anywhere in the
    world and can professionally pack your furniture and household goods. We guarantee that the
    shipment will arrive at the destination as soon as possible. Customer can get the following
    services from us.</p>

<div class="section group" style="background-color: #F4F4F4;">
    <div class="col span_6_of_12">
        <ul style="list-style: square; line-height: 2; padding-left: 50px;">
            <li>Full Container Load (FCL) services</li>
            <li><a href="lcl-cargo.php" class="resource-link">Less than Container Load (LCL) services</a></li>
        </ul>
    </div>
    <div class="col span_6_of_12">
        <ul style="line-height: 2; list-style: square;">
            <li>Warehousing and Distributing</li>
            <li>Bulk / Project cargo</li>
        </ul>
    </div>
</div>
<h4 style="color: #015176; font-size: 11pt; font-weight: 700;">Prohibited Items while shipping by
    sea</h4>

<p id="sv-5">While shipping to Vietnam, certain things are prohibited to ship to Vietnam.
    Those things are given below</p>

<div class="section group" style="background-color: #F4F4F4;">
    <div class="col span_6_of_12">
        <ul style="line-height: 2; list-style: square; padding-left: 50px;">
            <li>Narcotics</li>
            <li>Radio transmitters</li>
            <li>Historical books about Vietnam</li>
        </ul>
    </div>
    <div class="col span_6_of_12">
        <ul style="list-style: square; line-height: 2;">
            <li>Firearms and Ammunition</li>
            <li>Satellite dishes</li>
            <li>Politically sensitive materials</li>
        </ul>
    </div>
</div>
<br>
<h4 style="color: #015176; font-size: 11pt; font-weight: 700;">Resource for Vietnam Shipper</h4>
<ul style="list-style: square; line-height: 3; padding-left: 15px;">
    <!--<li><a href="http://www.buyusa.gov/vietnam/en/country_commercial_guide.html" target="_blank">U.S.Commercial
            Service</a></li>-->
    <li><a href="http://www.customs.gov.vn/Default.aspx?tabid=807" target="_blank"
           class="resource-link">Import of Gifts
            &amp;
            Donations in Vietnam</a></li>
    <hr style="border-bottom: 1px solid #eeeeee;">
    <li><a href="http://www.customs.gov.vn/Default.aspx?tabid=809#re" target="_blank"
           class="resource-link">Import of Cars
            in
            Vietnam</a></li>
    <hr style="border-bottom: 1px solid #eeeeee;">
    <li><a href="http://www.customs.gov.vn/default.aspx?tabid=454" target="_blank"
           class="resource-link">Vietnam
            Customs</a>
    </li>
    <hr style="border-bottom: 1px solid #eeeeee;">
    <li><a href="http://www.customs.gov.vn/Default.aspx?tabid=34" target="_blank"
           class="resource-link">Vietnam Customs
            Downloads &amp; Forms</a></li>
    <hr style="border-bottom: 1px solid #eeeeee;">
    <li><a href="http://www.amchamvietnam.com/675" target="_blank" class="resource-link">American
            Chamber of Commerce in
            Vietnam</a></li>
    <hr style="border-bottom: 1px solid #eeeeee;">
    <li><a href="http://www.vietnamembassy-usa.org/" target="_blank" class="resource-link">Vietnam
            Embassy &#45;
            Washington,
            DC</a></li>
    <hr style="border-bottom: 1px solid #eeeeee;">
    <li><a href="http://www.vietnam-un.org/en/index.php" target="_blank" class="resource-link">Vietnam
            Consulate &#45;
            NYC</a>
    </li>
    <hr style="border-bottom: 1px solid #eeeeee;">
    <li><a href="http://www.vietnamconsulate-ca.org/home.asp" target="_blank" class="resource-link">Vietnam
            Consulate
            &#45;
            SFO</a></li>
    <hr style="border-bottom: 1px solid #eeeeee;">
    <li><a href="http://vietnam.usembassy.gov/" target="_blank" class="resource-link">US Embassy
            &#45; Hanoi</a></li>
    <hr style="border-bottom: 1px solid #eeeeee;">
    <li><a href="http://hochiminh.usconsulate.gov/" target="_blank" class="resource-link">US
            Consulate &#45; Ho Chi Minh
            City</a>
    </li>
    <hr style="border-bottom: 1px solid #eeeeee;">
    <li><a href="http://www.business.gov.vn/" target="_blank" class="resource-link">Business Info
            Center</a></li>
    <hr style="border-bottom: 1px solid #eeeeee;">
    <!--<li><a href="http://www.mpi.gov.vn/default.aspx?Lang=2" target="_blank">Ministry of Planning &amp;
            Investment</a></li>-->

    <!--<li><a href="http://vibforum.vcci.com.vn/" target="_blank">Vietnam Chamber of Commerce &amp;
            Industry U.S. Vietnam Trade Council</a></li>-->
    <li><a href="http://www.usvtc.org/" target="_blank" class="resource-link">U.S. Vietnam Trade
            Council</a></li>
    <hr style="border-bottom: 1px solid #eeeeee;">
    <!--<li><a href="http://www.itpc.hochiminhcity.gov.vn/en/" target="_blank">Investment &amp; Trade
            Promotion Centre</a></li>
    <li><a href="http://www.dpi.hochiminhcity.gov.vn/invest/index.html" target="_blank">Planning &amp;
            Investment of HCMC Department</a></li>-->
    <li><a href="http://www.donre.hochiminhcity.gov.vn/" target="_blank" class="resource-link">Nature
            Resources &amp;
            Environment Department</a></li>
    <hr style="border-bottom: 1px solid #eeeeee;">
    <li><a href="http://www.export.gov/vietnam/" target="_blank" class="resource-link">Vietnam:
            A great market for
            US
            Businesses</a></li>
    <hr style="border-bottom: 1px solid #eeeeee;">
    <li><a href="http://www.customs.gov.vn/default.aspx?tabid=454" target="_blank"
           class="resource-link">Vietnam
            Customs</a>
        Vietnam Custom Forms (.jpg)
    </li>
    <hr style="border-bottom: 1px solid #eeeeee;">
    <!--<li><a href="Forms/Vietnam%20Forms/tk%20import.jpg" target="_blank">Import</a></li>
    <li><a href="Forms/Vietnam%20Forms/tk%20export.jpg" target="_blank">Export</a></li>
    <hr class="style-two">
    <li><a href="Documents/Visa%20Application%20VN.pdf" target="_blank">Entry and Exit Visa Application
            (.pdf) (For Foreigners)</a></li>
    <li><a href="Documents/Tourist%20Visa%20to%20Vietnam.mht" target="_blank">Instructions on Visa
            Application to VIETNAM</a></li>-->
    <li><a href="http://www.vietnamtourism.com/en/index.php/useful" target="_blank"
           class="resource-link">Vietnam
            Useful Information</a></li>
</ul>
<p style="margin-top: 20px;" align="center"><i>Information shown is as of August 2015. Subject to change without notice.</i></p>
</div>
<div class="col span_3_of_12 notranslate">
    <table style="width: 100%; font-size: 10pt; border: 1px solid #f2f2f2; padding-bottom: 10px;" cellpadding="0"
           cellspacing="0">
        <tr>
            <td colspan="2" style="background-color: #e6e6e6; padding: 4px 0;" align="center"><h2
                    style="font-size: 11pt; color: #016ec2; font-weight: 700;">Contact Details</h2></td>
        </tr>
        <tr style="height: 80px;">
            <td style="padding-left: 5px; vertical-align: top; padding-top: 12px;">Toll Free</td>
            <td>: 1(888) GUI-VE-VN <br> &nbsp;&nbsp;<a href="tel:18884848386" class="resource-link">1(888)
                    484-8386</a><br>
                &nbsp;&nbsp; <a href="tel:4089578747" class="resource-link">(408) 957-8747</a>
            </td>
        </tr>
        <tr>
            <td style="padding-left: 5px;">Email</td>
            <td>: <a href="mailto:saigon@air7seas.us" class="resource-link">Saigon (@) Air7seas.us</a></td>
        </tr>
        <tr style="height: 40px;">
            <td style="padding-left: 5px;">Fax</td>
            <td>: (408) 957-7557</td>
        </tr>
    </table>
    <br>
    

<link href="source/css/controls.css" rel="stylesheet" type="text/css" visible="true"/>
<style>
    table.estimate tr > td {
        padding: 2px 0px;
    }

    .txtborder {
        border: 1px solid #cccccc;
    }
</style>

<script>
    function f_t_Countries(value) {
        var f_country = document.getElementById('from_country').value;
        var t_country = document.getElementById('to_country').value;
        if (value == 'to_country') {
            if (t_country != 'US') {

            }
        } else if (value == 'from_country') {

        }
    }
</script>

<!--  DATE CALANDER  -->
<link rel="stylesheet" type="text/css" href="source/css/jquery.datetimepicker.css"/>
<script src="source/js/jquery-1.11.1.js"></script>


<script>
    $(function () {
        $("#txt_moving_date").datepicker();
    });
</script>

<div style="width: 225px; height: auto; background-color: #fafafa; margin-bottom: 20px;" align="center">
    <form method="post" action="sidebar-free-estimate-action.php">
        <div
            style="width: 223px;background-color: #056598; border: 1px solid #056598; padding: 5px 0px; font-family: arial; font-size: 10pt; color: #ffffff; font-weight: bold;">
            Get FREE Quotation
        </div>
        <table class="estimate" style="width: 100%; font-family: arial; font-size: 10pt;  border: 1px solid #cccccc;"
               cellspacing="0" cellpadding="0" border="0">
            <tr>
                <td style="padding-left: 10px; padding-top: 10px; font-size: 9pt; color: #666666; padding-bottom: 0px;">

                </td>
            </tr>
            <tr style="height: 33px;">
                <td align="center">
                    <select type="text" id="mode_transport" name="mode_transport" style="width: 90%; margin-top: 0px; "
                            class="form-textbox">
                        <option>Select Mode of Transport</option>
                        <option>By Air</option>
                        <option>By Sea</option>
                        <option>By Land</option>
                        <option>Not Sure</option>
                    </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">Select Commodity</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="center">
                    <select type="text" id="commodity" name="commodity" style="width: 90%; margin-top: 0px;"
                            class="form-textbox">
                        <option value="Select Commodity" selected="selected">Select Commodity</option><option value="Automobile/s">Automobile/s</option><option value="Boat">Boat</option><option value="Charity Goods">Charity Goods</option><option value="Computer/Electronics">Computer/Electronics</option><option value="General Cargo">General Cargo</option><option value="Hazardous Cargo">Hazardous Cargo</option><option value="Machinery">Machinery</option><option value="Metal Scrap">Metal Scrap</option><option value="Motorcycle/s">Motorcycle/s</option><option value="Perishable Cargo">Perishable Cargo</option><option value="Residential">Residential</option><option value="Residential with Vehicle (Auto, Motorcycle etc)">Residential with Vehicle (Auto, Motorcycle etc)</option><option value="Vehicle/s">Vehicle/s</option><option value="Waste Paper">Waste Paper</option><option value="Used Clothing">Used Clothing</option>                    </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">From Country</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="center">
                    <select type="text" style="width: 90%; margin-top: 0px;" class="form-textbox" id="from_country"
                            name="from_country">
                        <OPTION Value="0">Select From</OPTION>
                        <option value="US">US</option><option value="Vietnam">Vietnam</option>                    </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">To Country</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="center"><select type="text" style="width: 90%; margin-top: 0px;" class="form-textbox"
                                           id="to_country" name="to_country">
                        <OPTION Value="0">Select To</OPTION>
                        <option value="US">US</option><option value="Vietnam">Vietnam</option>                    </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">Moving Date</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="left">
                    <input type="text" id="txt_moving_date" name="txt_moving_date" class="form-textbox"
                           style="width: 77%; margin-left: 12px;" placeholder="Expected date to ship">
                    <img src="source/images/calendar.PNG" style="position: absolute; padding-top: 3px;">
                </td>
            </tr>
            <tr style="height: 33px;">
                <td align="right" style="padding: 5px 13px 10px 10px;">
                    <input type="submit" id="submit_quote" name="submit_quote" class="naviBlue"
                           value="SUBMIT" style="height: 25px; padding-top: 3px"></td>
            </tr>
        </table>
        <script src="source/js/jquery.datetimepicker.js"></script>
        <script>
            $('#txt_moving_date').datetimepicker({
                lang: 'en',
                timepicker: false,
                closeOnDateSelect: true,
                format: 'm/d/Y',
                formatDate: 'Y/m/d',
                minDate: '2017/01/01', // yesterday is minimum date
                //startDate: '2015/01/01',
                autodateonstart: true,
                maxDate: '2030/12/31' // and tommorow is maximum date calendar
            });
        </script>
    </form>
</div>


<a href="cargo-tracking.php"><img src="source/images/cargo-tracking.png" style="margin-bottom: 20px;"></a>
<a href="about-air7seas.php"><img src="source/images/exp.png" style="margin-bottom: 20px;"></a>
<a href="customer-review.php"><img src="source/images/tp-logo-customer-review.PNG" style="margin-bottom: 20px;"></a>
</div>
</div>
</div>
</div>
</div>
<div class="notranslate">
    <!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" lang="en">


<head>
    <!--Start of Zopim Live Chat Script
    <script type="text/javascript">
        window.$zopim || (function (d, s) {
            var z = $zopim = function (c) {
                z._.push(c)
            }, $ = z.s =
                d.createElement(s), e = d.getElementsByTagName(s)[0];
            z.set = function (o) {
                z.set.
                    _.push(o)
            };
            z._ = [];
            z.set._ = [];
            $.async = !0;
            $.setAttribute('charset', 'utf-8');
            $.src = '//v2.zopim.com/?2NBKvMLseKA8C45Gr5ywmelLErtAkht6';
            z.t = +new Date;
            $.
                type = 'text/javascript';
            e.parentNode.insertBefore($, e)
        })(document, 'script');
    </script>
    End of Zopim Live Chat Script-->
    
    <!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = '3kWxTfUv3x';var d=document;var w=window;function l(){
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
<!-- {/literal} END JIVOSITE CODE -->

    <link href="source/css/sole.css" rel="stylesheet">

<body class="vpform pgTrustPilot" lang="en-GB" align="center">


<div id="footerinfo" style="width: 100%; background-color: #cccccc" align="center">
    <div style="width: 980px; background-color: #ffffff; padding: 10px 0px;" align="left">
        <div id="BreadcrumbWrapper">
            <div class="section group">
                <div class="col span_12_of_12" style="line-height: 23px; border-right: 1px solid #dddddd; ">
                </div>
            </div>
            <hr>
        </div>
        <img src="source/images/logos.jpg" alt="" style="width: 980px;">
        <div style="margin-left:40px;">
            <a id="bbblink" class="ruvtbum" target="_blank" href="https://www.bbb.org/us/ca/milpitas/profile/logistics/air-7-seas-transport-logistics-1216-213698#bbbseal"
        title="AIR 7 SEAS Transport Logistics Inc, Logistics, Milpitas, CA"
        style="display: block;position: relative;overflow: hidden; width: 60px; height: 108px; margin: 0">
        <img style="padding: 0px; border: none;" id="bbblinkimg" src="https://seal-sanjose.bbb.org/logo/ruvtbum/air-7-seas-transport-logistics-213698.png" width="120" height="108" alt="AIR 7 SEAS Transport Logistics Inc, Logistics, Milpitas, CA" />
        </a>    
        </div>
        
        <script type="text/javascript">var bbbprotocol = ( ("https:" == document.location.protocol) ? "https://" : "http://" ); (function(){var s=document.createElement('script');s.src=bbbprotocol + 'seal-sanjose.bbb.org' + unescape('%2Flogo%2Fair-7-seas-transport-logistics-213698.js');s.type='text/javascript';s.async=true;var st=document.getElementsByTagName('script');st=st[st.length-1];var pt=st.parentNode;pt.insertBefore(s,pt.nextSibling);})();
        </script>
    </div>
</div>
<!--footer-->
<footer style="background-color: #4d4d4d">
    <div class="DB MMdLFtR">
        <div class="FL DB MMdLFtRa" style="padding-left: 75px;">

            <div id="FtR" class="LH20 footer-links">
                <div class="left-section FL">
                    <div class="left-wrapper FL">
                        <section class="ordering-fromus">
                            <div class="title">
                                AIR 7 SEAS
                            </div>
                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="about-air7seas.php" id="aContact">About Us</a>
                                    <a href="feedback.php" id="aFAQ">Feedback</a>
                                    <a href="shipping-news.php" id="aOrdertracking">News &amp;
                                        Events</a>
                                    <a href="#">Privacy Policy</a>
                                    <a href="terms-and-conditions.php">Terms &amp;
                                        Conditions</a>
                                    <a href="jobs.php">Jobs</a>
                                </li>
                            </ul>
                        </section>
                        <section class="help-support">
                            <div class="title">
                                SERVICES
                            </div>

                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="international-freight.php">International &#45;
                                        Freight</a>
                                    <a href="domestic-freight.php">Domestic &#45;
                                        Freight</a>
                                    <a href="autos-vehicles-machinery.php">Machinery &amp; Vehicles</a>
                                    <a href="freight-forwarder.php">Freight Forwarding</a>
                                    <a href="customs-release.php">Customs Release</a>
                                    <a href="moving.php">Movers</a>
                                </li>
                            </ul>
                        </section>
                        <section class="information">
                            <div class="title">
                                SUPPORT
                            </div>
                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="faq.php">Frequently Asked Questions</a>
                                    <a href="moving-tips.php">Moving Tips</a>

                                    <a href="payments.php" id="aFreeRecycle">Payment Options</a>
                                    <a href="procedural-steps-for-claim-submition.php">Claim
                                        Submission Procedures</a>
                                    <a href="isf.php">Importer Security Filing (ISF)</a>
                                    <a href="order-online-insurance.php">Order Online -
                                        Insurance</a>

                                </li>
                            </ul>
                        </section>
                    </div>
                    <div class="social-links">


                    </div>
                </div>
                <section class="newsletter">
                    <div class="title">CORPORATE OFFICE</div>
                    <div class="footer-contact">
                        <ul>
                            <li class="f-map"><a
                                    href="contact-us.php"
                                    target="_blank">1815 Houret Court, <br> Milpitas, CA 95035, US</a></li>
                            <li class="f-phone"><span><a href="tel:+18882477732">Call Us: 1-888-247-7732</a></span></li>
                            <li class="f-mail"><a href="mailto:info@air7seas.us">info (@) air7seas.us</a></li>
                        </ul>
                    </div>
                    <br><br>

                    <div>
                        <a href="https://www.facebook.com/pages/Air7Seas-Transport-Logistics-Inc/731149066945233" target="_blank">
                            <img src="source/images/icons/fb.png" style="margin-top: 7px; width: 25px;">
                        </a>&nbsp;
                        <a href="https://twitter.com/Air7seas" target="_blank">
                            <img src="source/images/icons/twitter.png" style="margin-top: 7px; width: 25px;">
                        </a>&nbsp;
                        <a href="https://www.google.com/maps/place/AIR+7+SEAS+Transport+Logistics+Inc/@37.405497,-121.8994427,17z/data=!3m1!4b1!4m5!3m4!1s0x808fceb215c020c3:0x183384c4fb534d3c!8m2!3d37.405497!4d-121.897254" target="_blank">
                            <img src="source/images/icons/gp.png" style="margin-top: 7px; width: 25px;">
                        </a>
                    </div>

                </section>
            </div>
        </div>
    </div>

</footer>

<div class="baseline-footer">
    <div class="baseline-footer-wrapper">
        <section class="FL" itemprop="provider" itemscope itemtype="http://schema.org/Organization">
            <div class="FL">

                <meta itemprop="url" content="http://www.air7seas.com/"/>
                <meta itemprop="name" content="Air 7 Seas Transport Logistics Pvt Ltd"/>
                <meta itemprop="email" content="info@air7seas.com "/>
                <div itemprop="location" itemscope itemtype="http://www.schema.org/LocalBusiness">

                    <meta itemprop="openingHours" content="Mo-Fr 08:00-16:00"/>
                    <meta itemprop="openingHours" content="Sa-Su Holiday"/>
                    <div itemprop="geo" itemscope itemtype="http://schema.org/GeoCoordinates">
                        <meta itemprop="latitude" content="53.55519"/>
                        <meta itemprop="longitude" content="-3.041651"/>
                    </div>
                </div>

            </div>
            <div class="contact-information">
                <div id="pnlUKFooter">

                    <div class="address" itemprop=address itemscope itemtype=http://schema.org/PostalAddress>
                        <span class="address-image"></span>

                        <div class="address-wrapper">
                            <span itemprop=streetAddress><a href="contact-us.php" style="color: #cfcfcf;">1815 Houret
                                    Court,<br> Milpitas, CA 95035</a></span>,
                            <span itemprop=addressLocality>USA</span>
                        </div>
                    </div>
                    <div class="phone-number">
                        <span class="phone-image"></span>
                        <span class="telephone" itemprop=telephone><a href="tel:+18882477732" style="color: #cfcfcf;">1-888-247-7732</a></span>
                        <span class="sales-support">(Customer Support)</span>
                    </div>
                    <div class="email-address">
                        <span class="email-img"></span>
                        <span itemprop=email><a class="mail-id"
                                                href="mailto:info@air7seas.us">info (@) air7seas.us</a></span>
                    </div>


                </div>

            </div>
        </section>


        <div itemprop="copyrightHolder" itemscope itemtype="http://www.schema.org/Organization"
             class="copywrite-holder">
            <meta itemprop="url" content="http://www.air7seas.com/"/>
            <meta itemprop="name" content="Air 7 Seas Transport Logistics Pvt Ltd"/>

            <meta itemprop="email" content="info@air7seas.com "/>

            Copyright <span class="copyrights">&copy;</span> AIR 7 SEAS 2014 &#45; 2015
        </div>
        <meta itemprop="copyrightYear" content="1986-2014"/>

        <div class="divAuthorisedText">Authorised and regulated by AIR 7 SEAS 95035</div>


    </div>
</div>

</body>
</html>

</div>
</body>
</html>
