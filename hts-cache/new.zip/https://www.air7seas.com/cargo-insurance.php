<!DOCTYPE html>
<html>
<head>
    <title>Cargo Insurance AIR 7 SEAS</title>
    <link rel="shortcut icon" href="source/images/a7s-icon.ico"/>
    <meta charset="utf-8"/>
    <meta name="description"
          content="Air 7 seas is leading Freight Forwarder, NVOCC, OTI, Cargo Consolidator, Custom Broker, Carrier, and Shipping Agents for Ship Lines, Airlines, Truckers, Shipper & Consignee to handle International and Domestic transportation by Air Freight, Sea Freight or Road Freight.">
    <meta name="description"
          content="Air 7 Seas Overseas Relocation, Air 7 Seas Moving Overseas, Air 7 Seas Relocation Services, Air 7 Seas Shipping India, Air 7 Seas Shipping USA, Air 7 Seas Freight Forwarder, Air 7 Seas Air Freight, Air 7 Seas Air Cargo, Air 7 Seas Customs Clearance, Air 7 Seas International Shipping Companies, Air 7 Seas Moving Estimate, Air 7 Seas Shipping Quote, Air 7 Seas Moving International, Air 7 Seas Domestic Movers, Air 7 Seas Shipping Agent, Air 7 Seas Shipping International, Air 7 Seas International Moving Service, Air 7 Seas Cargo Agent, Air 7 Seas Customs Broker, Air 7 Seas International Mover, Air 7 Seas Household Goods, Air 7 Seas Commercial Goods, Air 7 Seas Breakbulk Cargo, Air 7 Seas Car Shipping, Air 7 Seas Motorbike Shipping, Air 7 Seas Auto Vehicle Mechinery, Air 7 Seas Cargo Consolidation, Air 7 Seas Freight Service Provider">
    <meta name="keywords"
          content="Overseas Relocation, Moving Overseas, Relocation Services, Shipping India, Shipping USA, Freight Forwarder, Air Freight, Air Cargo, Customs Clearance, International Shipping Companies, Moving Estimate, Shipping Quote, Moving International, Domestic Movers, Shipping Agent, Shipping International, International Moving Service, Cargo Agent, Customs Broker, International Mover, Household Goods, Commercial Goods, Breakbulk Cargo, Car Shipping, Motorbike Shipping, Auto Vehicle Mechinery, Cargo Consolidation, Freight Service Provider">
    <meta name="author" content="Air 7 Seas Transport Logistics Pvt Ltd">
    <!--  <base href="http://www.air7seas.com/"> -->
    <link href="source/css/responsive.css" rel="stylesheet">
    <link href="source/css/sole.css" rel="stylesheet" type="text/css" visible="true"/>
    <link href="source/css/faq_accordion.css" rel="stylesheet">
    <script src="source/js/jquery-latest.min.js" type="text/javascript"></script>
    <script src="source/js/script.js" type="text/javascript"></script>

    <style>
        ul.ff-service {
            font-size: 9pt;
            padding-left: 25px;
        }

        ul.ff-service li {
            margin: 10px;
            line-height: 1.5;
        }
    </style>

    <script>
        /*(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

        ga('create', 'UA-54008281-2', 'auto');
        ga('send', 'pageview');*/

    </script>

</head>
<body>
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link href="source/css/sole.css" rel="stylesheet" type="text/css" visible="true"/>
    <link href="source/css/skin.css" rel="stylesheet" type="text/css" visible="true"/>

    <link
        href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800'
        rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="source/css/megadrop.css"/>
    <script type="text/javascript" src="source/js/megascripts.js"></script>
    <style>
        .searchbox {
            height: 28px;
            width: 225px;
            border: 1px solid #dadada;
            border-top-left-radius: 3px;
            border-bottom-left-radius: 3px;
            padding-left: 10px;
            font-size: 12px;
            color: #9b9b9b
        }

        .searchbutton {
            cursor: pointer;
            background-image: url('source/images/search.GIF');
            height: 30px;
            width: 70px;
            margin-top: 0;
            color: transparent
        }

        .txtSearchbox::-webkit-input-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox:-moz-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox::-moz-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox:-ms-input-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }
    </style>
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NQDLZPP');</script>
<!-- End Google Tag Manager -->
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NQDLZPP"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div id="topLine">
</div>
<div id="main-header" align="center" style="font-family: Arial;">
    <div id="main-header-area" align="left">
        <a href="index.php">
            <img src="source/images/logo-new.png" alt="Air 7 Seas" style="float: left; position: relative;"></a>

        <div class="top-small-link" style=" vertical-align: middle">
            <table border="0">
                <tr style="vertical-align: top">
                    <td style="padding-top: 3px;">
                        <a href="cargo-tracking.php" style="color: #404040; font-family: Arial;"><b>Cargo
                                Tracking</b></a>|
                        <a href="about-air7seas.php">About Us</a>|
                        <a href="https://portal.cargoez.com/air7seas/login" target="_blank">Login</a>|
                        <a href="shipping-news.php">News &amp; Events</a>

                    </td>
                    <td style="vertical-align: top;"><img src="source/images/phone-ico.PNG" alt=""
                                                          style="margin-top: 0px;">
                    </td>
                    <td style="padding: 3px 0 0 5px; width: 185px;">
                        <span style="font-size: 13pt; float: right"><span style="font-size: 9pt;">Toll Free:</span>
                        <a href="tel:+18882477732"
                           style="padding-left: 0px; padding-right: 0px; margin-right: 0px; color: #026799;"><b>1-888-247-7732<b/></a></span>
                    </td>

                </tr>
                <tr>
                    <td colspan="3" style="">
                        <div id="SrCl" style="padding-top: 8px; float: right">
                            <form method="post" action="search-results.php">

                                <input type="text" id="find" name="find" autocomplete="off"
                                       class="searchbox txtSearchbox" placeholder="How can i help you...?">
                                <input type="submit" name="" style="border:0px; height: 28px;" class="searchbutton"
                                       alt="Search"/>

                            </form>
                        </div>
                    </td>
                </tr>
            </table>


        </div>


    </div>
</div>
<div id="menu-bar" style="width: 100%; background-color: #1e6a89;" align="center">
<div style="width: 980px;" align="left">
<ul class="nav-mainmenu clearfix animated">
<li><a href="index.php">Home</a></li>
<li>
    <a href="#">Services</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px; ">

            <ul class="menu-items">
                <li class="seperator"><a href="international-freight.php" style="font-weight: 600">International
                        Freight</a></li>
                <li class="seperator"><a href="domestic-freight.php">Domestic Freight</a></li>
                <li class="seperator"><a href="freight-forwarder.php">Freight Forwarding</a></li>
                <li class="seperator"><a href="freight-consultation.php">Consultation</a></li>

            </ul>
        </div>
    </div>
</li>
<li><a href="#">Products</a>

    <div class="container-2" style="width: 500px;">
        <table border="0">
            <tr>
                <td style="border-right:1px solid #ccc; vertical-align: top;">
                    <div class="col1" style="width: 250px;">

                        <ul class="menu-items">


                            <li class="seperator"><a href="shipping-to-vietnam.php"><img
                                        src="source/images/Vietnam-Flag-icon.png" alt="Vietnam Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Saigon Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-india.php"><img
                                        src="source/images/India-Flag-icon.png" alt="India Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">India Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-middle-east.php"><img
                                        src="source/images/MiddleEast-Flag-icon.png" alt="Shipping to Middle East"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Middle East Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-china.php"><img
                                        src="source/images/China-Flag-icon.png" alt="China Shipper"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">China Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-philippines.php"><img
                                        src="source/images/Philippines-Flag-icon.png" alt="Philippines Shipper"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Manila Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-spain.php"><img
                                        src="source/images/Spain-Flag-icon.png" alt="Spain Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Spain Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-mexico.php"><img
                                        src="source/images/Mexico-Flag-icon.png" alt="Mexico Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Mexico Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="autos-to-canada.php"><img
                                        src="source/images/Canada-Flag-icon.png" alt="Canada Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Autos to Canada</span></a>
                            </li>
  <li class="seperator"><a href="importers-logistics-rep.php">Importer&#39;s Rep</a></li>

                        </ul>
                    </div>
                </td>
                <td style="vertical-align: top;">
                    <div class="col1" style="width: 250px;">

                        <ul class="menu-items">
                            <li class="seperator"><a href="shipping-to-africa.php">
                                    <img src="source/images/Africa-Flag-icon.png" alt="AfriCargo Express" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">AfriCargo Express</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-latin-america.php">
                                    <img src="source/images/Latino-Flag-icon.png" alt="Latino Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Latino Shipper</span></a>
                            </li>
                              <li class="seperator"><a href="nvo.php">
                                    <img src="source/images/lcl-icon.jpg" alt="Latino Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Cargo-Coloader LCL</span></a>
                            </li>
                            <li class="seperator"><a href="a7s-pre-fulfilment-service.php"><img src="source/images/receiving-center-icon.png"
                                                                                      alt="Air7seas Pre-Fulfillment Service" width="22px"
                                                                                      style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Pre-Fulfillment &amp; Delivery </span></a></li>
                            <li class="seperator"><a href="receiving-center.php"><img src="source/images/receiving-center-icon.png"
                                                                                      alt="Mexico Shipper" width="22px"
                                                                                      style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Pre-Shipping Receiving Center</span></a></li>
                            <!--<li class="seperator"><a href="receiving-center.php">Receiving Center</a></li>-->
                            <li class="seperator"><a href="partners-agents.php"><img
                                        src="source/images/partners-agents-icon.png" alt="Canada Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Partners - Agents</span></a>
                            </li>
                            <li class="seperator"><a href="autos-vehicles-machinery.php"><img
                                        src="source/images/autos-vehicle-mechinery-icon.png" alt="Mexico Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Autos Vehicles Machinery</span></a>
                            </li>
                            <li class="seperator"><a href="transloading-transhipment.php">Transloading -
                                    Transhipment</a></li>
                            <li class="seperator"><a href="ship-hazardous-perishable-goods.php">Hazardous &amp;
                                    Perishable</a></li>


                        </ul>
                    </div>
                </td>
            </tr>
        </table>


    </div>
</li>
<li><a href="#">Mover &amp; Relocation</a>

    <div class="container-4" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="move-household-goods.php">Household Goods</a></li>
                <li class="seperator"><a href="ship-commercial-goods.php">Commercial Goods</a></li>
                <!--     <li class="seperator"><a href="#">Countries served</a></li> -->
            </ul>
        </div>
    </div>
</li>
<li><a href="#">Freight Carrier</a>

    <div class="container-4" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="air-freight-carrier.php">Air Freight Carrier</a></li>
                <li class="seperator"><a href="ocean-freight-carrier.php">Ocean Freight Carrier</a>
                </li>
                <li class="seperator"><a href="soc-movements.php">SOC Movements</a></li>
            </ul>
        </div>
    </div>
</li>
<li>
    <a href="#">Customs Release</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="export-import.php"">Export - Import</a></li>
                <li class="seperator"><a href="isf.php">ISF / AMS</a></li>
                <li class="seperator"><a href="importers-logistics-rep.php">Importer&#39;s Rep</a></li>
            </ul>
        </div>
    </div>
</li>

<li><a href="#">Insurance</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="cargo-insurance-coverage-types.php">Coverage Types</a></li>
                <li class="seperator"><a href="free-estimate-insurance.php">Free Estimate - Insurance</a>
                </li>
                <li class="seperator"><a href="order-online-insurance.php">Order Online - Insurance</a></li>
                <li class="seperator"><a href="claim-submission.php">Claim submission Form</a></li>
                <li class="seperator"><a href="faq-insurance.php">FAQ</a></li>
                <!--<li class="seperator"><a href="#">Resources - Insurance</a></li>-->
                <li class="seperator"><a href="damages-to-the-goods-by-customs.php">Damages to the goods by
                        Customs</a></li>

            </ul>
        </div>
    </div>
</li>
<li><a href="#">Contact Us</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="contact-us.php">Contacts</a></li>
                <li class="seperator"><a href="free-estimatesdetails.php">Get an Estimate</a></li>
                <li class="seperator"><a href="ordernowdetails.php">Book a Shipment</a></li>
                <li class="seperator"><a href="feedback.php">Feedback</a></li>
                <li class="seperator"><a href="complaint.php">Complaint</a></li>
                <li class="seperator"><a href="customer-review.php">Testimonial</a></li>
                <li class="seperator"><a href="claim-submission.php">Claim submission</a></li>
                <li class="seperator"><a href="terms-and-conditions.php">Terms &amp; Conditions</a></li>
                <li class="seperator"><a href="jobs.php">Jobs</a></li>
            </ul>
        </div>
    </div>
</li>
<li><a href="#" class="last-list">Tools &amp; Resources</a>

    <div class="container-1 right" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="forms-downloads.php">Documents &amp; Forms</a></li>
                <li class="seperator"><a href="payments.php">Payment options</a></li>
                <li class="seperator"><a href="moving-tips.php">Moving Tips</a></li>
                <li class="seperator"><a href="container-sizes.php">Container Sizes for Sea</a></li>
                <li class="seperator"><a href="faq.php">FAQs</a></li>
                <li class="seperator"><a href="shipping-news.php">News &amp; Events</a></li>
                <li class="seperator"><a href="ask-a-question.php">Ask a question</a></li>
            </ul>
        </div>
    </div>
</li>

</ul>
</div>

</div>
<div id="info-bar" style="box-shadow: 0px 3px 3px 0px rgba(0, 0, 0, 0.15); position: relative; z-index: 100;"
     align="center">
    <div id="info-bar-area" align="left">
        <div class="top-thin-links">
            <div class="thin-links-wrapper">
                <a class="review" href="free-estimatesdetails.php"><span class="icon"></span><span>Free Shipping Estimate</span></a>
                <a class="finance" href="estimate-sizeof-shipment.php"><span
                        class="icon"></span><span>Moving Calculator</span></a>
                <a class="facebook" href="moving-tips.php"><span class="icon"></span><span>Moving Tips</span></a>
                <a class="catalogue" href="ordernowdetails.php"><span class="icon"></span><span>Order Online</span></a>
                <a class="trade-account" href="ask-a-question.php"><span class="icon"></span><span>Shipping ?</span></a>
            </div>
        </div>
    </div>
</div>

</body>
</html>
<div id="contents" align="center">
<div id="contentsArea" align="left" style="padding-left: 20px;">

<!-- Top Information Bar -->
<div id="BreadcrumbWrapper" style="width: 690px; margin-top: 12px;">
    <div id="Breadcrumb" class="Breadcrumb BoxSBB">
         <span itemscope itemtype='#'>
             <a href="index.php" itemprop='url' title="Air7seas Homepage">
                 <span itemprop='title'>Home</span>
             </a>
         </span>
        &rsaquo; <span itemscope itemtype='#'><span itemprop='title'><b>Insurance</b></span></span>
        &rsaquo; <span itemscope itemtype='#'><span itemprop='title'><b><a
                        href="cargo-insurance-coverage-types.php">Cargo Insurance Coverage Types</a></b></span></span>
        &rsaquo; <span itemscope itemtype='#'><span itemprop='title'><b>Cargo Insurance</b></span></span>
    </div>
</div>

<div id="BreadcrumbWrapper" class="FL HMenu" style="margin-top: 0px; ">
<div class="section group">
<div class="col span_9_of_12" style="vertical-align: top; padding-right: 20px;">
<h1 style="font-size: 18pt; font-family: 'open sans'; color: #3b3b3b; margin-bottom: 20px; font-weight: 600; ">
    Cargo Insurance</h1>

<h2 style="color: #015176; margin-bottom: 5px; font-size: 12pt; font-weight: 700;">Need of Cargo
    Insurance ?</h2>
<ul class="ff-service" style="background-color: #f4f4f4; padding: 15px 15px 15px 25px;">
    <li>All risk and third party coverage can be underwritten for: Exporters and Importers
        (including stock throughput), Multinational accounts (including captives), Freight
        forwarders and Infrastructure projects.
    </li>
    <li>Comprehensive coverage for goods in transit can be enhanced to include warehouse storage for
        consolidation risks.
    </li>
    <li>Worldwide master policies, including locally admitted coverage as required, are available.
    </li>
    <li>Underwriting, claims, recovery, loss control, and risk management services provided by
        marine specialists throughout the world.
    </li>
    <li>Advance Loss of Profit (ALOP) / Delay in Start up (DSU) coverage available on project Cargo
        programs.
    </li>
    <li>Fully Combined property and marine cargo policy available with the Property Income Loss and Ocean transit
        (PILOT)
    </li>
</ul>
<br>

<h2 style="color: #015176; margin-bottom: 10px; font-size: 12pt; font-weight: 700;">Benefits</h2>

<div id='cssmenu'>
<ul id="before">
<li class='has-sub' style="border: 1px solid #dddddd;"><a href='#'>
        <div class="faq" style="background-color: #F4F4F4;">
                                        <span
                                            style="padding-right: 10px; font-family: 'Roboto'; font-size: 14pt; color: #198fb8; display: inline; float: left;">Q.</span>
            <h4 class="title"
                style="margin: 0px; display: inline; margin-right: 18px; font-size: 10pt;">
                Almost Any Item, even High Risk Commodities</h4>
        </div>
    </a>
    <ul style="padding-top: 15px;">
        <li>
            Yes, All types of goods, used or new, even high risk items such as Household Goods, Fine Arts, Fragile Goods
            and Jewelry.
        </li>

    </ul>
</li>
<li class='has-sub' style="border: 1px solid #dddddd;"><a href='#'>
        <div class="faq" style="background-color: #F4F4F4;">
                                        <span
                                            style="padding-right: 10px; font-family: 'Roboto'; font-size: 14pt; color: #198fb8; display: inline; float: left;">Q.</span>
            <h4 class="title"
                style="margin: 0px; display: inline; margin-right: 18px; font-size: 10pt;">
                Any Destination: Domestic &amp; International</h4>
        </div>
    </a>
    <ul style="padding-top: 15px;">
        <li>
            Yes, You can get cargo insurance coverage To and From any place in the world, including Mexico and Iraq.
        </li>
    </ul>
</li>
<li class='has-sub' style="border: 1px solid #dddddd;"><a href='#'>
        <div class="faq" style="background-color: #F4F4F4;">
                                        <span
                                            style="padding-right: 10px; font-family: 'Roboto'; font-size: 14pt; color: #198fb8; display: inline; float: left;">Q.</span>
            <h4 class="title"
                style="margin: 0px; display: inline; margin-right: 18px; font-size: 10pt;">
                All Modes of Transport: Ocean, Air &amp; Land</h4>
        </div>
    </a>
    <ul style="padding-top: 15px;">
        <li>
            Yes, It doesn&#39;t matter if your shipment is moving by boat, plane, truck or train. You can get coverage
            for any transit including shipments with multiple modes of transport.
        </li>
    </ul>
</li>
<li class='has-sub' style="border: 1px solid #dddddd;"><a href='#'>
        <div class="faq" style="background-color: #F4F4F4;">
                                        <span
                                            style="padding-right: 10px; font-family: 'Roboto'; font-size: 14pt; color: #198fb8; display: inline; float: left;">Q.</span>
            <h4 class="title"
                style="margin: 0px; display: inline; margin-right: 18px; font-size: 10pt;">
                Any $ Amount &#45; No min. or max. coverage limits</h4>
        </div>
    </a>
    <ul style="padding-top: 15px;">
        <li>
            Yes, Get cargo insurance coverage for any value from small $100 packages to Million dollar shipments.
        </li>
    </ul>
</li>
<li class='has-sub' style="border: 1px solid #dddddd;"><a href='#'>
        <div class="faq" style="background-color: #F4F4F4;">
                                        <span
                                            style="padding-right: 10px; font-family: 'Roboto'; font-size: 14pt; color: #198fb8; display: inline; float: left;">Q.</span>
            <h4 class="title"
                style="margin: 0px; display: inline; margin-right: 18px; font-size: 10pt;">
                Any Licensed Carrier or Moving Company</h4>
        </div>
    </a>
    <ul style="padding-top: 15px;">
        <li>
            Yes, It does not matter who is moving your shipment, you can get cargo insurance coverage for any licensed
            carrier.
        </li>
    </ul>
</li>
<li class='has-sub' style="border: 1px solid #dddddd;"><a href='#'>
        <div class="faq" style="background-color: #F4F4F4;">
                                        <span
                                            style="padding-right: 10px; font-family: 'Roboto'; font-size: 14pt; color: #198fb8; display: inline; float: left;">Q.</span>
            <h4 class="title"
                style="margin: 0px; display: inline; margin-right: 18px; font-size: 10pt;">
                Multiple or Single Shipments</h4>
        </div>
    </a>
    <ul style="padding-top: 15px;">
        <li>
            Yes, You can insure individual one time shipments or if you are a frequent shipper, you can insure multiple
            shipments as well.
        </li>
    </ul>
</li>
<li class='has-sub' style="border: 1px solid #dddddd;"><a href='#'>
        <div class="faq" style="background-color: #F4F4F4;">
                                        <span
                                            style="padding-right: 10px; font-family: 'Roboto'; font-size: 14pt; color: #198fb8; display: inline; float: left;">Q.</span>
            <h4 class="title"
                style="margin: 0px; display: inline; margin-right: 18px; font-size: 10pt;">
                Save up to 90% compared to Carrier Insurance and up to 50% over traditional primary cargo insurance with
                our low rates direct from the underwriter.</h4>
        </div>
    </a>
    <ul style="padding-top: 15px;">
        <li>
            Yes, Because we are a freight logistics company specializing in cargo shipments, we have access to lower
            rates direct from the underwriter; unlike insurance brokers who have to go through multiple brokers in order
            to offer this special type of freight coverage. Eliminate the middle man and get lower rates direct from us.
        </li>
    </ul>
</li>
<li class='has-sub' style="border: 1px solid #dddddd;"><a href='#'>
        <div class="faq" style="background-color: #F4F4F4;">
                                        <span
                                            style="padding-right: 10px; font-family: 'Roboto'; font-size: 14pt; color: #198fb8; display: inline; float: left;">Q.</span>
            <h4 class="title"
                style="margin: 0px; display: inline; margin-right: 18px; font-size: 10pt;">
                Your Cargo Insurance coverage is provided by one of the Best and most well know &quot;A&quot; rated
                insurers in the world.</h4>
        </div>
    </a>
    <ul style="padding-top: 15px;">
        <li>
            Yes, They are synonymous with high quality, reliability and trust. We are proud to offer you the high
            quality security of A+ rated underwriters.
        </li>
    </ul>
</li>
<li class='has-sub' style="border: 1px solid #dddddd;"><a href='#'>
        <div class="faq" style="background-color: #F4F4F4;">
                                        <span
                                            style="padding-right: 10px; font-family: 'Roboto'; font-size: 14pt; color: #198fb8; display: inline; float: left;">Q.</span>
            <h4 class="title"
                style="margin: 0px; display: inline; margin-right: 18px; font-size: 10pt;">
                Your cargo insurance coverage arranged will be Primary not Contingent.</h4>
        </div>
    </a>
    <ul style="padding-top: 15px;">
        <li>
            Yes, Primary coverage comes first in the event of a loss, regardless of the carriers liability or their
            terms and conditions and you can protect your shipment for it&#39;s actual Full declared value instead of
            being restricted to 0.50 per pound, as with contingent carrier coverage.
        </li>
    </ul>
</li>
<li class='has-sub' style="border: 1px solid #dddddd;"><a href='#'>
        <div class="faq" style="background-color: #F4F4F4;">
                                        <span
                                            style="padding-right: 10px; font-family: 'Roboto'; font-size: 14pt; color: #198fb8; display: inline; float: left;">Q.</span>
            <h4 class="title"
                style="margin: 0px; display: inline; margin-right: 18px; font-size: 10pt;">
                You Get Your Own Cargo Insurance Policy</h4>
        </div>
    </a>
    <ul style="padding-top: 15px;">
        <li>
            Yes, You will receive your own cargo insurance policy/certificate with the loss payable made out direct to
            you or whomever you choose, unlike coverage from freight carriers in which they cover you under their own
            blanket policy that covers everyone's shipment and funds are paid to them. With us, you get your own policy
            direct from the insurer and claims are paid directly to you.
        </li>
    </ul>
</li>
<li class='has-sub' style="border: 1px solid #dddddd;"><a href='#'>
        <div class="faq" style="background-color: #F4F4F4;">
                                        <span
                                            style="padding-right: 10px; font-family: 'Roboto'; font-size: 14pt; color: #198fb8; display: inline; float: left;">Q.</span>
            <h4 class="title"
                style="margin: 0px; display: inline; margin-right: 18px; font-size: 10pt;">
                No Hassle Fast and Easy Claims Processing</h4>
        </div>
    </a>
    <ul style="padding-top: 15px;">
        <li>
            Yes, The greatest benefit of being covered by a Leading A rated insurer is that you can rest assured that
            they can pay for your loss and will handle claims properly. Our A rated insurers have an outstanding
            financial strength rating and claims payment stability. Claims are handled directly by the insurer, no
            middle third party. We help expedite the process with direct submission to the insurer and the ability for
            you to communicate directly with your dedicated claims handler by phone and email to ensure your claim is
            settled quickly and easily. Our insurers strive to achieve the best possible results with fair and
            expeditious claims processing while providing the highest level of service.
        </li>
    </ul>
</li>
<li class='has-sub' style="border: 1px solid #dddddd;"><a href='#'>
        <div class="faq" style="background-color: #F4F4F4;">
                                        <span
                                            style="padding-right: 10px; font-family: 'Roboto'; font-size: 14pt; color: #198fb8; display: inline; float: left;">Q.</span>
            <h4 class="title"
                style="margin: 0px; display: inline; margin-right: 18px; font-size: 10pt;">
                No Paperwork</h4>
        </div>
    </a>
    <ul style="padding-top: 15px;">
        <li>
            Yes, No registration or long application forms to fill out or approval process in order to use our services.
            No membership fee&#39;s either. Anyone can get started right away and get a quote or buy a cargo insurance
            policy immediately.
        </li>
    </ul>
</li>
<li class='has-sub' style="border: 1px solid #dddddd;"><a href='#'>
        <div class="faq" style="background-color: #F4F4F4;">
                                        <span
                                            style="padding-right: 10px; font-family: 'Roboto'; font-size: 14pt; color: #198fb8; display: inline; float: left;">Q.</span>
            <h4 class="title"
                style="margin: 0px; display: inline; margin-right: 18px; font-size: 10pt;">
                Our Friendly Customer Service</h4>
        </div>
    </a>
    <ul style="padding-top: 15px;">
        <li>
            Yes, Exceptional customer service is our goal and our friendly insurance experts practice it every day. We
            are always here to answer your questions and help assist you with your cargo insurance needs.
        </li>
    </ul>
</li>
</ul>
</div>

</div>
<div class="col span_3_of_12">
    

<link href="source/css/controls.css" rel="stylesheet" type="text/css" visible="true"/>
<style>
    table.estimate tr > td {
        padding: 2px 0px;
    }

    .txtborder {
        border: 1px solid #cccccc;
    }
</style>

<script>
    function f_t_Countries(value) {
        var f_country = document.getElementById('from_country').value;
        var t_country = document.getElementById('to_country').value;
        if (value == 'to_country') {
            if (t_country != 'US') {

            }
        } else if (value == 'from_country') {

        }
    }
</script>

<!--  DATE CALANDER  -->
<link rel="stylesheet" type="text/css" href="source/css/jquery.datetimepicker.css"/>
<script src="source/js/jquery-1.11.1.js"></script>


<script>
    $(function () {
        $("#txt_moving_date").datepicker();
    });
</script>

<div style="width: 225px; height: auto; background-color: #fafafa; margin-bottom: 20px;" align="center">
    <form method="post" action="sidebar-free-estimate-action.php">
        <div
            style="width: 223px;background-color: #056598; border: 1px solid #056598; padding: 5px 0px; font-family: arial; font-size: 10pt; color: #ffffff; font-weight: bold;">
            Get FREE Quotation
        </div>
        <table class="estimate" style="width: 100%; font-family: arial; font-size: 10pt;  border: 1px solid #cccccc;"
               cellspacing="0" cellpadding="0" border="0">
            <tr>
                <td style="padding-left: 10px; padding-top: 10px; font-size: 9pt; color: #666666; padding-bottom: 0px;">

                </td>
            </tr>
            <tr style="height: 33px;">
                <td align="center">
                    <select type="text" id="mode_transport" name="mode_transport" style="width: 90%; margin-top: 0px; "
                            class="form-textbox">
                        <option>Select Mode of Transport</option>
                        <option>By Air</option>
                        <option>By Sea</option>
                        <option>By Land</option>
                        <option>Not Sure</option>
                    </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">Select Commodity</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="center">
                    <select type="text" id="commodity" name="commodity" style="width: 90%; margin-top: 0px;"
                            class="form-textbox">
                        <option>Select From</option>
                        <option value="Select Commodity" selected="selected">Select Commodity</option><option value="Automobile/s">Automobile/s</option><option value="Boat">Boat</option><option value="Charity Goods">Charity Goods</option><option value="Computer/Electronics">Computer/Electronics</option><option value="General Cargo">General Cargo</option><option value="Hazardous Cargo">Hazardous Cargo</option><option value="Machinery">Machinery</option><option value="Metal Scrap">Metal Scrap</option><option value="Motorcycle/s">Motorcycle/s</option><option value="Perishable Cargo">Perishable Cargo</option><option value="Residential">Residential</option><option value="Residential with Vehicle (Auto, Motorcycle etc)">Residential with Vehicle (Auto, Motorcycle etc)</option><option value="Vehicle/s">Vehicle/s</option><option value="Waste Paper">Waste Paper</option><option value="Used Clothing">Used Clothing</option>

                    </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">From Country</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="center">
                    <select type="text" style="width: 90%; margin-top: 0px;" class="form-textbox" id="from_country"
                            name="from_country">
                        <OPTION Value="0">Select From</OPTION>
                                                    <option value="Afghanistan">
                                Afghanistan                            </option>
                                                    <option value="Alaska">
                                Alaska                            </option>
                                                    <option value="Albania">
                                Albania                            </option>
                                                    <option value="Algeria">
                                Algeria                            </option>
                                                    <option value="Angola">
                                Angola                            </option>
                                                    <option value="Antigua">
                                Antigua                            </option>
                                                    <option value="Argentina">
                                Argentina                            </option>
                                                    <option value="Aruba">
                                Aruba                            </option>
                                                    <option value="Australia">
                                Australia                            </option>
                                                    <option value="Austria">
                                Austria                            </option>
                                                    <option value="Bahamas">
                                Bahamas                            </option>
                                                    <option value="Bahrain">
                                Bahrain                            </option>
                                                    <option value="Bangladesh">
                                Bangladesh                            </option>
                                                    <option value="Barbados">
                                Barbados                            </option>
                                                    <option value="Belgium">
                                Belgium                            </option>
                                                    <option value="Belize">
                                Belize                            </option>
                                                    <option value="Benin">
                                Benin                            </option>
                                                    <option value="Brazil">
                                Brazil                            </option>
                                                    <option value="Brunei">
                                Brunei                            </option>
                                                    <option value="Bulgaria">
                                Bulgaria                            </option>
                                                    <option value="Cambodia">
                                Cambodia                            </option>
                                                    <option value="Cameroon">
                                Cameroon                            </option>
                                                    <option value="Canada">
                                Canada                            </option>
                                                    <option value="Canary Islands">
                                Canary Islands                            </option>
                                                    <option value="Caroline">
                                Caroline                            </option>
                                                    <option value="Chile">
                                Chile                            </option>
                                                    <option value="China">
                                China                            </option>
                                                    <option value="Columbia">
                                Columbia                            </option>
                                                    <option value="Comoros Islands">
                                Comoros Islands                            </option>
                                                    <option value="Congo">
                                Congo                            </option>
                                                    <option value="Croatia">
                                Croatia                            </option>
                                                    <option value="Cuba">
                                Cuba                            </option>
                                                    <option value="Cyprus">
                                Cyprus                            </option>
                                                    <option value="Czechoslovakia">
                                Czechoslovakia                            </option>
                                                    <option value="Denmark">
                                Denmark                            </option>
                                                    <option value="Djibouti">
                                Djibouti                            </option>
                                                    <option value="Dominica">
                                Dominica                            </option>
                                                    <option value="Dominican Republic">
                                Dominican Republic                            </option>
                                                    <option value="Ecuador">
                                Ecuador                            </option>
                                                    <option value="Egypt">
                                Egypt                            </option>
                                                    <option value="El Salvador">
                                El Salvador                            </option>
                                                    <option value="Estonia">
                                Estonia                            </option>
                                                    <option value="Ethiopia">
                                Ethiopia                            </option>
                                                    <option value="Fiji">
                                Fiji                            </option>
                                                    <option value="Finland">
                                Finland                            </option>
                                                    <option value="France">
                                France                            </option>
                                                    <option value="Gabon">
                                Gabon                            </option>
                                                    <option value="Gambia">
                                Gambia                            </option>
                                                    <option value="Germany">
                                Germany                            </option>
                                                    <option value="Ghana">
                                Ghana                            </option>
                                                    <option value="Gilbert">
                                Gilbert                            </option>
                                                    <option value="Grand Cayman">
                                Grand Cayman                            </option>
                                                    <option value="Greece">
                                Greece                            </option>
                                                    <option value="Grenada">
                                Grenada                            </option>
                                                    <option value="Guam">
                                Guam                            </option>
                                                    <option value="Guatemala">
                                Guatemala                            </option>
                                                    <option value="Guinea">
                                Guinea                            </option>
                                                    <option value="Guyana">
                                Guyana                            </option>
                                                    <option value="Haiti">
                                Haiti                            </option>
                                                    <option value="Hawaii">
                                Hawaii                            </option>
                                                    <option value="Honduras">
                                Honduras                            </option>
                                                    <option value="Hungary">
                                Hungary                            </option>
                                                    <option value="Iceland">
                                Iceland                            </option>
                                                    <option value="India">
                                India                            </option>
                                                    <option value="Indonesia">
                                Indonesia                            </option>
                                                    <option value="Iran">
                                Iran                            </option>
                                                    <option value="Iraq">
                                Iraq                            </option>
                                                    <option value="Ireland">
                                Ireland                            </option>
                                                    <option value="Israel">
                                Israel                            </option>
                                                    <option value="Italy">
                                Italy                            </option>
                                                    <option value="Ivory Coast">
                                Ivory Coast                            </option>
                                                    <option value="Jamaica">
                                Jamaica                            </option>
                                                    <option value="Japan">
                                Japan                            </option>
                                                    <option value="Jordan">
                                Jordan                            </option>
                                                    <option value="Kenya">
                                Kenya                            </option>
                                                    <option value="Kuwait">
                                Kuwait                            </option>
                                                    <option value="Latvia">
                                Latvia                            </option>
                                                    <option value="Lebanon">
                                Lebanon                            </option>
                                                    <option value="Liberia">
                                Liberia                            </option>
                                                    <option value="Libya">
                                Libya                            </option>
                                                    <option value="Macau">
                                Macau                            </option>
                                                    <option value="Madagascar">
                                Madagascar                            </option>
                                                    <option value="Malagasy">
                                Malagasy                            </option>
                                                    <option value="Malawi">
                                Malawi                            </option>
                                                    <option value="Malaysia">
                                Malaysia                            </option>
                                                    <option value="Maldives">
                                Maldives                            </option>
                                                    <option value="Malta">
                                Malta                            </option>
                                                    <option value="Mariana">
                                Mariana                            </option>
                                                    <option value="Marshall">
                                Marshall                            </option>
                                                    <option value="Martinique">
                                Martinique                            </option>
                                                    <option value="Mauritania">
                                Mauritania                            </option>
                                                    <option value="Mauritius">
                                Mauritius                            </option>
                                                    <option value="Mexico">
                                Mexico                            </option>
                                                    <option value="Micronesia">
                                Micronesia                            </option>
                                                    <option value="Montserrat">
                                Montserrat                            </option>
                                                    <option value="Morocco">
                                Morocco                            </option>
                                                    <option value="Mozambique">
                                Mozambique                            </option>
                                                    <option value="Myanmar">
                                Myanmar                            </option>
                                                    <option value="Namibia">
                                Namibia                            </option>
                                                    <option value="Netherlands">
                                Netherlands                            </option>
                                                    <option value="Netherlands Antilles">
                                Netherlands Antilles                            </option>
                                                    <option value="New Caledonia">
                                New Caledonia                            </option>
                                                    <option value="New Herbrides">
                                New Herbrides                            </option>
                                                    <option value="New Zealand">
                                New Zealand                            </option>
                                                    <option value="Nicaragua">
                                Nicaragua                            </option>
                                                    <option value="Nigeria">
                                Nigeria                            </option>
                                                    <option value="Norway">
                                Norway                            </option>
                                                    <option value="Oman">
                                Oman                            </option>
                                                    <option value="Pakistan">
                                Pakistan                            </option>
                                                    <option value="Panama">
                                Panama                            </option>
                                                    <option value="Papua New Gunea">
                                Papua New Gunea                            </option>
                                                    <option value="Peru">
                                Peru                            </option>
                                                    <option value="Philippines">
                                Philippines                            </option>
                                                    <option value="Poland">
                                Poland                            </option>
                                                    <option value="Portugal">
                                Portugal                            </option>
                                                    <option value="Puerto Rico">
                                Puerto Rico                            </option>
                                                    <option value="Qatar">
                                Qatar                            </option>
                                                    <option value="Reunion Islands">
                                Reunion Islands                            </option>
                                                    <option value="Romania">
                                Romania                            </option>
                                                    <option value="Russia">
                                Russia                            </option>
                                                    <option value="Saudi Arabia">
                                Saudi Arabia                            </option>
                                                    <option value="Scotland">
                                Scotland                            </option>
                                                    <option value="Senegal">
                                Senegal                            </option>
                                                    <option value="Seychelles">
                                Seychelles                            </option>
                                                    <option value="Sierra Leone">
                                Sierra Leone                            </option>
                                                    <option value="Singapore">
                                Singapore                            </option>
                                                    <option value="Solomon Islands">
                                Solomon Islands                            </option>
                                                    <option value="Somalia">
                                Somalia                            </option>
                                                    <option value="South Africa">
                                South Africa                            </option>
                                                    <option value="South Korea">
                                South Korea                            </option>
                                                    <option value="Spain">
                                Spain                            </option>
                                                    <option value="Sri Lanka">
                                Sri Lanka                            </option>
                                                    <option value="St. Kitts">
                                St. Kitts                            </option>
                                                    <option value="St. Maarten">
                                St. Maarten                            </option>
                                                    <option value="St. Vincent">
                                St. Vincent                            </option>
                                                    <option value="Sudan">
                                Sudan                            </option>
                                                    <option value="Surinam">
                                Surinam                            </option>
                                                    <option value="Sweden">
                                Sweden                            </option>
                                                    <option value="Switzerland">
                                Switzerland                            </option>
                                                    <option value="Syria">
                                Syria                            </option>
                                                    <option value="Tahiti">
                                Tahiti                            </option>
                                                    <option value="Taiwan">
                                Taiwan                            </option>
                                                    <option value="Tanzania">
                                Tanzania                            </option>
                                                    <option value="Thailand">
                                Thailand                            </option>
                                                    <option value="Togo">
                                Togo                            </option>
                                                    <option value="Tonga">
                                Tonga                            </option>
                                                    <option value="Trinidad">
                                Trinidad                            </option>
                                                    <option value="Tunisia">
                                Tunisia                            </option>
                                                    <option value="Turkey">
                                Turkey                            </option>
                                                    <option value="Tuvalu">
                                Tuvalu                            </option>
                                                    <option value="UAE">
                                UAE                            </option>
                                                    <option value="Uganda">
                                Uganda                            </option>
                                                    <option value="UK">
                                UK                            </option>
                                                    <option value="Ukraine">
                                Ukraine                            </option>
                                                    <option value="Uruguay">
                                Uruguay                            </option>
                                                    <option value="US">
                                US                            </option>
                                                    <option value="Venezuela">
                                Venezuela                            </option>
                                                    <option value="Vietnam">
                                Vietnam                            </option>
                                                    <option value="Western Samoa">
                                Western Samoa                            </option>
                                                    <option value="Yemen">
                                Yemen                            </option>
                                                    <option value="Yugoslavia">
                                Yugoslavia                            </option>
                                                    <option value="Zaire">
                                Zaire                            </option>
                                                    <option value="Zambia">
                                Zambia                            </option>
                                                    <option value="Zimbabwe">
                                Zimbabwe                            </option>
                                            </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">To Country</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="center"><select type="text" style="width: 90%; margin-top: 0px;" class="form-textbox"
                                           id="to_country" name="to_country">
                        <OPTION Value="0">Select To</OPTION>
                                                    <option value="Afghanistan">
                                Afghanistan                            </option>
                                                    <option value="Alaska">
                                Alaska                            </option>
                                                    <option value="Albania">
                                Albania                            </option>
                                                    <option value="Algeria">
                                Algeria                            </option>
                                                    <option value="Angola">
                                Angola                            </option>
                                                    <option value="Antigua">
                                Antigua                            </option>
                                                    <option value="Argentina">
                                Argentina                            </option>
                                                    <option value="Aruba">
                                Aruba                            </option>
                                                    <option value="Australia">
                                Australia                            </option>
                                                    <option value="Austria">
                                Austria                            </option>
                                                    <option value="Bahamas">
                                Bahamas                            </option>
                                                    <option value="Bahrain">
                                Bahrain                            </option>
                                                    <option value="Bangladesh">
                                Bangladesh                            </option>
                                                    <option value="Barbados">
                                Barbados                            </option>
                                                    <option value="Belgium">
                                Belgium                            </option>
                                                    <option value="Belize">
                                Belize                            </option>
                                                    <option value="Benin">
                                Benin                            </option>
                                                    <option value="Brazil">
                                Brazil                            </option>
                                                    <option value="Brunei">
                                Brunei                            </option>
                                                    <option value="Bulgaria">
                                Bulgaria                            </option>
                                                    <option value="Cambodia">
                                Cambodia                            </option>
                                                    <option value="Cameroon">
                                Cameroon                            </option>
                                                    <option value="Canada">
                                Canada                            </option>
                                                    <option value="Canary Islands">
                                Canary Islands                            </option>
                                                    <option value="Caroline">
                                Caroline                            </option>
                                                    <option value="Chile">
                                Chile                            </option>
                                                    <option value="China">
                                China                            </option>
                                                    <option value="Columbia">
                                Columbia                            </option>
                                                    <option value="Comoros Islands">
                                Comoros Islands                            </option>
                                                    <option value="Congo">
                                Congo                            </option>
                                                    <option value="Croatia">
                                Croatia                            </option>
                                                    <option value="Cuba">
                                Cuba                            </option>
                                                    <option value="Cyprus">
                                Cyprus                            </option>
                                                    <option value="Czechoslovakia">
                                Czechoslovakia                            </option>
                                                    <option value="Denmark">
                                Denmark                            </option>
                                                    <option value="Djibouti">
                                Djibouti                            </option>
                                                    <option value="Dominica">
                                Dominica                            </option>
                                                    <option value="Dominican Republic">
                                Dominican Republic                            </option>
                                                    <option value="Ecuador">
                                Ecuador                            </option>
                                                    <option value="Egypt">
                                Egypt                            </option>
                                                    <option value="El Salvador">
                                El Salvador                            </option>
                                                    <option value="Estonia">
                                Estonia                            </option>
                                                    <option value="Ethiopia">
                                Ethiopia                            </option>
                                                    <option value="Fiji">
                                Fiji                            </option>
                                                    <option value="Finland">
                                Finland                            </option>
                                                    <option value="France">
                                France                            </option>
                                                    <option value="Gabon">
                                Gabon                            </option>
                                                    <option value="Gambia">
                                Gambia                            </option>
                                                    <option value="Germany">
                                Germany                            </option>
                                                    <option value="Ghana">
                                Ghana                            </option>
                                                    <option value="Gilbert">
                                Gilbert                            </option>
                                                    <option value="Grand Cayman">
                                Grand Cayman                            </option>
                                                    <option value="Greece">
                                Greece                            </option>
                                                    <option value="Grenada">
                                Grenada                            </option>
                                                    <option value="Guam">
                                Guam                            </option>
                                                    <option value="Guatemala">
                                Guatemala                            </option>
                                                    <option value="Guinea">
                                Guinea                            </option>
                                                    <option value="Guyana">
                                Guyana                            </option>
                                                    <option value="Haiti">
                                Haiti                            </option>
                                                    <option value="Hawaii">
                                Hawaii                            </option>
                                                    <option value="Honduras">
                                Honduras                            </option>
                                                    <option value="Hungary">
                                Hungary                            </option>
                                                    <option value="Iceland">
                                Iceland                            </option>
                                                    <option value="India">
                                India                            </option>
                                                    <option value="Indonesia">
                                Indonesia                            </option>
                                                    <option value="Iran">
                                Iran                            </option>
                                                    <option value="Iraq">
                                Iraq                            </option>
                                                    <option value="Ireland">
                                Ireland                            </option>
                                                    <option value="Israel">
                                Israel                            </option>
                                                    <option value="Italy">
                                Italy                            </option>
                                                    <option value="Ivory Coast">
                                Ivory Coast                            </option>
                                                    <option value="Jamaica">
                                Jamaica                            </option>
                                                    <option value="Japan">
                                Japan                            </option>
                                                    <option value="Jordan">
                                Jordan                            </option>
                                                    <option value="Kenya">
                                Kenya                            </option>
                                                    <option value="Kuwait">
                                Kuwait                            </option>
                                                    <option value="Latvia">
                                Latvia                            </option>
                                                    <option value="Lebanon">
                                Lebanon                            </option>
                                                    <option value="Liberia">
                                Liberia                            </option>
                                                    <option value="Libya">
                                Libya                            </option>
                                                    <option value="Macau">
                                Macau                            </option>
                                                    <option value="Madagascar">
                                Madagascar                            </option>
                                                    <option value="Malagasy">
                                Malagasy                            </option>
                                                    <option value="Malawi">
                                Malawi                            </option>
                                                    <option value="Malaysia">
                                Malaysia                            </option>
                                                    <option value="Maldives">
                                Maldives                            </option>
                                                    <option value="Malta">
                                Malta                            </option>
                                                    <option value="Mariana">
                                Mariana                            </option>
                                                    <option value="Marshall">
                                Marshall                            </option>
                                                    <option value="Martinique">
                                Martinique                            </option>
                                                    <option value="Mauritania">
                                Mauritania                            </option>
                                                    <option value="Mauritius">
                                Mauritius                            </option>
                                                    <option value="Mexico">
                                Mexico                            </option>
                                                    <option value="Micronesia">
                                Micronesia                            </option>
                                                    <option value="Montserrat">
                                Montserrat                            </option>
                                                    <option value="Morocco">
                                Morocco                            </option>
                                                    <option value="Mozambique">
                                Mozambique                            </option>
                                                    <option value="Myanmar">
                                Myanmar                            </option>
                                                    <option value="Namibia">
                                Namibia                            </option>
                                                    <option value="Netherlands">
                                Netherlands                            </option>
                                                    <option value="Netherlands Antilles">
                                Netherlands Antilles                            </option>
                                                    <option value="New Caledonia">
                                New Caledonia                            </option>
                                                    <option value="New Herbrides">
                                New Herbrides                            </option>
                                                    <option value="New Zealand">
                                New Zealand                            </option>
                                                    <option value="Nicaragua">
                                Nicaragua                            </option>
                                                    <option value="Nigeria">
                                Nigeria                            </option>
                                                    <option value="Norway">
                                Norway                            </option>
                                                    <option value="Oman">
                                Oman                            </option>
                                                    <option value="Pakistan">
                                Pakistan                            </option>
                                                    <option value="Panama">
                                Panama                            </option>
                                                    <option value="Papua New Gunea">
                                Papua New Gunea                            </option>
                                                    <option value="Peru">
                                Peru                            </option>
                                                    <option value="Philippines">
                                Philippines                            </option>
                                                    <option value="Poland">
                                Poland                            </option>
                                                    <option value="Portugal">
                                Portugal                            </option>
                                                    <option value="Puerto Rico">
                                Puerto Rico                            </option>
                                                    <option value="Qatar">
                                Qatar                            </option>
                                                    <option value="Reunion Islands">
                                Reunion Islands                            </option>
                                                    <option value="Romania">
                                Romania                            </option>
                                                    <option value="Russia">
                                Russia                            </option>
                                                    <option value="Saudi Arabia">
                                Saudi Arabia                            </option>
                                                    <option value="Scotland">
                                Scotland                            </option>
                                                    <option value="Senegal">
                                Senegal                            </option>
                                                    <option value="Seychelles">
                                Seychelles                            </option>
                                                    <option value="Sierra Leone">
                                Sierra Leone                            </option>
                                                    <option value="Singapore">
                                Singapore                            </option>
                                                    <option value="Solomon Islands">
                                Solomon Islands                            </option>
                                                    <option value="Somalia">
                                Somalia                            </option>
                                                    <option value="South Africa">
                                South Africa                            </option>
                                                    <option value="South Korea">
                                South Korea                            </option>
                                                    <option value="Spain">
                                Spain                            </option>
                                                    <option value="Sri Lanka">
                                Sri Lanka                            </option>
                                                    <option value="St. Kitts">
                                St. Kitts                            </option>
                                                    <option value="St. Maarten">
                                St. Maarten                            </option>
                                                    <option value="St. Vincent">
                                St. Vincent                            </option>
                                                    <option value="Sudan">
                                Sudan                            </option>
                                                    <option value="Surinam">
                                Surinam                            </option>
                                                    <option value="Sweden">
                                Sweden                            </option>
                                                    <option value="Switzerland">
                                Switzerland                            </option>
                                                    <option value="Syria">
                                Syria                            </option>
                                                    <option value="Tahiti">
                                Tahiti                            </option>
                                                    <option value="Taiwan">
                                Taiwan                            </option>
                                                    <option value="Tanzania">
                                Tanzania                            </option>
                                                    <option value="Thailand">
                                Thailand                            </option>
                                                    <option value="Togo">
                                Togo                            </option>
                                                    <option value="Tonga">
                                Tonga                            </option>
                                                    <option value="Trinidad">
                                Trinidad                            </option>
                                                    <option value="Tunisia">
                                Tunisia                            </option>
                                                    <option value="Turkey">
                                Turkey                            </option>
                                                    <option value="Tuvalu">
                                Tuvalu                            </option>
                                                    <option value="UAE">
                                UAE                            </option>
                                                    <option value="Uganda">
                                Uganda                            </option>
                                                    <option value="UK">
                                UK                            </option>
                                                    <option value="Ukraine">
                                Ukraine                            </option>
                                                    <option value="Uruguay">
                                Uruguay                            </option>
                                                    <option value="US">
                                US                            </option>
                                                    <option value="Venezuela">
                                Venezuela                            </option>
                                                    <option value="Vietnam">
                                Vietnam                            </option>
                                                    <option value="Western Samoa">
                                Western Samoa                            </option>
                                                    <option value="Yemen">
                                Yemen                            </option>
                                                    <option value="Yugoslavia">
                                Yugoslavia                            </option>
                                                    <option value="Zaire">
                                Zaire                            </option>
                                                    <option value="Zambia">
                                Zambia                            </option>
                                                    <option value="Zimbabwe">
                                Zimbabwe                            </option>
                                            </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">Moving Date</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="left">
                    <input type="text" id="txt_moving_date" name="txt_moving_date" class="form-textbox"
                           style="width: 77%; margin-left: 12px;" placeholder="Expected date to ship">
                    <img src="source/images/calendar.PNG" style="position: absolute; padding-top: 3px;">
                </td>
            </tr>
            <tr style="height: 33px;">
                <td align="right" style="padding: 5px 13px 10px 10px;">
                    <input type="submit" id="submit_quote" name="submit_quote" class="naviBlue"
                           value="SUBMIT" style="height: 25px; padding-top: 3px"></td>
            </tr>
        </table>
        <script src="source/js/jquery.datetimepicker.js"></script>
        <script>
            $('#txt_moving_date').datetimepicker({
                lang: 'en',
                timepicker: false,
                closeOnDateSelect: true,
                format: 'm/d/Y',
                formatDate: 'Y/m/d',
                minDate: '2017/01/01', // yesterday is minimum date
                //startDate: '2015/01/01',
                autodateonstart: true,
                maxDate: '2030/12/31' // and tommorow is maximum date calendar
            });
        </script>
    </form>
</div>


<a href="cargo-tracking.php"><img src="source/images/cargo-tracking.png" style="margin-bottom: 20px;"></a>
<a href="about-air7seas.php"><img src="source/images/exp.png" style="margin-bottom: 20px;"></a>
<a href="customer-review.php"><img src="source/images/tp-logo-customer-review.PNG" style="margin-bottom: 20px;"></a>
</div>
</div>
</div>
</div>
</div>
<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" lang="en">


<head>
    <!--Start of Zopim Live Chat Script
    <script type="text/javascript">
        window.$zopim || (function (d, s) {
            var z = $zopim = function (c) {
                z._.push(c)
            }, $ = z.s =
                d.createElement(s), e = d.getElementsByTagName(s)[0];
            z.set = function (o) {
                z.set.
                    _.push(o)
            };
            z._ = [];
            z.set._ = [];
            $.async = !0;
            $.setAttribute('charset', 'utf-8');
            $.src = '//v2.zopim.com/?2NBKvMLseKA8C45Gr5ywmelLErtAkht6';
            z.t = +new Date;
            $.
                type = 'text/javascript';
            e.parentNode.insertBefore($, e)
        })(document, 'script');
    </script>
    End of Zopim Live Chat Script-->
    
    <!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = '3kWxTfUv3x';var d=document;var w=window;function l(){
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
<!-- {/literal} END JIVOSITE CODE -->

    <link href="source/css/sole.css" rel="stylesheet">

<body class="vpform pgTrustPilot" lang="en-GB" align="center">


<div id="footerinfo" style="width: 100%; background-color: #cccccc" align="center">
    <div style="width: 980px; background-color: #ffffff; padding: 10px 0px;" align="left">
        <div id="BreadcrumbWrapper">
            <div class="section group">
                <div class="col span_12_of_12" style="line-height: 23px; border-right: 1px solid #dddddd; ">
                </div>
            </div>
            <hr>
        </div>
        <img src="source/images/logos.jpg" alt="" style="width: 980px;">
        <div style="margin-left:40px;">
            <a id="bbblink" class="ruvtbum" target="_blank" href="https://www.bbb.org/us/ca/milpitas/profile/logistics/air-7-seas-transport-logistics-1216-213698#bbbseal"
        title="AIR 7 SEAS Transport Logistics Inc, Logistics, Milpitas, CA"
        style="display: block;position: relative;overflow: hidden; width: 60px; height: 108px; margin: 0">
        <img style="padding: 0px; border: none;" id="bbblinkimg" src="https://seal-sanjose.bbb.org/logo/ruvtbum/air-7-seas-transport-logistics-213698.png" width="120" height="108" alt="AIR 7 SEAS Transport Logistics Inc, Logistics, Milpitas, CA" />
        </a>    
        </div>
        
        <script type="text/javascript">var bbbprotocol = ( ("https:" == document.location.protocol) ? "https://" : "http://" ); (function(){var s=document.createElement('script');s.src=bbbprotocol + 'seal-sanjose.bbb.org' + unescape('%2Flogo%2Fair-7-seas-transport-logistics-213698.js');s.type='text/javascript';s.async=true;var st=document.getElementsByTagName('script');st=st[st.length-1];var pt=st.parentNode;pt.insertBefore(s,pt.nextSibling);})();
        </script>
    </div>
</div>
<!--footer-->
<footer style="background-color: #4d4d4d">
    <div class="DB MMdLFtR">
        <div class="FL DB MMdLFtRa" style="padding-left: 75px;">

            <div id="FtR" class="LH20 footer-links">
                <div class="left-section FL">
                    <div class="left-wrapper FL">
                        <section class="ordering-fromus">
                            <div class="title">
                                AIR 7 SEAS
                            </div>
                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="about-air7seas.php" id="aContact">About Us</a>
                                    <a href="feedback.php" id="aFAQ">Feedback</a>
                                    <a href="shipping-news.php" id="aOrdertracking">News &amp;
                                        Events</a>
                                    <a href="#">Privacy Policy</a>
                                    <a href="terms-and-conditions.php">Terms &amp;
                                        Conditions</a>
                                    <a href="jobs.php">Jobs</a>
                                </li>
                            </ul>
                        </section>
                        <section class="help-support">
                            <div class="title">
                                SERVICES
                            </div>

                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="international-freight.php">International &#45;
                                        Freight</a>
                                    <a href="domestic-freight.php">Domestic &#45;
                                        Freight</a>
                                    <a href="autos-vehicles-machinery.php">Machinery &amp; Vehicles</a>
                                    <a href="freight-forwarder.php">Freight Forwarding</a>
                                    <a href="customs-release.php">Customs Release</a>
                                    <a href="moving.php">Movers</a>
                                </li>
                            </ul>
                        </section>
                        <section class="information">
                            <div class="title">
                                SUPPORT
                            </div>
                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="faq.php">Frequently Asked Questions</a>
                                    <a href="moving-tips.php">Moving Tips</a>

                                    <a href="payments.php" id="aFreeRecycle">Payment Options</a>
                                    <a href="procedural-steps-for-claim-submition.php">Claim
                                        Submission Procedures</a>
                                    <a href="isf.php">Importer Security Filing (ISF)</a>
                                    <a href="order-online-insurance.php">Order Online -
                                        Insurance</a>

                                </li>
                            </ul>
                        </section>
                    </div>
                    <div class="social-links">


                    </div>
                </div>
                <section class="newsletter">
                    <div class="title">CORPORATE OFFICE</div>
                    <div class="footer-contact">
                        <ul>
                            <li class="f-map"><a
                                    href="contact-us.php"
                                    target="_blank">1815 Houret Court, <br> Milpitas, CA 95035, US</a></li>
                            <li class="f-phone"><span><a href="tel:+18882477732">Call Us: 1-888-247-7732</a></span></li>
                            <li class="f-mail"><a href="mailto:info@air7seas.us">info (@) air7seas.us</a></li>
                        </ul>
                    </div>
                    <br><br>

                    <div>
                        <a href="https://www.facebook.com/pages/Air7Seas-Transport-Logistics-Inc/731149066945233" target="_blank">
                            <img src="source/images/icons/fb.png" style="margin-top: 7px; width: 25px;">
                        </a>&nbsp;
                        <a href="https://twitter.com/Air7seas" target="_blank">
                            <img src="source/images/icons/twitter.png" style="margin-top: 7px; width: 25px;">
                        </a>&nbsp;
                        <a href="https://www.google.com/maps/place/AIR+7+SEAS+Transport+Logistics+Inc/@37.405497,-121.8994427,17z/data=!3m1!4b1!4m5!3m4!1s0x808fceb215c020c3:0x183384c4fb534d3c!8m2!3d37.405497!4d-121.897254" target="_blank">
                            <img src="source/images/icons/gp.png" style="margin-top: 7px; width: 25px;">
                        </a>
                    </div>

                </section>
            </div>
        </div>
    </div>

</footer>

<div class="baseline-footer">
    <div class="baseline-footer-wrapper">
        <section class="FL" itemprop="provider" itemscope itemtype="http://schema.org/Organization">
            <div class="FL">

                <meta itemprop="url" content="http://www.air7seas.com/"/>
                <meta itemprop="name" content="Air 7 Seas Transport Logistics Pvt Ltd"/>
                <meta itemprop="email" content="info@air7seas.com "/>
                <div itemprop="location" itemscope itemtype="http://www.schema.org/LocalBusiness">

                    <meta itemprop="openingHours" content="Mo-Fr 08:00-16:00"/>
                    <meta itemprop="openingHours" content="Sa-Su Holiday"/>
                    <div itemprop="geo" itemscope itemtype="http://schema.org/GeoCoordinates">
                        <meta itemprop="latitude" content="53.55519"/>
                        <meta itemprop="longitude" content="-3.041651"/>
                    </div>
                </div>

            </div>
            <div class="contact-information">
                <div id="pnlUKFooter">

                    <div class="address" itemprop=address itemscope itemtype=http://schema.org/PostalAddress>
                        <span class="address-image"></span>

                        <div class="address-wrapper">
                            <span itemprop=streetAddress><a href="contact-us.php" style="color: #cfcfcf;">1815 Houret
                                    Court,<br> Milpitas, CA 95035</a></span>,
                            <span itemprop=addressLocality>USA</span>
                        </div>
                    </div>
                    <div class="phone-number">
                        <span class="phone-image"></span>
                        <span class="telephone" itemprop=telephone><a href="tel:+18882477732" style="color: #cfcfcf;">1-888-247-7732</a></span>
                        <span class="sales-support">(Customer Support)</span>
                    </div>
                    <div class="email-address">
                        <span class="email-img"></span>
                        <span itemprop=email><a class="mail-id"
                                                href="mailto:info@air7seas.us">info (@) air7seas.us</a></span>
                    </div>


                </div>

            </div>
        </section>


        <div itemprop="copyrightHolder" itemscope itemtype="http://www.schema.org/Organization"
             class="copywrite-holder">
            <meta itemprop="url" content="http://www.air7seas.com/"/>
            <meta itemprop="name" content="Air 7 Seas Transport Logistics Pvt Ltd"/>

            <meta itemprop="email" content="info@air7seas.com "/>

            Copyright <span class="copyrights">&copy;</span> AIR 7 SEAS 2014 &#45; 2015
        </div>
        <meta itemprop="copyrightYear" content="1986-2014"/>

        <div class="divAuthorisedText">Authorised and regulated by AIR 7 SEAS 95035</div>


    </div>
</div>

</body>
</html>

</body>
</html>