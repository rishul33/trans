
<!DOCTYPE html>
<html>
<head>
    <title>Shipping to Canada - AIR 7 SEAS</title>
    <link rel="shortcut icon" href="source/images/a7s-icon.ico"/>
    <meta charset="utf-8"/>
    <meta name="description"
          content="shipping to canada, shipping from usa to canada, shipping to canada from usa, cheap shipping overseas, international movers, shipping household goods to canada, air freight to canada, sea freight to canada, international freight shipping quote, international freight companies, low cost international shipping, cheap shipping to canada, freight shipping to canada, car shipping to canada, shipping supplies canada, packing and shipping services, ocean cargo shipping, low cost international shipping, international car shipping rates, freight estimate, car transporting, overseas vehicle shipping">
    <meta name="keywords"
          content="Overseas Relocation, Moving Overseas, Relocation Services, Shipping India, Shipping USA, Freight Forwarder, Air Freight, Air Cargo, Customs Clearance, International Shipping Companies, Moving Estimate, Shipping Quote, Moving International, Domestic Movers, Shipping Agent, Shipping International, International Moving Service, Cargo Agent, Customs Broker, International Mover, Household Goods, Commercial Goods, Breakbulk Cargo, Car Shipping, Motorbike Shipping, Auto Vehicle Mechinery, Cargo Consolidation, Freight Service Provider">
    <meta name="author" content="Air 7 Seas Transport Logistics Pvt Ltd">
    <!--  <base href="http://www.air7seas.com/"> -->

    <link href="source/css/responsive.css" rel="stylesheet">
    <link href="source/css/sole.css" rel="stylesheet" type="text/css" visible="true"/>


    <style type="text/css">
        ul.ff-service {
            font-size: 9pt;
            padding-left: 25px;
        }

        ul.ff-service li {
            margin: 5px;
            line-height: 1.5;
            list-style: square;

        }

        div.div-border {
            border: 1px solid #e4e4e4;
            background-color: #f4f4f4;
        }
    </style>


</head>
<body>
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link href="source/css/sole.css" rel="stylesheet" type="text/css" visible="true"/>
    <link href="source/css/skin.css" rel="stylesheet" type="text/css" visible="true"/>

    <link
        href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800'
        rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="source/css/megadrop.css"/>
    <script type="text/javascript" src="source/js/megascripts.js"></script>
    <style>
        .searchbox {
            height: 28px;
            width: 225px;
            border: 1px solid #dadada;
            border-top-left-radius: 3px;
            border-bottom-left-radius: 3px;
            padding-left: 10px;
            font-size: 12px;
            color: #9b9b9b
        }

        .searchbutton {
            cursor: pointer;
            background-image: url('source/images/search.GIF');
            height: 30px;
            width: 70px;
            margin-top: 0;
            color: transparent
        }

        .txtSearchbox::-webkit-input-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox:-moz-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox::-moz-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox:-ms-input-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }
    </style>
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NQDLZPP');</script>
<!-- End Google Tag Manager -->
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NQDLZPP"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div id="topLine">
</div>
<div id="main-header" align="center" style="font-family: Arial;">
    <div id="main-header-area" align="left">
        <a href="index.php">
            <img src="source/images/logo-new.png" alt="Air 7 Seas" style="float: left; position: relative;"></a>

        <div class="top-small-link" style=" vertical-align: middle">
            <table border="0">
                <tr style="vertical-align: top">
                    <td style="padding-top: 3px;">
                        <a href="cargo-tracking.php" style="color: #404040; font-family: Arial;"><b>Cargo
                                Tracking</b></a>|
                        <a href="about-air7seas.php">About Us</a>|
                        <a href="https://portal.cargoez.com/air7seas/login" target="_blank">Login</a>|
                        <a href="shipping-news.php">News &amp; Events</a>

                    </td>
                    <td style="vertical-align: top;"><img src="source/images/phone-ico.PNG" alt=""
                                                          style="margin-top: 0px;">
                    </td>
                    <td style="padding: 3px 0 0 5px; width: 185px;">
                        <span style="font-size: 13pt; float: right"><span style="font-size: 9pt;">Toll Free:</span>
                        <a href="tel:+18882477732"
                           style="padding-left: 0px; padding-right: 0px; margin-right: 0px; color: #026799;"><b>1-888-247-7732<b/></a></span>
                    </td>

                </tr>
                <tr>
                    <td colspan="3" style="">
                        <div id="SrCl" style="padding-top: 8px; float: right">
                            <form method="post" action="search-results.php">

                                <input type="text" id="find" name="find" autocomplete="off"
                                       class="searchbox txtSearchbox" placeholder="How can i help you...?">
                                <input type="submit" name="" style="border:0px; height: 28px;" class="searchbutton"
                                       alt="Search"/>

                            </form>
                        </div>
                    </td>
                </tr>
            </table>


        </div>


    </div>
</div>
<div id="menu-bar" style="width: 100%; background-color: #1e6a89;" align="center">
<div style="width: 980px;" align="left">
<ul class="nav-mainmenu clearfix animated">
<li><a href="index.php">Home</a></li>
<li>
    <a href="#">Services</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px; ">

            <ul class="menu-items">
                <li class="seperator"><a href="international-freight.php" style="font-weight: 600">International
                        Freight</a></li>
                <li class="seperator"><a href="domestic-freight.php">Domestic Freight</a></li>
                <li class="seperator"><a href="freight-forwarder.php">Freight Forwarding</a></li>
                <li class="seperator"><a href="freight-consultation.php">Consultation</a></li>

            </ul>
        </div>
    </div>
</li>
<li><a href="#">Products</a>

    <div class="container-2" style="width: 500px;">
        <table border="0">
            <tr>
                <td style="border-right:1px solid #ccc; vertical-align: top;">
                    <div class="col1" style="width: 250px;">

                        <ul class="menu-items">


                            <li class="seperator"><a href="shipping-to-vietnam.php"><img
                                        src="source/images/Vietnam-Flag-icon.png" alt="Vietnam Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Saigon Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-india.php"><img
                                        src="source/images/India-Flag-icon.png" alt="India Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">India Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-middle-east.php"><img
                                        src="source/images/MiddleEast-Flag-icon.png" alt="Shipping to Middle East"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Middle East Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-china.php"><img
                                        src="source/images/China-Flag-icon.png" alt="China Shipper"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">China Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-philippines.php"><img
                                        src="source/images/Philippines-Flag-icon.png" alt="Philippines Shipper"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Manila Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-spain.php"><img
                                        src="source/images/Spain-Flag-icon.png" alt="Spain Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Spain Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-mexico.php"><img
                                        src="source/images/Mexico-Flag-icon.png" alt="Mexico Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Mexico Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="autos-to-canada.php"><img
                                        src="source/images/Canada-Flag-icon.png" alt="Canada Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Autos to Canada</span></a>
                            </li>
  <li class="seperator"><a href="importers-logistics-rep.php">Importer&#39;s Rep</a></li>

                        </ul>
                    </div>
                </td>
                <td style="vertical-align: top;">
                    <div class="col1" style="width: 250px;">

                        <ul class="menu-items">
                            <li class="seperator"><a href="shipping-to-africa.php">
                                    <img src="source/images/Africa-Flag-icon.png" alt="AfriCargo Express" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">AfriCargo Express</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-latin-america.php">
                                    <img src="source/images/Latino-Flag-icon.png" alt="Latino Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Latino Shipper</span></a>
                            </li>
                              <li class="seperator"><a href="nvo.php">
                                    <img src="source/images/lcl-icon.jpg" alt="Latino Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Cargo-Coloader LCL</span></a>
                            </li>
                            <li class="seperator"><a href="a7s-pre-fulfilment-service.php"><img src="source/images/receiving-center-icon.png"
                                                                                      alt="Air7seas Pre-Fulfillment Service" width="22px"
                                                                                      style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Pre-Fulfillment &amp; Delivery </span></a></li>
                            <li class="seperator"><a href="receiving-center.php"><img src="source/images/receiving-center-icon.png"
                                                                                      alt="Mexico Shipper" width="22px"
                                                                                      style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Pre-Shipping Receiving Center</span></a></li>
                            <!--<li class="seperator"><a href="receiving-center.php">Receiving Center</a></li>-->
                            <li class="seperator"><a href="partners-agents.php"><img
                                        src="source/images/partners-agents-icon.png" alt="Canada Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Partners - Agents</span></a>
                            </li>
                            <li class="seperator"><a href="autos-vehicles-machinery.php"><img
                                        src="source/images/autos-vehicle-mechinery-icon.png" alt="Mexico Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Autos Vehicles Machinery</span></a>
                            </li>
                            <li class="seperator"><a href="transloading-transhipment.php">Transloading -
                                    Transhipment</a></li>
                            <li class="seperator"><a href="ship-hazardous-perishable-goods.php">Hazardous &amp;
                                    Perishable</a></li>


                        </ul>
                    </div>
                </td>
            </tr>
        </table>


    </div>
</li>
<li><a href="#">Mover &amp; Relocation</a>

    <div class="container-4" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="move-household-goods.php">Household Goods</a></li>
                <li class="seperator"><a href="ship-commercial-goods.php">Commercial Goods</a></li>
                <!--     <li class="seperator"><a href="#">Countries served</a></li> -->
            </ul>
        </div>
    </div>
</li>
<li><a href="#">Freight Carrier</a>

    <div class="container-4" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="air-freight-carrier.php">Air Freight Carrier</a></li>
                <li class="seperator"><a href="ocean-freight-carrier.php">Ocean Freight Carrier</a>
                </li>
                <li class="seperator"><a href="soc-movements.php">SOC Movements</a></li>
            </ul>
        </div>
    </div>
</li>
<li>
    <a href="#">Customs Release</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="export-import.php"">Export - Import</a></li>
                <li class="seperator"><a href="isf.php">ISF / AMS</a></li>
                <li class="seperator"><a href="importers-logistics-rep.php">Importer&#39;s Rep</a></li>
            </ul>
        </div>
    </div>
</li>

<li><a href="#">Insurance</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="cargo-insurance-coverage-types.php">Coverage Types</a></li>
                <li class="seperator"><a href="free-estimate-insurance.php">Free Estimate - Insurance</a>
                </li>
                <li class="seperator"><a href="order-online-insurance.php">Order Online - Insurance</a></li>
                <li class="seperator"><a href="claim-submission.php">Claim submission Form</a></li>
                <li class="seperator"><a href="faq-insurance.php">FAQ</a></li>
                <!--<li class="seperator"><a href="#">Resources - Insurance</a></li>-->
                <li class="seperator"><a href="damages-to-the-goods-by-customs.php">Damages to the goods by
                        Customs</a></li>

            </ul>
        </div>
    </div>
</li>
<li><a href="#">Contact Us</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="contact-us.php">Contacts</a></li>
                <li class="seperator"><a href="free-estimatesdetails.php">Get an Estimate</a></li>
                <li class="seperator"><a href="ordernowdetails.php">Book a Shipment</a></li>
                <li class="seperator"><a href="feedback.php">Feedback</a></li>
                <li class="seperator"><a href="complaint.php">Complaint</a></li>
                <li class="seperator"><a href="customer-review.php">Testimonial</a></li>
                <li class="seperator"><a href="claim-submission.php">Claim submission</a></li>
                <li class="seperator"><a href="terms-and-conditions.php">Terms &amp; Conditions</a></li>
                <li class="seperator"><a href="jobs.php">Jobs</a></li>
            </ul>
        </div>
    </div>
</li>
<li><a href="#" class="last-list">Tools &amp; Resources</a>

    <div class="container-1 right" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="forms-downloads.php">Documents &amp; Forms</a></li>
                <li class="seperator"><a href="payments.php">Payment options</a></li>
                <li class="seperator"><a href="moving-tips.php">Moving Tips</a></li>
                <li class="seperator"><a href="container-sizes.php">Container Sizes for Sea</a></li>
                <li class="seperator"><a href="faq.php">FAQs</a></li>
                <li class="seperator"><a href="shipping-news.php">News &amp; Events</a></li>
                <li class="seperator"><a href="ask-a-question.php">Ask a question</a></li>
            </ul>
        </div>
    </div>
</li>

</ul>
</div>

</div>
<div id="info-bar" style="box-shadow: 0px 3px 3px 0px rgba(0, 0, 0, 0.15); position: relative; z-index: 100;"
     align="center">
    <div id="info-bar-area" align="left">
        <div class="top-thin-links">
            <div class="thin-links-wrapper">
                <a class="review" href="free-estimatesdetails.php"><span class="icon"></span><span>Free Shipping Estimate</span></a>
                <a class="finance" href="estimate-sizeof-shipment.php"><span
                        class="icon"></span><span>Moving Calculator</span></a>
                <a class="facebook" href="moving-tips.php"><span class="icon"></span><span>Moving Tips</span></a>
                <a class="catalogue" href="ordernowdetails.php"><span class="icon"></span><span>Order Online</span></a>
                <a class="trade-account" href="ask-a-question.php"><span class="icon"></span><span>Shipping ?</span></a>
            </div>
        </div>
    </div>
</div>

</body>
</html>
<div id="contents" align="center">
<div id="contentsArea" align="left" style="padding-left: 20px;">

<!-- Top Information Bar -->
<div id="BreadcrumbWrapper" style="width: 940px;">
    <div id="Breadcrumb" class="Breadcrumb BoxSBB">
         <span itemscope itemtype='#'>
             <a href="index.php" itemprop='url' title="Air7seas Homepage">
                 <span itemprop='title'>Home</span>
             </a>
         </span>
        &rsaquo; <span itemscope itemtype='#'><span itemprop='title'><b>Products</b></span></span>
        &rsaquo; <span itemscope itemtype='#'><span itemprop='title'><b>Shipping to Canada</b></span></span>
    </div>

</div>

<div id="BreadcrumbWrapper" class="FL HMenu" style="margin-top: 0px;">
<div class="section group">
<div class="col span_9_of_12" style="vertical-align: top; padding-right: 20px;">
<h1 style="font-size: 18pt; font-family: 'open sans'; color: #3b3b3b; margin-bottom: 10px; font-weight: 600;">
    Shipping to Canada</h1>
<a href="lcl-cargo.php" style="position: absolute; margin-top: -25px; margin-left: 500px; font-size: 11pt;" class="resource-link">LCL Cargo</a>
<hr style="border: 0px; border-bottom:1px solid #dedede; padding-top: 4px;">
<h2 class="title" style="margin-top: 15px;">HOUSEHOLD GOODS AND PERSONAL EFFECTS</h2>

<h3 style="font-size: 11pt; font-weight: 700;">Documents Required</h3>

<ul class="ff-service" style="padding: 10px 10px 10px 25px;">
    <li>Copy of Passport (photo page only)</li>
    <li>Proof of Residency abroad for at least 1 year (bank statements, utilities, rent
        receipts, income tax statement, etc. for first and last month of 12&#45;month period)
        (returning citizens)
    </li>
    <li>Detailed inventory / Packing list in English or French</li>
    <li>Receipts for new items</li>
    <li>Original Bill of Lading (OBL) / Air Waybill (AWB)</li>
    <li>Liquor Permit, if applicable</li>
    <li>Immigration papers, if applicable</li>
    <li>Work Permit / Student Visa holders, if applicable</li>
    <li>Proof of residence in Canada (copy of Deed / Sales Agreement / Lease Agreement)
        (seasonal residents)
    </li>
    <li>Copy of Death Certificate (import of inheritance items)</li>
    <li>Copy of Will or Letter from the Executor of an estate (import of inheritance items)</li>
    <li>Obligation for Privilege from the Canadian Ministry of External Affairs (Diplomats)</li>
</ul>
<br>

<h3 style="font-size: 11pt; font-weight: 700;">Specific Information</h3>

<div style="background-color: #f4f4f4; margin-top: 5px;">
    <ul class="ff-service" style="padding: 10px 10px 10px 25px;">
        <li>The shipper must be present for Customs clearance.</li>
        <li>Returning Canadians may import household goods and personal effects duty free under the
            following conditions:
            <ul style="list-style: disc; padding-left: 50px;">
                <li>The goods were owned and used by the shipper for at least 6 months prior to
                    importation.
                </li>
                <li>The shipper lived abroad for a minimum of 12 months. If the shipper lived abroad
                    for a period greater than 5 years, the shipper is exempt from the 6&#45;month
                    ownership rule.
                </li>
                <li>The goods must still be owned and used and the shipment can not include goods
                    that are for resale or otherwise disposed of within 12 months of importation.
                </li>
            </ul>
        </li>
        <!--<li>Shipments must be declared to Customs at the port of entry (POE) (airport/U.S-Canada
            border) when the shipper arrives in Canada. Customs will then issue documents needed for
            Customs clearance: B4e Personal Effects Accounting Document and B15 Casual Goods
            Accounting Document. The shipper must present a list of items to be imported. It is
            recommended that a copy of the packing list / inventory be hand carried for presentation
            to Customs. Customs may request a value on the shipment (returning citizens).
        </li>-->
        <li>For immigrants and holders of Work / Student Visas, the goods must be owned and used
            prior to importation and the shipment must not include goods that are to be sold or
            otherwise disposed of 12 months after importation for duty&#45;free import.
        </li>
        <li>Any single item of household goods or personal effects, including automobiles, that were
            acquired after March 31, 1977, and are valued at more than $10,000 are subject to
            regular duty and taxes on the excess amount.
        </li>
        <li>Seasonal residents may import household items and personal effects duty free under the
            following conditions:
            <ul style="list-style: disc; padding-left: 50px;">
                <li>The shipment can include household furniture and furnishings for a seasonal
                    residence, excluding construction, materials, electrical fixtures or other goods
                    permanently attached to or incorporated into a seasonal residence and tools and
                    equipment for the maintenance of a seasonal residence.
                </li>
                <li>The goods must have been owned and used prior to arrival.</li>
                <li>The goods cannot be sold for at least 1 year.</li>
                <li>The goods are for the personal use of that person or their family and are not
                    for any commercial, industrial or occupational purpose.
                </li>
                <li>Proof of purchase or a copy of a Lease Agreement is required for any person who
                    is not a resident of Canada but owns a residential property or has leased a
                    residence for at least 3 years for personal use.
                </li>
                <li>Only one shipment of this type is allowed.</li>
            </ul>
        </li>
        <li>The copy of the Will or Letter from the Executor of an estate must state that the
            shipper is the beneficiary of the named items for duty&#45;free import (duty&#45;free
            inheritances).
        </li>
        <li>Diplomats can import household goods and personal effects duty and tax free.</li>
        <li>The Canadian Government adopted ISPM&#45;15 (International standards for Phytosanitary
            Measures Publication 15) Guidelines for Regulating Wood Packaging Material in
            International Trade (aka NIFM&#45;15) to standardize the treatment of wood packing
            materials
            used for the transport of goods.
        </li>
        <li>ISPM No. 15 requires that wood packaging either be heat&#45;treated or fumigated with
            methyl
            bromide and marked with the internationally recognized International Plant Protection
            Convention (IPPC) mark, or in lieu of the mark, the consignment must be accompanied by a
            Phytosanitary Certificate specifying the treatment used.
        </li>
    </ul>
</div>
<br>
<hr style="border-bottom: 1px solid #DDDDDD;">
<h2 class="title" style="margin-top: 15px;">MOTOR VEHICLES</h2>

<h3 style="font-size: 11pt; font-weight: 700;">Documents Required</h3>

<ul class="ff-service" style="padding: 10px 10px 10px 25px;">
    <li>Copy of Passport (photo page only)</li>
    <li>Original proof of ownership (can be sent with the vehicle)</li>
    <li>OBL</li>
    <li>Previous Registration</li>
</ul>

<br>

<h3 style="font-size: 11pt; font-weight: 700;">Specific Information</h3>

<div style="background-color: #f4f4f4; margin-top: 5px;">
    <ul class="ff-service" style="padding: 10px 10px 10px 25px;">
        <li>The car must comply with Canadian standards.</li>
        <li>All vehicles are inspected by the Canadian Agricultural Inspection Agency upon arrival
            into Canada.
        </li>
        <li>The vehicle must be owned and used for more than 6 months in order to qualify for tax
            and duty relief.
        </li>
        <li>For returning residents, a tax and duty exemption applied to the first $10,000 of the
            vehicle&#39;s value. Anything in excess of $10,000 will be charged applicable duties and
            taxes.
        </li>
        <li>For Work Permit / Student Visa holders, duty and tax will be waived for the duration of
            the permit. The vehicle will be imported on a temporary basis for the duration of the
            Work Permit / Student Visa must be re&#45;exported upon departure from Canada.
        </li>
        <li>All cars / motorbikes should be clean on arrival and free of any soil or containments.
        </li>
        <li>It is recommended to include proof of cleaning (receipts) with the shipping documents.
        </li>
        <li>The vehicle cannot contain household goods and personal effects.</li>
        <li>Motor vehicles imported into Canada cannot be licensed in Canada unless cleared through
            Canadian Customs.
        </li>
    </ul>
</div>
<br>
<hr style="border-bottom: 1px solid #DDDDDD;">
<h2 class="title" style="margin-top: 15px;">ANTIQUES / ART EFFECTS / CARPETS / PAINTINGS</h2>

<ul class="ff-service" style="padding: 10px 10px 10px 25px;">
    <li>No documents are required if the items are part of the household effects shipment. Proof
        of age will be required if item is over 100 years old.
    </li>
    <li>
        The items are permitted duty free entry if the following conditions are met:
        <ul>
            <li>The works of art are part of a bona fide household removal.</li>
            <li>The works of art are not for sale or other disposal.</li>
        </ul>
    </li>
    <li>Antiques and works of art imported into Canada for resale, are subject to different
        regulations.
    </li>
</ul>

<br>
<hr style="border-bottom: 1px solid #DDDDDD;">
<h2 class="title" style="margin-top: 15px;">WEDDING TROUSSEAU / GIFTS</h2>

<ul class="ff-service" style="padding: 10px 10px 10px 25px;">
    <li>Wedding &quot;trousseau&quot; means goods acquired for use in the household of a newly married
        couple, but
        does not include vehicles, vessels or aircraft; wedding &quot;gifts&quot; means goods of a non&#45;commercial
        nature received by a person as personal gifts in consideration of that person&#39;s recent marriage
        or the anticipated marriage of that person within three months of the person&#45;s return to Canada.
    </li>
    <li>
        Wedding trousseau and gifts may be imported duty and tax free providing:
        <ul>
            <li>A bride&#39;s trousseau / gifts owned by, in the possession of, and imported by a recently
                married person or a bride&#45;to&#45;be whose anticipated marriage is to take place within 3
                months of the date of her return to Canada or has taken place no more than 3 months
                prior to arrival in Canada.
            </li>
        </ul>
    </li>
</ul>

<br>
<hr style="border-bottom: 1px solid #DDDDDD;">
<h2 class="title" style="margin-top: 15px;">RESTRICTED / DUTIABLE ITEMS</h2>

<div style="background-color: #f4f4f4; margin-top: 5px;">
    <ul class="ff-service" style="padding: 10px 10px 10px 25px;">
        <li>Alcohol (a detailed list including type, size, and quantity is required and an Import Permit must be
            obtained prior to importation; duties and taxes apply)
        </li>
        <li>Do not ship wine between October 1 and March 31 to avoid the possibility of freezing.</li>
        <li>Tobacco products are subject to duties and taxes.</li>
        <li>Foodstuffs can cause extensive delays / additional charges (importation is discouraged)</li>
        <li>Meat (authorization is required; importation is discouraged)</li>
        <li>Pornographic materials</li>
        <li>New items (a Bill of Sale may be required by Customs)</li>
        <li>Hunting trophies (restrictions apply, especially for endangered species; a CITES Certificate may be
            required; check with agent before shipping).
        </li>
        <li>Firearms (strict regulations apply; check with agent for details)</li>
        <li>Any one item valued at $10,000 or over is subject to duties and taxes.</li>
    </ul>
</div>
<br>
<hr style="border-bottom: 1px solid #DDDDDD;">
<h2 class="title" style="margin-top: 15px;">PROHIBITED ITEMS</h2>

<ul class="ff-service" style="padding: 10px 10px 10px 25px;">
    <li>Live plants</li>
    <li>Narcotics, drugs, incitements</li>
    <li>Fruits and vegetables</li>
    <li>Live ammunition and explosives</li>
</ul>
<br>
<hr style="border-bottom: 1px solid #DDDDDD;">
<h2 class="title" style="margin-top: 15px;">CONSIGNMENT INSTRUCTIONS</h2>

<p><b>Recommended:</b> Contact the destination agent to ensure all requirements have been met prior to import,
    especially for
    differences regarding air / sea shipments.</p><br>
<br>
<hr style="border-bottom: 1px solid #DDDDDD;">
<h2 class="title" style="margin-top: 15px;">Checklist for Importing Commercial Goods into Canada</h2>

<p>This checklist, to be used in conjunction with the Step-by-Step Guide to Importing Commercial Goods into
    Canada, is intended to complement and not replace existing regulations, acts and references. </p><br>
<b>Importing requirements include the following:</b>
<ul class="ff-service" style="padding: 10px 10px 10px 25px;">
    <li>Obtain your import/export business number from the Canada Revenue Agency.</li>
    <li>Identify what type of goods you want to import.</li>
    <li>Determine whether you will use the services of a customs broker.</li>
    <li>Determine the country of origin for the goods you are importing.</li>
    <li>Verify whether the goods are controlled, regulated or prohibited by the Canada Border Services Agency
        (CBSA) or any other government department or agency.</li>
    <li>Ensure that the goods are marked and labelled as required.</li>
    <li>Determine the 10-digit tariff classification number and the applicable rate of duty for each of the items
        you are importing using the Customs Tariff.</li>
    <li>Determine whether the goods are subject to any other duties or taxes including the goods and services
        tax (GST).</li>
    <li>Obtain invoices, certificates of origin and any other required documents.</li>
    <li>Determine the value for duty of your goods you are importing.</li>
    <li>Select the method of shipping and communicate with the transportation company on cross-border
        requirements.</li>
    <li>Await notification that your shipment has arrived.</li>
    <li>Submit the required CBSA documents and pay any duties and taxes owing in order to have the goods
        released. Note: Shipments valued at CAN$2,500 or less arriving by mail or courier may be assessed for
        duties and taxes and then released by the CBSA or the courier company.</li>
</ul>
<b>Please note:</b>
<ul class="ff-service" style="padding: 10px 10px 10px 25px;">
    <li>The shipment may be examined by government officials. Fees charged by authorized third parties to
        unload and reload goods are the responsibility of the importer.</li>
<li>If you make an error in the accounting information provided to the CBSA, you are required to correct
    the declaration if the change is revenue-neutral or if you owe money.</li>
    <li>Keep records of your import documents for a period of six years following the importation.</li>
    <li>Be aware that the CBSA uses the Administrative Monetary Penalty System (AMPS) to assess monetary
        penalties against businesses that do not comply with customs legislation.
    </li>
    </li>
</ul>

<!--<p><i><b>IAM Note:</b> Customs regulations can change at any time with or without notice. This document is provided as a
        guide
        and for information only. While IAM has exercised reasonable care in publishing this document, IAM makes no
        representation, either expressed or implied, as to its accuracy or applicability.</i></p>-->

<p style="margin-top: 20px;" align="center"><i>Information shown is as of August 2015. Subject to change without notice.</i></p>
</div>
<div class="col span_3_of_12">
    

<link href="source/css/controls.css" rel="stylesheet" type="text/css" visible="true"/>
<style>
    table.estimate tr > td {
        padding: 2px 0px;
    }

    .txtborder {
        border: 1px solid #cccccc;
    }
</style>

<script>
    function f_t_Countries(value) {
        var f_country = document.getElementById('from_country').value;
        var t_country = document.getElementById('to_country').value;
        if (value == 'to_country') {
            if (t_country != 'US') {

            }
        } else if (value == 'from_country') {

        }
    }
</script>

<!--  DATE CALANDER  -->
<link rel="stylesheet" type="text/css" href="source/css/jquery.datetimepicker.css"/>
<script src="source/js/jquery-1.11.1.js"></script>


<script>
    $(function () {
        $("#txt_moving_date").datepicker();
    });
</script>

<div style="width: 225px; height: auto; background-color: #fafafa; margin-bottom: 20px;" align="center">
    <form method="post" action="sidebar-free-estimate-action.php">
        <div
            style="width: 223px;background-color: #056598; border: 1px solid #056598; padding: 5px 0px; font-family: arial; font-size: 10pt; color: #ffffff; font-weight: bold;">
            Get FREE Quotation
        </div>
        <table class="estimate" style="width: 100%; font-family: arial; font-size: 10pt;  border: 1px solid #cccccc;"
               cellspacing="0" cellpadding="0" border="0">
            <tr>
                <td style="padding-left: 10px; padding-top: 10px; font-size: 9pt; color: #666666; padding-bottom: 0px;">

                </td>
            </tr>
            <tr style="height: 33px;">
                <td align="center">
                    <select type="text" id="mode_transport" name="mode_transport" style="width: 90%; margin-top: 0px; "
                            class="form-textbox">
                        <option>Select Mode of Transport</option>
                        <option>By Air</option>
                        <option>By Sea</option>
                        <option>By Land</option>
                        <option>Not Sure</option>
                    </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">Select Commodity</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="center">
                    <select type="text" id="commodity" name="commodity" style="width: 90%; margin-top: 0px;"
                            class="form-textbox">
                        <option value="Select Commodity" selected="selected">Select Commodity</option><option value="Automobile/s">Automobile/s</option><option value="Boat">Boat</option><option value="Charity Goods">Charity Goods</option><option value="Computer/Electronics">Computer/Electronics</option><option value="General Cargo">General Cargo</option><option value="Hazardous Cargo">Hazardous Cargo</option><option value="Machinery">Machinery</option><option value="Metal Scrap">Metal Scrap</option><option value="Motorcycle/s">Motorcycle/s</option><option value="Perishable Cargo">Perishable Cargo</option><option value="Residential">Residential</option><option value="Residential with Vehicle (Auto, Motorcycle etc)">Residential with Vehicle (Auto, Motorcycle etc)</option><option value="Vehicle/s">Vehicle/s</option><option value="Waste Paper">Waste Paper</option><option value="Used Clothing">Used Clothing</option>                    </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">From Country</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="center">
                    <select type="text" style="width: 90%; margin-top: 0px;" class="form-textbox" id="from_country"
                            name="from_country">
                        <OPTION Value="0">Select From</OPTION>
                        <option value="US">US</option><option value="Canada">Canada</option>                    </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">To Country</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="center"><select type="text" style="width: 90%; margin-top: 0px;" class="form-textbox"
                                           id="to_country" name="to_country">
                        <OPTION Value="0">Select To</OPTION>
                        <option value="US">US</option><option value="Canada">Canada</option>                    </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">Moving Date</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="left">
                    <input type="text" id="txt_moving_date" name="txt_moving_date" class="form-textbox"
                           style="width: 77%; margin-left: 12px;" placeholder="Expected date to ship">
                    <img src="source/images/calendar.PNG" style="position: absolute; padding-top: 3px;">
                </td>
            </tr>
            <tr style="height: 33px;">
                <td align="right" style="padding: 5px 13px 10px 10px;">
                    <input type="submit" id="submit_quote" name="submit_quote" class="naviBlue"
                           value="SUBMIT" style="height: 25px; padding-top: 3px"></td>
            </tr>
        </table>
        <script src="source/js/jquery.datetimepicker.js"></script>
        <script>
            $('#txt_moving_date').datetimepicker({
                lang: 'en',
                timepicker: false,
                closeOnDateSelect: true,
                format: 'm/d/Y',
                formatDate: 'Y/m/d',
                minDate: '2017/01/01', // yesterday is minimum date
                //startDate: '2015/01/01',
                autodateonstart: true,
                maxDate: '2030/12/31' // and tommorow is maximum date calendar
            });
        </script>
    </form>
</div>


<a href="cargo-tracking.php"><img src="source/images/cargo-tracking.png" style="margin-bottom: 20px;"></a>
<a href="about-air7seas.php"><img src="source/images/exp.png" style="margin-bottom: 20px;"></a>
<a href="customer-review.php"><img src="source/images/tp-logo-customer-review.PNG" style="margin-bottom: 20px;"></a>
</div>
</div>
</div>
</div>
</div>
<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" lang="en">


<head>
    <!--Start of Zopim Live Chat Script
    <script type="text/javascript">
        window.$zopim || (function (d, s) {
            var z = $zopim = function (c) {
                z._.push(c)
            }, $ = z.s =
                d.createElement(s), e = d.getElementsByTagName(s)[0];
            z.set = function (o) {
                z.set.
                    _.push(o)
            };
            z._ = [];
            z.set._ = [];
            $.async = !0;
            $.setAttribute('charset', 'utf-8');
            $.src = '//v2.zopim.com/?2NBKvMLseKA8C45Gr5ywmelLErtAkht6';
            z.t = +new Date;
            $.
                type = 'text/javascript';
            e.parentNode.insertBefore($, e)
        })(document, 'script');
    </script>
    End of Zopim Live Chat Script-->
    
    <!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = '3kWxTfUv3x';var d=document;var w=window;function l(){
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
<!-- {/literal} END JIVOSITE CODE -->

    <link href="source/css/sole.css" rel="stylesheet">

<body class="vpform pgTrustPilot" lang="en-GB" align="center">


<div id="footerinfo" style="width: 100%; background-color: #cccccc" align="center">
    <div style="width: 980px; background-color: #ffffff; padding: 10px 0px;" align="left">
        <div id="BreadcrumbWrapper">
            <div class="section group">
                <div class="col span_12_of_12" style="line-height: 23px; border-right: 1px solid #dddddd; ">
                </div>
            </div>
            <hr>
        </div>
        <img src="source/images/logos.jpg" alt="" style="width: 980px;">
        <div style="margin-left:40px;">
            <a id="bbblink" class="ruvtbum" target="_blank" href="https://www.bbb.org/us/ca/milpitas/profile/logistics/air-7-seas-transport-logistics-1216-213698#bbbseal"
        title="AIR 7 SEAS Transport Logistics Inc, Logistics, Milpitas, CA"
        style="display: block;position: relative;overflow: hidden; width: 60px; height: 108px; margin: 0">
        <img style="padding: 0px; border: none;" id="bbblinkimg" src="https://seal-sanjose.bbb.org/logo/ruvtbum/air-7-seas-transport-logistics-213698.png" width="120" height="108" alt="AIR 7 SEAS Transport Logistics Inc, Logistics, Milpitas, CA" />
        </a>    
        </div>
        
        <script type="text/javascript">var bbbprotocol = ( ("https:" == document.location.protocol) ? "https://" : "http://" ); (function(){var s=document.createElement('script');s.src=bbbprotocol + 'seal-sanjose.bbb.org' + unescape('%2Flogo%2Fair-7-seas-transport-logistics-213698.js');s.type='text/javascript';s.async=true;var st=document.getElementsByTagName('script');st=st[st.length-1];var pt=st.parentNode;pt.insertBefore(s,pt.nextSibling);})();
        </script>
    </div>
</div>
<!--footer-->
<footer style="background-color: #4d4d4d">
    <div class="DB MMdLFtR">
        <div class="FL DB MMdLFtRa" style="padding-left: 75px;">

            <div id="FtR" class="LH20 footer-links">
                <div class="left-section FL">
                    <div class="left-wrapper FL">
                        <section class="ordering-fromus">
                            <div class="title">
                                AIR 7 SEAS
                            </div>
                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="about-air7seas.php" id="aContact">About Us</a>
                                    <a href="feedback.php" id="aFAQ">Feedback</a>
                                    <a href="shipping-news.php" id="aOrdertracking">News &amp;
                                        Events</a>
                                    <a href="#">Privacy Policy</a>
                                    <a href="terms-and-conditions.php">Terms &amp;
                                        Conditions</a>
                                    <a href="jobs.php">Jobs</a>
                                </li>
                            </ul>
                        </section>
                        <section class="help-support">
                            <div class="title">
                                SERVICES
                            </div>

                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="international-freight.php">International &#45;
                                        Freight</a>
                                    <a href="domestic-freight.php">Domestic &#45;
                                        Freight</a>
                                    <a href="autos-vehicles-machinery.php">Machinery &amp; Vehicles</a>
                                    <a href="freight-forwarder.php">Freight Forwarding</a>
                                    <a href="customs-release.php">Customs Release</a>
                                    <a href="moving.php">Movers</a>
                                </li>
                            </ul>
                        </section>
                        <section class="information">
                            <div class="title">
                                SUPPORT
                            </div>
                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="faq.php">Frequently Asked Questions</a>
                                    <a href="moving-tips.php">Moving Tips</a>

                                    <a href="payments.php" id="aFreeRecycle">Payment Options</a>
                                    <a href="procedural-steps-for-claim-submition.php">Claim
                                        Submission Procedures</a>
                                    <a href="isf.php">Importer Security Filing (ISF)</a>
                                    <a href="order-online-insurance.php">Order Online -
                                        Insurance</a>

                                </li>
                            </ul>
                        </section>
                    </div>
                    <div class="social-links">


                    </div>
                </div>
                <section class="newsletter">
                    <div class="title">CORPORATE OFFICE</div>
                    <div class="footer-contact">
                        <ul>
                            <li class="f-map"><a
                                    href="contact-us.php"
                                    target="_blank">1815 Houret Court, <br> Milpitas, CA 95035, US</a></li>
                            <li class="f-phone"><span><a href="tel:+18882477732">Call Us: 1-888-247-7732</a></span></li>
                            <li class="f-mail"><a href="mailto:info@air7seas.us">info (@) air7seas.us</a></li>
                        </ul>
                    </div>
                    <br><br>

                    <div>
                        <a href="https://www.facebook.com/pages/Air7Seas-Transport-Logistics-Inc/731149066945233" target="_blank">
                            <img src="source/images/icons/fb.png" style="margin-top: 7px; width: 25px;">
                        </a>&nbsp;
                        <a href="https://twitter.com/Air7seas" target="_blank">
                            <img src="source/images/icons/twitter.png" style="margin-top: 7px; width: 25px;">
                        </a>&nbsp;
                        <a href="https://www.google.com/maps/place/AIR+7+SEAS+Transport+Logistics+Inc/@37.405497,-121.8994427,17z/data=!3m1!4b1!4m5!3m4!1s0x808fceb215c020c3:0x183384c4fb534d3c!8m2!3d37.405497!4d-121.897254" target="_blank">
                            <img src="source/images/icons/gp.png" style="margin-top: 7px; width: 25px;">
                        </a>
                    </div>

                </section>
            </div>
        </div>
    </div>

</footer>

<div class="baseline-footer">
    <div class="baseline-footer-wrapper">
        <section class="FL" itemprop="provider" itemscope itemtype="http://schema.org/Organization">
            <div class="FL">

                <meta itemprop="url" content="http://www.air7seas.com/"/>
                <meta itemprop="name" content="Air 7 Seas Transport Logistics Pvt Ltd"/>
                <meta itemprop="email" content="info@air7seas.com "/>
                <div itemprop="location" itemscope itemtype="http://www.schema.org/LocalBusiness">

                    <meta itemprop="openingHours" content="Mo-Fr 08:00-16:00"/>
                    <meta itemprop="openingHours" content="Sa-Su Holiday"/>
                    <div itemprop="geo" itemscope itemtype="http://schema.org/GeoCoordinates">
                        <meta itemprop="latitude" content="53.55519"/>
                        <meta itemprop="longitude" content="-3.041651"/>
                    </div>
                </div>

            </div>
            <div class="contact-information">
                <div id="pnlUKFooter">

                    <div class="address" itemprop=address itemscope itemtype=http://schema.org/PostalAddress>
                        <span class="address-image"></span>

                        <div class="address-wrapper">
                            <span itemprop=streetAddress><a href="contact-us.php" style="color: #cfcfcf;">1815 Houret
                                    Court,<br> Milpitas, CA 95035</a></span>,
                            <span itemprop=addressLocality>USA</span>
                        </div>
                    </div>
                    <div class="phone-number">
                        <span class="phone-image"></span>
                        <span class="telephone" itemprop=telephone><a href="tel:+18882477732" style="color: #cfcfcf;">1-888-247-7732</a></span>
                        <span class="sales-support">(Customer Support)</span>
                    </div>
                    <div class="email-address">
                        <span class="email-img"></span>
                        <span itemprop=email><a class="mail-id"
                                                href="mailto:info@air7seas.us">info (@) air7seas.us</a></span>
                    </div>


                </div>

            </div>
        </section>


        <div itemprop="copyrightHolder" itemscope itemtype="http://www.schema.org/Organization"
             class="copywrite-holder">
            <meta itemprop="url" content="http://www.air7seas.com/"/>
            <meta itemprop="name" content="Air 7 Seas Transport Logistics Pvt Ltd"/>

            <meta itemprop="email" content="info@air7seas.com "/>

            Copyright <span class="copyrights">&copy;</span> AIR 7 SEAS 2014 &#45; 2015
        </div>
        <meta itemprop="copyrightYear" content="1986-2014"/>

        <div class="divAuthorisedText">Authorised and regulated by AIR 7 SEAS 95035</div>


    </div>
</div>

</body>
</html>

</body>
</html>