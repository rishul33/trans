<!DOCTYPE html>
<html>
<head>
    <title>Shipping to India from USA with AIR 7 SEAS</title>
    <link rel="shortcut icon" href="source/images/a7s-icon.ico"/>
    <meta charset="utf-8"/>
    <meta name="description"
          content="shipping to india, shipping from usa to india, shipping to india from usa, cheap shipping overseas, international movers, shipping household goods to india, air freight to india, sea freight to india, international freight shipping quote, international freight companies, low cost international shipping, cheap shipping to vietnam, shipping charges to india, shipping cost to india, usa to india shipping rates, cheapest shipping from usa to india, shipping charges from india to usa, shipping luggage from india to usa, cheap shipping companies, international shipping companies in usa, how to ship from usa to india, door to door shipping, shipping tv to india">
    <meta name="keywords"
          content="Overseas Relocation, Moving Overseas, Relocation Services, Shipping India, Shipping USA, Freight Forwarder, Air Freight, Air Cargo, Customs Clearance, International Shipping Companies, Moving Estimate, Shipping Quote, Moving International, Domestic Movers, Shipping Agent, Shipping International, International Moving Service, Cargo Agent, Customs Broker, International Mover, Household Goods, Commercial Goods, Breakbulk Cargo, Car Shipping, Motorbike Shipping, Auto Vehicle Mechinery, Cargo Consolidation, Freight Service Provider">
    <meta name="author" content="Air 7 Seas Transport Logistics Pvt Ltd">
    <!--  <base href="http://www.air7seas.com/"> -->

    <link href="source/css/responsive.css" rel="stylesheet">
    <link href="source/css/sole.css" rel="stylesheet" type="text/css" visible="true"/>
    <link href="source/css/faq_accordion.css" rel="stylesheet" type="text/css">
    <script src="source/js/jquery-latest.min.js" type="text/javascript"></script>
    <script src="source/js/script.js" type="text/javascript"></script>

    <script src="source/modal-popup/jquery-1.4.3.min.js" type="text/javascript"></script>
    <link href="source/css/modal-popup.css" rel="stylesheet">
    <style>
        p, h2 {
            margin: 10px 0px;
        }

        #mab_bg {
            top: 0;
            width: 100%;
            background-color: rgba(0, 0, 0, 0.6);
            position: fixed;
            z-index: 999;
            height: 100%;
            display: none;
        }

        #map_expand {
            opacity: 1.6;
            margin-top: 10px;
            position: relative;
            z-index: 999999;
        }

    </style>
    
    <!-- Global site tag (gtag.js) - Google Ads: 881822992 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-881822992"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-881822992');
</script>


<!-- Event snippet for Conversion Rate for India Campaign conversion page -->
<script>
  gtag('event', 'conversion', {'send_to': 'AW-881822992/q-WBCMa7qGoQkJq-pAM'});
</script>


    <script>
        /*(function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function () {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

        ga('create', 'UA-54008281-2', 'auto');
        ga('send', 'pageview');*/

    </script>

    <script>
        $(function () {
            $("#show_map").click(function () {
                $("#mab_bg").show(400);
            });
            $("#close_info").click(function () {
                $("#mab_bg").hide(400);
            });
            $("#mab_bg").click(function () {
                $("#mab_bg").hide(400);
            });
        });
    </script>
</head>
<body>

<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/881822992/?label=q-WBCMa7qGoQkJq-pAM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>


<!--BING tracking-->
<script>(function(w,d,t,r,u){var f,n,i;w[u]=w[u]||[],f=function(){var o={ti:"5437466"};o.q=w[u],w[u]=new UET(o),w[u].push("pageLoad")},n=d.createElement(t),n.src=r,n.async=1,n.onload=n.onreadystatechange=function(){var s=this.readyState;s&&s!=="loaded"&&s!=="complete"||(f(),n.onload=n.onreadystatechange=null)},i=d.getElementsByTagName(t)[0],i.parentNode.insertBefore(n,i)})(window,document,"script","//bat.bing.com/bat.js","uetq");</script><noscript><img src="//bat.bing.com/action/0?ti=5437466&Ver=2" height="0" width="0" style="display:none; visibility: hidden;" /></noscript>

<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link href="source/css/sole.css" rel="stylesheet" type="text/css" visible="true"/>
    <link href="source/css/skin.css" rel="stylesheet" type="text/css" visible="true"/>

    <link
        href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800'
        rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="source/css/megadrop.css"/>
    <script type="text/javascript" src="source/js/megascripts.js"></script>
    <style>
        .searchbox {
            height: 28px;
            width: 225px;
            border: 1px solid #dadada;
            border-top-left-radius: 3px;
            border-bottom-left-radius: 3px;
            padding-left: 10px;
            font-size: 12px;
            color: #9b9b9b
        }

        .searchbutton {
            cursor: pointer;
            background-image: url('source/images/search.GIF');
            height: 30px;
            width: 70px;
            margin-top: 0;
            color: transparent
        }

        .txtSearchbox::-webkit-input-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox:-moz-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox::-moz-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox:-ms-input-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }
    </style>
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NQDLZPP');</script>
<!-- End Google Tag Manager -->
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NQDLZPP"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div id="topLine">
</div>
<div id="main-header" align="center" style="font-family: Arial;">
    <div id="main-header-area" align="left">
        <a href="index.php">
            <img src="source/images/logo-new.png" alt="Air 7 Seas" style="float: left; position: relative;"></a>

        <div class="top-small-link" style=" vertical-align: middle">
            <table border="0">
                <tr style="vertical-align: top">
                    <td style="padding-top: 3px;">
                        <a href="cargo-tracking.php" style="color: #404040; font-family: Arial;"><b>Cargo
                                Tracking</b></a>|
                        <a href="about-air7seas.php">About Us</a>|
                        <a href="https://portal.cargoez.com/air7seas/login" target="_blank">Login</a>|
                        <a href="shipping-news.php">News &amp; Events</a>

                    </td>
                    <td style="vertical-align: top;"><img src="source/images/phone-ico.PNG" alt=""
                                                          style="margin-top: 0px;">
                    </td>
                    <td style="padding: 3px 0 0 5px; width: 185px;">
                        <span style="font-size: 13pt; float: right"><span style="font-size: 9pt;">Toll Free:</span>
                        <a href="tel:+18882477732"
                           style="padding-left: 0px; padding-right: 0px; margin-right: 0px; color: #026799;"><b>1-888-247-7732<b/></a></span>
                    </td>

                </tr>
                <tr>
                    <td colspan="3" style="">
                        <div id="SrCl" style="padding-top: 8px; float: right">
                            <form method="post" action="search-results.php">

                                <input type="text" id="find" name="find" autocomplete="off"
                                       class="searchbox txtSearchbox" placeholder="How can i help you...?">
                                <input type="submit" name="" style="border:0px; height: 28px;" class="searchbutton"
                                       alt="Search"/>

                            </form>
                        </div>
                    </td>
                </tr>
            </table>


        </div>


    </div>
</div>
<div id="menu-bar" style="width: 100%; background-color: #1e6a89;" align="center">
<div style="width: 980px;" align="left">
<ul class="nav-mainmenu clearfix animated">
<li><a href="index.php">Home</a></li>
<li>
    <a href="#">Services</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px; ">

            <ul class="menu-items">
                <li class="seperator"><a href="international-freight.php" style="font-weight: 600">International
                        Freight</a></li>
                <li class="seperator"><a href="domestic-freight.php">Domestic Freight</a></li>
                <li class="seperator"><a href="freight-forwarder.php">Freight Forwarding</a></li>
                <li class="seperator"><a href="freight-consultation.php">Consultation</a></li>

            </ul>
        </div>
    </div>
</li>
<li><a href="#">Products</a>

    <div class="container-2" style="width: 500px;">
        <table border="0">
            <tr>
                <td style="border-right:1px solid #ccc; vertical-align: top;">
                    <div class="col1" style="width: 250px;">

                        <ul class="menu-items">


                            <li class="seperator"><a href="shipping-to-vietnam.php"><img
                                        src="source/images/Vietnam-Flag-icon.png" alt="Vietnam Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Saigon Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-india.php"><img
                                        src="source/images/India-Flag-icon.png" alt="India Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">India Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-middle-east.php"><img
                                        src="source/images/MiddleEast-Flag-icon.png" alt="Shipping to Middle East"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Middle East Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-china.php"><img
                                        src="source/images/China-Flag-icon.png" alt="China Shipper"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">China Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-philippines.php"><img
                                        src="source/images/Philippines-Flag-icon.png" alt="Philippines Shipper"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Manila Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-spain.php"><img
                                        src="source/images/Spain-Flag-icon.png" alt="Spain Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Spain Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-mexico.php"><img
                                        src="source/images/Mexico-Flag-icon.png" alt="Mexico Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Mexico Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="autos-to-canada.php"><img
                                        src="source/images/Canada-Flag-icon.png" alt="Canada Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Autos to Canada</span></a>
                            </li>
  <li class="seperator"><a href="importers-logistics-rep.php">Importer&#39;s Rep</a></li>

                        </ul>
                    </div>
                </td>
                <td style="vertical-align: top;">
                    <div class="col1" style="width: 250px;">

                        <ul class="menu-items">
                            <li class="seperator"><a href="shipping-to-africa.php">
                                    <img src="source/images/Africa-Flag-icon.png" alt="AfriCargo Express" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">AfriCargo Express</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-latin-america.php">
                                    <img src="source/images/Latino-Flag-icon.png" alt="Latino Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Latino Shipper</span></a>
                            </li>
                              <li class="seperator"><a href="nvo.php">
                                    <img src="source/images/lcl-icon.jpg" alt="Latino Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Cargo-Coloader LCL</span></a>
                            </li>
                            <li class="seperator"><a href="a7s-pre-fulfilment-service.php"><img src="source/images/receiving-center-icon.png"
                                                                                      alt="Air7seas Pre-Fulfillment Service" width="22px"
                                                                                      style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Pre-Fulfillment &amp; Delivery </span></a></li>
                            <li class="seperator"><a href="receiving-center.php"><img src="source/images/receiving-center-icon.png"
                                                                                      alt="Mexico Shipper" width="22px"
                                                                                      style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Pre-Shipping Receiving Center</span></a></li>
                            <!--<li class="seperator"><a href="receiving-center.php">Receiving Center</a></li>-->
                            <li class="seperator"><a href="partners-agents.php"><img
                                        src="source/images/partners-agents-icon.png" alt="Canada Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Partners - Agents</span></a>
                            </li>
                            <li class="seperator"><a href="autos-vehicles-machinery.php"><img
                                        src="source/images/autos-vehicle-mechinery-icon.png" alt="Mexico Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Autos Vehicles Machinery</span></a>
                            </li>
                            <li class="seperator"><a href="transloading-transhipment.php">Transloading -
                                    Transhipment</a></li>
                            <li class="seperator"><a href="ship-hazardous-perishable-goods.php">Hazardous &amp;
                                    Perishable</a></li>


                        </ul>
                    </div>
                </td>
            </tr>
        </table>


    </div>
</li>
<li><a href="#">Mover &amp; Relocation</a>

    <div class="container-4" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="move-household-goods.php">Household Goods</a></li>
                <li class="seperator"><a href="ship-commercial-goods.php">Commercial Goods</a></li>
                <!--     <li class="seperator"><a href="#">Countries served</a></li> -->
            </ul>
        </div>
    </div>
</li>
<li><a href="#">Freight Carrier</a>

    <div class="container-4" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="air-freight-carrier.php">Air Freight Carrier</a></li>
                <li class="seperator"><a href="ocean-freight-carrier.php">Ocean Freight Carrier</a>
                </li>
                <li class="seperator"><a href="soc-movements.php">SOC Movements</a></li>
            </ul>
        </div>
    </div>
</li>
<li>
    <a href="#">Customs Release</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="export-import.php"">Export - Import</a></li>
                <li class="seperator"><a href="isf.php">ISF / AMS</a></li>
                <li class="seperator"><a href="importers-logistics-rep.php">Importer&#39;s Rep</a></li>
            </ul>
        </div>
    </div>
</li>

<li><a href="#">Insurance</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="cargo-insurance-coverage-types.php">Coverage Types</a></li>
                <li class="seperator"><a href="free-estimate-insurance.php">Free Estimate - Insurance</a>
                </li>
                <li class="seperator"><a href="order-online-insurance.php">Order Online - Insurance</a></li>
                <li class="seperator"><a href="claim-submission.php">Claim submission Form</a></li>
                <li class="seperator"><a href="faq-insurance.php">FAQ</a></li>
                <!--<li class="seperator"><a href="#">Resources - Insurance</a></li>-->
                <li class="seperator"><a href="damages-to-the-goods-by-customs.php">Damages to the goods by
                        Customs</a></li>

            </ul>
        </div>
    </div>
</li>
<li><a href="#">Contact Us</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="contact-us.php">Contacts</a></li>
                <li class="seperator"><a href="free-estimatesdetails.php">Get an Estimate</a></li>
                <li class="seperator"><a href="ordernowdetails.php">Book a Shipment</a></li>
                <li class="seperator"><a href="feedback.php">Feedback</a></li>
                <li class="seperator"><a href="complaint.php">Complaint</a></li>
                <li class="seperator"><a href="customer-review.php">Testimonial</a></li>
                <li class="seperator"><a href="claim-submission.php">Claim submission</a></li>
                <li class="seperator"><a href="terms-and-conditions.php">Terms &amp; Conditions</a></li>
                <li class="seperator"><a href="jobs.php">Jobs</a></li>
            </ul>
        </div>
    </div>
</li>
<li><a href="#" class="last-list">Tools &amp; Resources</a>

    <div class="container-1 right" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="forms-downloads.php">Documents &amp; Forms</a></li>
                <li class="seperator"><a href="payments.php">Payment options</a></li>
                <li class="seperator"><a href="moving-tips.php">Moving Tips</a></li>
                <li class="seperator"><a href="container-sizes.php">Container Sizes for Sea</a></li>
                <li class="seperator"><a href="faq.php">FAQs</a></li>
                <li class="seperator"><a href="shipping-news.php">News &amp; Events</a></li>
                <li class="seperator"><a href="ask-a-question.php">Ask a question</a></li>
            </ul>
        </div>
    </div>
</li>

</ul>
</div>

</div>
<div id="info-bar" style="box-shadow: 0px 3px 3px 0px rgba(0, 0, 0, 0.15); position: relative; z-index: 100;"
     align="center">
    <div id="info-bar-area" align="left">
        <div class="top-thin-links">
            <div class="thin-links-wrapper">
                <a class="review" href="free-estimatesdetails.php"><span class="icon"></span><span>Free Shipping Estimate</span></a>
                <a class="finance" href="estimate-sizeof-shipment.php"><span
                        class="icon"></span><span>Moving Calculator</span></a>
                <a class="facebook" href="moving-tips.php"><span class="icon"></span><span>Moving Tips</span></a>
                <a class="catalogue" href="ordernowdetails.php"><span class="icon"></span><span>Order Online</span></a>
                <a class="trade-account" href="ask-a-question.php"><span class="icon"></span><span>Shipping ?</span></a>
            </div>
        </div>
    </div>
</div>

</body>
</html>
<div id="contents" align="center">

<!--       MODAL POPUP STARTS      -->
<div id="mab_bg" style="">
    <div id="map_expand" style="opacity: 100;">
        <table style="border: 2px solid #336699; background-color: #FFFFFF;"
               cellpadding="3" cellspacing="0">
            <tr>
                <td class="web_dialog_title">Shipping to India Service map</td>
                <td class="web_dialog_title align_right">
                    <a href="#" id="close_info">Close</a>
                </td>
            </tr>
            <tr style="height: 0px;">
                <td colspan="2"></td>
            </tr>
            <tr>
                <td colspan="2" style="padding: 5px;">
                    <img src="source/documents/maps/india-map.jpg" alt="Shipping to India from USA"
                         style="width: 480px;">
                </td>
            </tr>
            <tr>
                <td colspan="2" align="right"
                    style="padding-right: 20px; font-size: 11pt; font-weight: 600;">
                    <a href="source/documents/maps/india-map.jpg" class="resource-link"></a>
                </td>
            </tr>
        </table>
    </div>
</div>

<!--       MODAL POPUP ENDS      -->

<div id="contentsArea" align="left" style="padding-left: 20px;">

<!-- Top Information Bar -->
<div id="BreadcrumbWrapper" style="width: 690px; margin-top: 12px;">
    <div id="Breadcrumb" class="Breadcrumb BoxSBB">
         <span itemscope itemtype='#'>
             <a href="index.php" itemprop='url' title="Air7seas Homepage">
                 <span itemprop='title'>Home</span>
             </a>
         </span>
        &rsaquo; <span itemscope itemtype='#'><span itemprop='title'><b>Products</b></span></span>
        &rsaquo; <span itemscope itemtype='#'><span itemprop='title'><b>Shipping to India</b></span></span>
    </div>
</div>

<div id="BreadcrumbWrapper" class="FL HMenu" style="margin-top: 0px;">
<div class="section group">

<div class="col span_9_of_12" style="vertical-align: top; padding-right: 20px;">
<h1 style="font-size: 18pt; font-family: 'open sans'; color: #3b3b3b; margin-bottom: 15px; font-weight: 600;">
    Shipping to India</h1>
<a href="http://export.gov/faq/eg_main_028022.asp" class="resource-link"
   style="position: absolute; margin-left: 470px; margin-top: -30px; font-size: 10pt;" target="_blank">Personal Goods
    &amp; Gift Exports</a>

<div style="width: 700px; height: 120px; margin-bottom: 5px;"><img
        src="source/images/shipping-to-india-banner.png" alt="Shipping to India" width="660px"/></div>
<p id="si-0">There are number of major international cargo shipping ports available in India. If any
    customer is interested in moving overseas to India, it may be worth to use our transporting
    services.</p>

<p id="si-1">Our door to door international services start with packing, loading, trucking, storage,
    transporting, crating, air &amp; ocean freight, customs clearance, door delivery, unloading,
    unpacking &amp; removal of wastages. Whatever the items customer need they can transport whether
    it may be their entire house or just a few goods, whether the customer might have self pack or
    they want us to pack, whether the customer want storage in us or India; we have the experts for
    the package. We have some classified services.</p>

<a href="source/documents/faq-documents/A7S-USA-ISC-Flyer-Afghanistan.png" style="font-size: 10pt; font-weight: 700;"
   class="resource-link" target="_blank">India,
    Pakistan, Bangladesh, Sri Lanka, Afghanistan &amp; Nepal Service flyer</a>
<h2 class="title" style="padding-top: 10px;">Full Container Load (FCL)</h2>

<p id="si-2">FCL is the most effective container shipping way regarding cost, volume and weight of
    the cargo. The process of FCL involves the following, picking up empty freight container at the
    container yard, loading at the shipper facility, transporting by truck or rail to the port of
    loading and further ocean container shipping of the cargo to the port of arrival and delivery to
    the customer&#39;s final destination. FCL is the most appropriate choice for customer&#39;s
    ocean cargo transportation for sizable ocean freight shipping. Containers offer the convenience
    of loading customer&#39;s own freight and the ability to track its progress on the journey. Full
    Container Load (FCL) as the name implies, is the standard form of shipping freight for the
    customer who have large amount of goods to be transported. We have some FCL services as
    below:</p>

<table style="width: 100%;">
    <tr>
        <td>
            <div style="width: 100%; margin-top: 20px;">
                <img id="show_map" src="source/documents/maps/india-map.jpg" alt="Shipping to India Service map"
                     style="cursor: pointer; border: 1px solid #00a7eb; width: 380px;">
            </div>
        </td>
        <td style="vertical-align: top; padding-left: 10px;">
            <ul style="background-color: #f4f4f4; line-height: 2; list-style: square; padding-left: 30px;">
                <li style="padding-top: 10px;">Minimize delays with cross&#45;customer.</li>
                <li>Use strategic consolidation hubs in Asia and India.</li>
                <li>Expedite customer&#39;s shipments with a sea&#45;air services combination.</li>
                <li style="padding-bottom: 10px;">Reliability and fast transit times.</li>
            </ul>
            <!-- HIDDEN KEYWORDS FOR ADWORDS -->
            <ul style="display: none;">
                <li>relocation to Mumbai</li>
<li> relocation to india</li>
<li> goods to india</li>
<li> deliver to india</li>
<li> delivery to India</li>
<li> moving to india</li>
<li> moving to mumbai</li>
<li> moving to delhi</li>
<li> moving to chennai</li>
<li> freight to india</li>
<li> relocate to india</li>
<li> airfreight to india</li>
<li> airfreight to Mumbai</li>
<li> airfreight to Chennai</li>
<li> cargo to mumbai</li>
<li> forwarder to india</li>
<li> forwarder to Mumbai</li>
<li> freight to mumbai</li>
<li> freight to Kolkata</li>
<li> mover to Bangalore</li>
<li> mover to Chennai</li>
<li> mover to Delhi</li>
<li> mover to india</li>
<li> moving to new delhi</li>
<li> moving to Pune</li>
<li> relocation to Bangalore</li>
<li> relocation to Chennai</li>
<li> shipping to New Delhi</li>

            </ul>
            <span style="display: none;">relocation to Mumbai, relocation to india, goods to india, deliver to india, delivery to India, moving to india, moving to mumbai, moving to delhi, moving to chennai, freight to india, relocate to india, airfreight to india, airfreight to Mumbai, airfreight to Chennai, cargo to mumbai, forwarder to india, forwarder to Mumbai, freight to mumbai, freight to Kolkata, mover to Bangalore, mover to Chennai, mover to Delhi, mover to india, moving to new delhi, moving to Pune, relocation to Bangalore, relocation to Chennai, shipping to New Delhi</span>
            
        </td>
    </tr>
</table>
<h2 class="title" style="padding-top: 10px;">Less than Container Load (LCL)</h2>

<p id="si-3">When customer doesn&#39;t have enough cargo to fill an ocean freight container, we
    offer LCL (Less than Container Load) service between major ports. That means we can offer space
    within a container that is shared with other customer&#39;s goods to deliver economical usage
    based costing. Less than Container Load is a shipment that will not fill a container. Our LCL
    shipping solutions allow customer to reduce inventory costs quicker, decrease the risk of
    obsolescence sooner, and customer will benefit from greater control, high security and better
    visibility while the shipments are on the water. Customer&#39;s goods travel in a shipping
    container, along with other people&#39;s things that are going to the same port. So, customer
    still gets the same care and protection as a full container load. Our LCL services have some
    features as below:</p>
<ul style="background-color: #f4f4f4; line-height: 2; list-style: square; padding-left: 50px;">
    <li style="padding-top: 10px;">Minimize delays with cross&#45;customer.</li>
    <li>Use strategic consolidation hubs in Asia and India.</li>
    <li>Expedite customer&#39;s shipments with a sea&#45;air services combination.</li>
    <li style="padding-bottom: 10px;">Reliability and fast transit times.</li>
</ul>
<h2 class="title">Air Freight to India:</h2>

<p id="si-4">Customer needs an air freight service provider with high performance standards and the
    flexibility to meet customer&#39;s changing needs. Customer&#39;s air freight requirements are
    confidence and reliability with our air freight services. Our primary responsibility is to ship
    customer&#39;s freight on time and customer&#39;s destination. Safety of customer&#39;s freight
    is also most important for us, we take most care to all freights that do not meet any damage in
    forwarding process. We use advanced, online technology to track customer&#39;s freight movements
    in real time.</p>
<h2 class="title" >Ocean Freight to India:</h2>

<p id="si-5">We are committed to provide our clients with reliable, flexible shipping solutions at
    ocean freight based on expertise gained from years of experience. We ensure that customer&#39;s
    cargo delivered their final destination at the right time in a cost&#45;efficient way. Ocean
    transportation is the backbone of most freight forwarding services. Our ocean freight
    transportation offers shipping for both large and small volumes using Less than Container and
    Full Container Load services. Below are some the features of our ocean freight:</p>
<ul style="background-color: #F4F4F4; line-height: 2; padding-left: 50px; list-style: square;">
    <li style="padding-top: 10px;">Door to door services.</li>
    <li>Advanced tracking &amp; reporting options.</li>
    <li>Multiple levels of ocean freight services to meet customer needs</li>
    <li style="padding-bottom: 10px;">Simplify customer&#39;s transportation and freight services with a single
        provider.
    </li>
</ul>
<p id="si-6">There are some regulations in shipping to India.</p>
<h2 class="title">Regulations</h2>

<p id="si-7">Indian residents or foreign nationals, anybody can ship their used goods or some
    personal items to India. Customer can ship professional equipments to India to provide the
    Indian customs officials with evidence and/or certificates that prove their qualifications in
    the profession. Customers are allowed to ship limited amounts of electronic equipments to India.
    When shipping to India customers are expected to pay duties or import taxes on a variety of
    goods. There are some things that are not allowed to ship to India as listed.</p>

<div class="section group" style="background-color: #F4F4F4;">
    <div class="col span_6_of_12">
        <ul style="list-style: square; line-height: 2; padding-left: 50px;">
            <li>Narcotics</li>
            <li>Weapons, firearms and ammunition</li>
        </ul>
    </div>
    <div class="col span_6_of_12">
        <ul style="line-height: 2; list-style: square;">
            <li>Walkie&#45;Talkies</li>
            <li>Politically sensitive literature</li>
        </ul>
    </div>
</div>
<br>

<div id='cssmenu'>
<ul>
<li class='has-sub' style="border: 1px solid #cccccc;">
    <a href='#'>
        <div class="faq" style="background-color: #f4f4f4">

            <h2 class="title"
                style="margin: 0px; display: inline; margin-right: 18px; font-size: 10pt;">
                Consulate</h2>
        </div>
    </a>

    <ul style="list-style: square; line-height: 2; ">
        <li><a href="http://www.indianconsulate-sf.org/custom/b_duty.html" class="resource-link" target="_blank"
               style="padding-top: 20px;">Indian
                Consulate </a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.cbec.gov.in/" class="resource-link" target="_blank">Official Website of the Indian
                Custom</a>
        </li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <!--<li><a href="http://www.geocities.com/indiancustoms/baggagerule/tr.htm" target="_blank" class="resource-link">Transfer
                of Residence Rules</a></li><hr style="border-bottom: 1px solid #eeeeee;">-->
        <li><a href="http://www.indianconsulate-sf.org/" target="_blank" class="resource-link" style="display: inline">Indian
                Consulate
                &#45;SFO</a> (San Francisco)
        </li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <!--<li><a href="http://chicago.indianconsulate.com/" target="_blank">Indian Consulate &#45;
                Chicago</a></li>-->
        <li><a href="http://www.indiacgny.org/" class="resource-link" target="_blank">Indian Consulate &#45; New
                York</a>
        </li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.cgihouston.org" class="resource-link" target="_blank">Consulate General of India &#45;
                Houston</a>
        </li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.indianEmbassy.org" target="_blank" class="resource-link">Embassy of India &#45;
                Washington
                DC</a>
        </li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.cgihouston.org" target="_blank" class="resource-link">Huston</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.nic.in" class="resource-link" target="_blank">National Information Centre</a></li>
        <!--<li><a href="http://www.ciionline.org" target="_blank">Confederation of Indian Industry</a></li>
         <li><a href="http://www.cbec.gov.in/customs/cs-act/formatted-htmls/cs-rulef.htm"
                target="_blank">Baggage Rules 1</a> &#45; (Import of Household Goods &amp; Personal
             belongings)
         </li>
         <li><a href="LatestBaggageRules.htm" target="_blank">Baggage Rules 2</a></li>
        <li><a href="http://www.cbec.gov.in/" target="_blank">Customs Rules</a></li>
        <li>
            <a href="http://www.cargotrackers.com/cargotrackers/pages/customs_act/custom_law.asp?fid=CTAct"
               target="_blank">The Customs ACT 1962</a></li>-->
    </ul>

</li>
<li class='has-sub' style="border: 1px solid #cccccc;"><a href='#'>
        <div class="faq" style="background-color: #f4f4f4">
            <h2 class="title"
                style="margin: 0px; display: inline; margin-right: 18px; font-size: 10pt;">
                Customs</h2>
        </div>
    </a>
    <ul style="padding-top: 15px;">
        <!--<li>
            <a href="http://www.cargotrackers.com/cargotrackers/pages/customs_act/custom_law.asp?fid=CTForms"
               target="_blank">Customs Forms &amp; Bonds</a></li>
        <li><a href="http://www.cbec.gov.in/cae/customs/cs-tariff/cst-note.htm" target="_blank">Tariff
                to Calculate Customs Duty</a></li>
        <li><a href="http://www.cbec.gov.in/cae/customs/forms_pdf/forms_idx_final.htm" target="_blank">Customs
                Forms</a></li>-->
        <!--<li><a href="http://www.geocities.com/indiancustoms/" class="resource-link" target="_blank">Indian Customs Info
                (Non Government)</a></li><hr style="border-bottom: 1px solid #eeeeee;">-->
        <!--<li><a href="http://www.cbec.gov.in/cae/customs/cs-business/imp-samples.htm" target="_blank">Import
                of Samples in India</a></li>
        <li><a href="http://www.texprocil.com/texprocil/quota/index.htm" target="_blank">Textile
                promotion Council (for Garments, Textile Quota)</a></li>
        <li><a href="http://passport.nic.in/" target="_blank">Passport &amp; Visa Division of Ministry of
                External Affairs</a></li>-->
        <!--<li><a href="http://www.geocities.com/icddelhi/" class="resource-link" target="_blank">ICD Delhi &#45; Inland
                Container Depot</a></li><hr style="border-bottom: 1px solid #eeeeee;">-->
        <li><a href="http://www.fieo.com" target="_blank" class="resource-link">Federation of Indian Export
                Organisations</a>
        </li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.mapsofindia.com" target="_blank" class="resource-link">Maps of India</a></li>
        <li><a href="import-export-code-number.php" class="resource-link">Import Export Code Number</a></li>
    </ul>
</li>
<li class='has-sub' style="border: 1px solid #cccccc;"><a href='#'>
        <div class="faq" style="background-color: #f4f4f4">
            <h2 class="title"
                style="margin: 0px; display: inline; margin-right: 18px; font-size: 10pt;">
                Directories</h2>
        </div>
    </a>
    <ul style="padding-top: 15px;">
        <!--<li><a href="http://www.concorindia.com/data/query.htm" target="_blank">Container Corp of
                India</a></li>
        <li><a href="http://www.meadev.nic.in/" target="_blank">Ministry of External Affairs</a></li>-->
        <li><a href="http://goidirectory.nic.in/" class="resource-link" target="_blank">Directory of Official Websites
                of
                Government of India</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://dgft.delhi.nic.in/" class="resource-link" target="_blank">Directorate General of Foreign
                Trade</a>
        </li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <!--<li><a href="http://www.indianembassy.org/links/indialinks.htm" target="_blank">All Ministries
                Departments</a></li>
        <li><a href="http://www.isn.org/" target="_blank">Immigrants Support Network</a></li>
        <li><a href="http://usembassy.state.gov/delhi.html/wwwhareg.html" target="_blank">Online
                Registration for USA Citizens</a></li>
        <li><a href="http://travel.state.gov/visa_services.html" target="_blank">Visas for Foreign
                Citizens to come to the USA</a></li>
        <li><a href="http://usembassy.state.gov/posts/in1/wwwhmain.html" target="_blank">The U.S.
                Embassy in New Delhi</a></li>
        <li><a href="http://usembassy.state.gov/mumbai/" target="_blank">The U.S.Consulate General in
                Mumbai</a></li>
        <li><a href="http://usembassy.state.gov/chennai/" target="_blank">The U.S.Consulate General in
                Chennai</a></li>
        <li><a href="http://usembassy.state.gov/calcutta/" target="_blank">The U.S.Consulate General in
                Calcutta</a></li>
        <li><a href="http://www.jnport.com" target="_blank">Bombay Jawaharlal Nehru Port</a></li>-->
        <li><a href="http://www.indianconsulate-sf.org/businesses/ecbulletin/ec_index.html"
               target="_blank" class="resource-link">The Weekly Economic News/Bulletin</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.eanindia.com/" class="resource-link" target="_blank">EAN India</a></li>
        <!--<li><a href="http://www.meadev.nic.in/info/misc/addresseshome.htm" target="_blank">Indian
                Missions & Post</a></li>
        <li><a href="http://www.mumbaiporttrust.com/index1.htm" target="_blank">Mumbai Port Trust</a>
        </li>-->
    </ul>
</li>
<li class='has-sub' style="border: 1px solid #cccccc;"><a href='#'>
        <div class="faq" style="background-color: #f4f4f4">
            <h2 class="title"
                style="margin: 0px; display: inline; margin-right: 18px; font-size: 10pt;">
                Trade &amp; Finance</h2>
        </div>
    </a>
    <ul style="padding-top: 15px;">
        <li><a href="http://www.portofcalcutta.com/" class="resource-link" target="_blank">Kolkata Port Trust</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <!--<li><a href="http://www.chennaiporttrust.com/" class="resource-link" target="_blank">Chennai Port Trust</a></li><hr style="border-bottom: 1px solid #eeeeee;">-->
        <!--<li><a href="http://www.jnport.com/" target="_blank">Jawaharlal Nehru Port Trust</a></li>-->
        <li><a href="http://www.cochinport.com/" class="resource-link" target="_blank">Cochin Port Trust</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <!--<li><a href="http://www.kandlaport.com/default1.asp" target="_blank">Kandla Port Trust</a></li>-->
        <li><a href="http://www.cbec.gov.in/htdocs-cbec/central-excise" class="resource-link" target="_blank">Central Board of Excise and
                Customs</a>
        </li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.jawaharcustoms.gov.in/" class="resource-link" target="_blank">Jawahar Customs</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <!--<li><a href="http://www.mumbaicustoms.gov.in/" target="_blank">Mumbai Customs</a></li>
        <li><a href="http://www.kar.nic.in/blrcustoms/" target="_blank">Bangalore Customs</a></li>
        <li><a href="import_export_code_number.htm" target="_blank">Import Export Code Number
                Requirement</a></li>-->
        <li><a href="http://dgft.delhi.nic.in/" class="resource-link" target="_blank">Commerce and Industry, Directorate
                General of
                Foreign Trade</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://finmin.nic.in/" class="resource-link" target="_blank">Finance &amp; Company Affairs</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.cbec.gov.in/" class="resource-link" target="_blank">Finance, Department of Revenue</a>
        </li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://indiabudget.nic.in/" class="resource-link" target="_blank">Finance (Budget)</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <!--<li><a href="http://www.nic.in/most/ewelco.html" target="_blank">Shipping, Road Transport</a>
        </li>-->
        <li><a href="https://www.rbi.org.in/" class="resource-link" target="_blank">Reserve Bank of India (RBI)</a></li>
    </ul>
</li>
<li class='has-sub' style="border: 1px solid #cccccc;"><a href='#'>
        <div class="faq" style="background-color: #f4f4f4">
            <h2 class="title"
                style="margin: 0px; display: inline; margin-right: 18px; font-size: 10pt;">
                Regulations</h2>
        </div>
    </a>
    <ul style="padding-top: 15px;">
        <li><a href="http://www.cbec.gov.in/htdocs-cbec/central-excise" class="resource-link" target="_blank">Central Board of
                Excise and Customs &#45; Local Office</a></li>
        <hr class="style-dash">
        <li><a href="http://cbn.nic.in/" class="resource-link" target="_blank">Central Bureau of Narcotics</a></li>
        <li><a href="http://cbi.nic.in/" class="resource-link" target="_blank">Central Bureau of Investigation</a></li>
        <li><a href="http://cvc.nic.in/" class="resource-link" target="_blank">Central Vigilance Commission</a></li>
        <li><a href="http://supremecourtofindia.nic.in/" class="resource-link" target="_blank">Supreme Court of
                India</a></li>
        <!--<li><a href="http://www.nic.in/ceib/frameset.htm" target="_blank">Indian Agencies Fighting
                Economic Crime</a></li>
        <li><a href="http://www.cbec.gov.in/cae/excise/cx-tariff/cx-note.htm" target="_blank">Determination of
                Duties of excise chargeable on goods manufactured in India</a> Establishing an Indian Venture
        </li>-->
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.indianconsulate-sf.org/iebo/jvc.htm" class="resource-link" target="_blank">Incorporating
                a Company in
                India</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.indianconsulate-sf.org/iebo/impproil.htm" class="resource-link" target="_blank">Industrial
                Licence</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.indianconsulate-sf.org/iebo/impprorf.htm" class="resource-link" target="_blank">Raising
                Finances in India</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.indianconsulate-sf.org/iebo/impproso.htm" class="resource-link" target="_blank">Starting
                Operations</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.indianconsulate-sf.org/iebo/impprois.htm" class="resource-link" target="_blank">Investment
                support</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.indianconsulate-sf.org/iebo/impprofo.htm" class="resource-link" target="_blank">Hiring
                of Foreign
                Nationals</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.indianconsulate-sf.org/iebo/forinve.htm" class="resource-link" target="_blank">Foreign
                Investment</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.indianconsulate-sf.org/iebo/export.htm" class="resource-link" target="_blank">Exporting
                from
                India</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.goidirectory.nic.in/" target="_blank" class="resource-link">Government of India,
                Directory of Official Web Sites</a></li>
        <!--<li>
            <a href="http://www.sgs.com/gtsnet.nsf/dab395eb21efae84c125666400373465/8d5e8e862b76c44765256a5e00380027!OpenDocument"
               target="_blank">Preshipment Inspection of Imports for India</a></li>-->
    </ul>
</li>
<li class='has-sub' style="border: 1px solid #cccccc;"><a href='#'>
        <div class="faq" style="background-color: #f4f4f4">
            <h2 class="title"
                style="margin: 0px; display: inline; margin-right: 18px; font-size: 10pt;">
                Other useful links related to India</h2>
        </div>
    </a>
    <ul style="list-style: square; line-height: 0;">
        <li style="padding-top: 10px;"><a href="http://www.WhatisIndia.com" class="resource-link" target="_blank">The
                Indian Analyst</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.tourismofindia.com/" class="resource-link" target="_blank">Tourism of India</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.taxindiaonline.com/" class="resource-link" target="_blank">TaxIndia Online</a></li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <li><a href="http://www.indiantaxsolutions.com/" class="resource-link" target="_blank">Indian Tax Solutions</a>
        </li>
        <hr style="border-bottom: 1px solid #eeeeee;">
        <!--<li><a href="http://www.licenceindia.com/" class="resource-link" target="_blank">India&#39;s portal for all Exim
                Licenses</a>-->
</li>
<hr style="border-bottom: 1px solid #eeeeee;">
<li><a href="http://www.indiaserver.com/" class="resource-link" target="_blank">All you want to know about India
        on
        Indiaserver</a></li>
<hr style="border-bottom: 1px solid #eeeeee;">
<!--<li><a href="http://www.ftrade4u.com/" target="_blank">Foreign trade &#45; India. International
        marketing and logistics</a>
</li>-->
<li><a href="http://dgft.delhi.nic.in/" class="resource-link" target="_blank">Directorate General of Foreign
        Trade</a>
</li>
<hr style="border-bottom: 1px solid #eeeeee;">
<li><a href="http://www.nriol.com/" class="resource-link" target="_blank">Non Resident Indians Online</a></li>
<hr style="border-bottom: 1px solid #eeeeee;">
<li><a href="http://www.IndiaPost.org" class="resource-link" target="_blank">Postal Codes in India</a></li>
<hr style="border-bottom: 1px solid #eeeeee;">
<!--<li><a href="http://www.cbec.gov.in/travellers.htm" target="_blank">Incoming Passengers/Travellers
        Rules</a></li>-->
<li><a href="http://www.servicetax.gov.in/htdocs-servicetax/service-tax" class="resource-link" target="_blank">Forms &#45;
        Customs, Central Excise
        &amp; Service Tax</a></li>
<hr style="border-bottom: 1px solid #eeeeee;">
<li><a href="http://www.cbec.gov.in/htdocs-cbec/othersites" target="_blank" class="resource-link">List of other related
        web
        sites</a></li>
<!--<li><a href="Forms/Form_9.doc" target="_blank">Form 9 Transboundary Movement Document for Scrap/Recycle
        products imports</a></li>-->
</ul>
</li>
</ul>
</div>

</div>
<div class="col span_3_of_12">
<!--<a href="ship-to-india-at-99.php" class="resource-link" style="font-size: 10pt; font-weight: 700;">Ship to India - $99/Box</a><br>-->
                                <a href="lcl-export-schedule.php" style="font-weight: 700;" class="resource-link">LCL Export Freight Schedule</a><br>
    <a href="lcl-cargo.php" class="resource-link" style="font-size: 10pt; font-weight: 700;">LCL Cargo</a><br><br>
    

<link href="source/css/controls.css" rel="stylesheet" type="text/css" visible="true"/>
<style>
    table.estimate tr > td {
        padding: 2px 0px;
    }

    .txtborder {
        border: 1px solid #cccccc;
    }
</style>

<script>
    function f_t_Countries(value) {
        var f_country = document.getElementById('from_country').value;
        var t_country = document.getElementById('to_country').value;
        if (value == 'to_country') {
            if (t_country != 'US') {

            }
        } else if (value == 'from_country') {

        }
    }
</script>

<!--  DATE CALANDER  -->
<link rel="stylesheet" type="text/css" href="source/css/jquery.datetimepicker.css"/>
<script src="source/js/jquery-1.11.1.js"></script>


<script>
    $(function () {
        $("#txt_moving_date").datepicker();
    });
</script>

<div style="width: 225px; height: auto; background-color: #fafafa; margin-bottom: 20px;" align="center">
    <form method="post" action="sidebar-free-estimate-action.php">
        <div
            style="width: 223px;background-color: #056598; border: 1px solid #056598; padding: 5px 0px; font-family: arial; font-size: 10pt; color: #ffffff; font-weight: bold;">
            Get FREE Quotation
        </div>
        <table class="estimate" style="width: 100%; font-family: arial; font-size: 10pt;  border: 1px solid #cccccc;"
               cellspacing="0" cellpadding="0" border="0">
            <tr>
                <td style="padding-left: 10px; padding-top: 10px; font-size: 9pt; color: #666666; padding-bottom: 0px;">

                </td>
            </tr>
            <tr style="height: 33px;">
                <td align="center">
                    <select type="text" id="mode_transport" name="mode_transport" style="width: 90%; margin-top: 0px; "
                            class="form-textbox">
                        <option>Select Mode of Transport</option>
                        <option>By Air</option>
                        <option>By Sea</option>
                        <option>By Land</option>
                        <option>Not Sure</option>
                    </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">Select Commodity</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="center">
                    <select type="text" id="commodity" name="commodity" style="width: 90%; margin-top: 0px;"
                            class="form-textbox">
                        <option value="Select Commodity" selected="selected">Select Commodity</option><option value="Automobile/s">Automobile/s</option><option value="Boat">Boat</option><option value="Charity Goods">Charity Goods</option><option value="Computer/Electronics">Computer/Electronics</option><option value="General Cargo">General Cargo</option><option value="Hazardous Cargo">Hazardous Cargo</option><option value="Machinery">Machinery</option><option value="Metal Scrap">Metal Scrap</option><option value="Motorcycle/s">Motorcycle/s</option><option value="Perishable Cargo">Perishable Cargo</option><option value="Residential">Residential</option><option value="Residential with Vehicle (Auto, Motorcycle etc)">Residential with Vehicle (Auto, Motorcycle etc)</option><option value="Vehicle/s">Vehicle/s</option><option value="Waste Paper">Waste Paper</option><option value="Used Clothing">Used Clothing</option>                    </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">From Country</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="center">
                    <select type="text" style="width: 90%; margin-top: 0px;" class="form-textbox" id="from_country"
                            name="from_country">
                        <OPTION Value="0">Select From</OPTION>
                        <option value="US">US</option><option value="India">India</option>                    </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">To Country</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="center"><select type="text" style="width: 90%; margin-top: 0px;" class="form-textbox"
                                           id="to_country" name="to_country">
                        <OPTION Value="0">Select To</OPTION>
                        <option value="US">US</option><option value="India">India</option>                    </select></td>
            </tr>
            <!--<tr>
                <td style="padding-left: 10px; padding-top: 5px; font-size: 9pt; color: #666666;">Moving Date</td>
            </tr>-->
            <tr style="height: 33px;">
                <td align="left">
                    <input type="text" id="txt_moving_date" name="txt_moving_date" class="form-textbox"
                           style="width: 77%; margin-left: 12px;" placeholder="Expected date to ship">
                    <img src="source/images/calendar.PNG" style="position: absolute; padding-top: 3px;">
                </td>
            </tr>
            <tr style="height: 33px;">
                <td align="right" style="padding: 5px 13px 10px 10px;">
                    <input type="submit" id="submit_quote" name="submit_quote" class="naviBlue"
                           value="SUBMIT" style="height: 25px; padding-top: 3px"></td>
            </tr>
        </table>
        <script src="source/js/jquery.datetimepicker.js"></script>
        <script>
            $('#txt_moving_date').datetimepicker({
                lang: 'en',
                timepicker: false,
                closeOnDateSelect: true,
                format: 'm/d/Y',
                formatDate: 'Y/m/d',
                minDate: '2017/01/01', // yesterday is minimum date
                //startDate: '2015/01/01',
                autodateonstart: true,
                maxDate: '2030/12/31' // and tommorow is maximum date calendar
            });
        </script>
    </form>
</div>


<a href="cargo-tracking.php"><img src="source/images/cargo-tracking.png" style="margin-bottom: 20px;"></a>
<a href="about-air7seas.php"><img src="source/images/exp.png" style="margin-bottom: 20px;"></a>
<a href="customer-review.php"><img src="source/images/tp-logo-customer-review.PNG" style="margin-bottom: 20px;"></a>
</div>
</div>
</div>
</div>
</div>
<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" lang="en">


<head>
    <!--Start of Zopim Live Chat Script
    <script type="text/javascript">
        window.$zopim || (function (d, s) {
            var z = $zopim = function (c) {
                z._.push(c)
            }, $ = z.s =
                d.createElement(s), e = d.getElementsByTagName(s)[0];
            z.set = function (o) {
                z.set.
                    _.push(o)
            };
            z._ = [];
            z.set._ = [];
            $.async = !0;
            $.setAttribute('charset', 'utf-8');
            $.src = '//v2.zopim.com/?2NBKvMLseKA8C45Gr5ywmelLErtAkht6';
            z.t = +new Date;
            $.
                type = 'text/javascript';
            e.parentNode.insertBefore($, e)
        })(document, 'script');
    </script>
    End of Zopim Live Chat Script-->
    
    <!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = '3kWxTfUv3x';var d=document;var w=window;function l(){
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
<!-- {/literal} END JIVOSITE CODE -->

    <link href="source/css/sole.css" rel="stylesheet">

<body class="vpform pgTrustPilot" lang="en-GB" align="center">


<div id="footerinfo" style="width: 100%; background-color: #cccccc" align="center">
    <div style="width: 980px; background-color: #ffffff; padding: 10px 0px;" align="left">
        <div id="BreadcrumbWrapper">
            <div class="section group">
                <div class="col span_12_of_12" style="line-height: 23px; border-right: 1px solid #dddddd; ">
                </div>
            </div>
            <hr>
        </div>
        <img src="source/images/logos.jpg" alt="" style="width: 980px;">
        <div style="margin-left:40px;">
            <a id="bbblink" class="ruvtbum" target="_blank" href="https://www.bbb.org/us/ca/milpitas/profile/logistics/air-7-seas-transport-logistics-1216-213698#bbbseal"
        title="AIR 7 SEAS Transport Logistics Inc, Logistics, Milpitas, CA"
        style="display: block;position: relative;overflow: hidden; width: 60px; height: 108px; margin: 0">
        <img style="padding: 0px; border: none;" id="bbblinkimg" src="https://seal-sanjose.bbb.org/logo/ruvtbum/air-7-seas-transport-logistics-213698.png" width="120" height="108" alt="AIR 7 SEAS Transport Logistics Inc, Logistics, Milpitas, CA" />
        </a>    
        </div>
        
        <script type="text/javascript">var bbbprotocol = ( ("https:" == document.location.protocol) ? "https://" : "http://" ); (function(){var s=document.createElement('script');s.src=bbbprotocol + 'seal-sanjose.bbb.org' + unescape('%2Flogo%2Fair-7-seas-transport-logistics-213698.js');s.type='text/javascript';s.async=true;var st=document.getElementsByTagName('script');st=st[st.length-1];var pt=st.parentNode;pt.insertBefore(s,pt.nextSibling);})();
        </script>
    </div>
</div>
<!--footer-->
<footer style="background-color: #4d4d4d">
    <div class="DB MMdLFtR">
        <div class="FL DB MMdLFtRa" style="padding-left: 75px;">

            <div id="FtR" class="LH20 footer-links">
                <div class="left-section FL">
                    <div class="left-wrapper FL">
                        <section class="ordering-fromus">
                            <div class="title">
                                AIR 7 SEAS
                            </div>
                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="about-air7seas.php" id="aContact">About Us</a>
                                    <a href="feedback.php" id="aFAQ">Feedback</a>
                                    <a href="shipping-news.php" id="aOrdertracking">News &amp;
                                        Events</a>
                                    <a href="#">Privacy Policy</a>
                                    <a href="terms-and-conditions.php">Terms &amp;
                                        Conditions</a>
                                    <a href="jobs.php">Jobs</a>
                                </li>
                            </ul>
                        </section>
                        <section class="help-support">
                            <div class="title">
                                SERVICES
                            </div>

                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="international-freight.php">International &#45;
                                        Freight</a>
                                    <a href="domestic-freight.php">Domestic &#45;
                                        Freight</a>
                                    <a href="autos-vehicles-machinery.php">Machinery &amp; Vehicles</a>
                                    <a href="freight-forwarder.php">Freight Forwarding</a>
                                    <a href="customs-release.php">Customs Release</a>
                                    <a href="moving.php">Movers</a>
                                </li>
                            </ul>
                        </section>
                        <section class="information">
                            <div class="title">
                                SUPPORT
                            </div>
                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="faq.php">Frequently Asked Questions</a>
                                    <a href="moving-tips.php">Moving Tips</a>

                                    <a href="payments.php" id="aFreeRecycle">Payment Options</a>
                                    <a href="procedural-steps-for-claim-submition.php">Claim
                                        Submission Procedures</a>
                                    <a href="isf.php">Importer Security Filing (ISF)</a>
                                    <a href="order-online-insurance.php">Order Online -
                                        Insurance</a>

                                </li>
                            </ul>
                        </section>
                    </div>
                    <div class="social-links">


                    </div>
                </div>
                <section class="newsletter">
                    <div class="title">CORPORATE OFFICE</div>
                    <div class="footer-contact">
                        <ul>
                            <li class="f-map"><a
                                    href="contact-us.php"
                                    target="_blank">1815 Houret Court, <br> Milpitas, CA 95035, US</a></li>
                            <li class="f-phone"><span><a href="tel:+18882477732">Call Us: 1-888-247-7732</a></span></li>
                            <li class="f-mail"><a href="mailto:info@air7seas.us">info (@) air7seas.us</a></li>
                        </ul>
                    </div>
                    <br><br>

                    <div>
                        <a href="https://www.facebook.com/pages/Air7Seas-Transport-Logistics-Inc/731149066945233" target="_blank">
                            <img src="source/images/icons/fb.png" style="margin-top: 7px; width: 25px;">
                        </a>&nbsp;
                        <a href="https://twitter.com/Air7seas" target="_blank">
                            <img src="source/images/icons/twitter.png" style="margin-top: 7px; width: 25px;">
                        </a>&nbsp;
                        <a href="https://www.google.com/maps/place/AIR+7+SEAS+Transport+Logistics+Inc/@37.405497,-121.8994427,17z/data=!3m1!4b1!4m5!3m4!1s0x808fceb215c020c3:0x183384c4fb534d3c!8m2!3d37.405497!4d-121.897254" target="_blank">
                            <img src="source/images/icons/gp.png" style="margin-top: 7px; width: 25px;">
                        </a>
                    </div>

                </section>
            </div>
        </div>
    </div>

</footer>

<div class="baseline-footer">
    <div class="baseline-footer-wrapper">
        <section class="FL" itemprop="provider" itemscope itemtype="http://schema.org/Organization">
            <div class="FL">

                <meta itemprop="url" content="http://www.air7seas.com/"/>
                <meta itemprop="name" content="Air 7 Seas Transport Logistics Pvt Ltd"/>
                <meta itemprop="email" content="info@air7seas.com "/>
                <div itemprop="location" itemscope itemtype="http://www.schema.org/LocalBusiness">

                    <meta itemprop="openingHours" content="Mo-Fr 08:00-16:00"/>
                    <meta itemprop="openingHours" content="Sa-Su Holiday"/>
                    <div itemprop="geo" itemscope itemtype="http://schema.org/GeoCoordinates">
                        <meta itemprop="latitude" content="53.55519"/>
                        <meta itemprop="longitude" content="-3.041651"/>
                    </div>
                </div>

            </div>
            <div class="contact-information">
                <div id="pnlUKFooter">

                    <div class="address" itemprop=address itemscope itemtype=http://schema.org/PostalAddress>
                        <span class="address-image"></span>

                        <div class="address-wrapper">
                            <span itemprop=streetAddress><a href="contact-us.php" style="color: #cfcfcf;">1815 Houret
                                    Court,<br> Milpitas, CA 95035</a></span>,
                            <span itemprop=addressLocality>USA</span>
                        </div>
                    </div>
                    <div class="phone-number">
                        <span class="phone-image"></span>
                        <span class="telephone" itemprop=telephone><a href="tel:+18882477732" style="color: #cfcfcf;">1-888-247-7732</a></span>
                        <span class="sales-support">(Customer Support)</span>
                    </div>
                    <div class="email-address">
                        <span class="email-img"></span>
                        <span itemprop=email><a class="mail-id"
                                                href="mailto:info@air7seas.us">info (@) air7seas.us</a></span>
                    </div>


                </div>

            </div>
        </section>


        <div itemprop="copyrightHolder" itemscope itemtype="http://www.schema.org/Organization"
             class="copywrite-holder">
            <meta itemprop="url" content="http://www.air7seas.com/"/>
            <meta itemprop="name" content="Air 7 Seas Transport Logistics Pvt Ltd"/>

            <meta itemprop="email" content="info@air7seas.com "/>

            Copyright <span class="copyrights">&copy;</span> AIR 7 SEAS 2014 &#45; 2015
        </div>
        <meta itemprop="copyrightYear" content="1986-2014"/>

        <div class="divAuthorisedText">Authorised and regulated by AIR 7 SEAS 95035</div>


    </div>
</div>

</body>
</html>

</body>
</html>
