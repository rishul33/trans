


    <!DOCTYPE html>
    <html>

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
        <title> USA De-consolidation, Devanning &amp; OCC Charges - AIR 7 SEAS</title>
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800'
            rel='stylesheet' type='text/css'>
        <link rel="shortcut icon" href="source/images/a7s-icon.ico" />

        <meta name="description" content="Air 7 seas is leading Freight Forwarder, NVOCC, OTI, Cargo Consolidator, Custom Broker, Carrier, and Shipping Agents for Ship Lines, Airlines, Truckers, Shipper & Consignee to handle International and Domestic transportation by Air Freight, Sea Freight or Road Freight.">
        <meta name="keywords" content="consolidation, cargo consolidation, De-consolidation, cargo De-consolidation, USA De-consolidation, On Carriage Charges, Freight Rates, Net costs, LCL consolidation to, LCL shipping to, LCL service to, LCL to, LCL cargo to, freight consolidation to, shipping lcl to, Consolidation to, LCL freight to">
        <meta name="author" content="Air 7 Seas Transport Logistics Pvt Ltd">

        <!--  <base href="http://www.air7seas.com/"> -->

        <link href="source/css/responsive.css" rel="stylesheet">
        <link href="source/css/sole.css" rel="stylesheet" type="text/css" visible="true" />
        <link href="source/css/skin.css" rel="stylesheet" type="text/css">

        <style>
            /*      DEVANNING CHARGES at LAX        */

            table.devann-lax {
                background-color: #ffffff;
                border-top: 2px solid #016491;
                border-bottom: 1px solid #016491;
                border-right: 1px solid #016491;
                border-left: 1px solid #016491;
            }

            table.devann-lax tr {
                height: 30px;
                vertical-align: middle;
            }

            table.devann-lax tr td {
                border-bottom: 1px solid #d4d3d3;
                padding-left: 5px;
            }

            table.devann-lax tr:first-child td {
                font-weight: 700;
                border-bottom: 1px solid #016491;
                color: #404040;
                padding-left: 50px;
            }

            table.devann-lax tr:nth-child(2) td {
                font-weight: 700;
                border-bottom: 1px solid #016491;
                color: #404040;
            }

            table.devann-lax tr:first-child td {
                border-bottom: 1px solid #016491;
            }

            table.devann-lax tr td:first-child {
                border-right: 2px solid #d4d3d3;
            }

            table.devann-lax tr td:nth-child(5) {
                border-right: 2px solid #d4d3d3;
            }

            /*       DEVAINNING CHARGES at IPI CODE, CITY TABLE FORMAT    */

            table.ipi-code-lax-nyc {
                background-color: #ffffff;
                border-top: 2px solid #016491;
                border-bottom: 1px solid #016491;
                border-right: 1px solid #016491;
                border-left: 1px solid #016491;
            }

            table.ipi-code-lax-nyc tr {
                height: 30px;
                vertical-align: middle;
            }

            table.ipi-code-lax-nyc tr td {
                border-bottom: 1px solid #d4d3d3;
                padding-left: 5px;
            }

            table.ipi-code-lax-nyc tr:first-child td {
                font-weight: 700;
                border-bottom: 1px solid #016491;
                color: #404040;
            }

            table.ipi-code-lax-nyc tr:last-child td {
                border-bottom: 1px solid #016491;
            }

            table.ipi-code-lax-nyc tr td:nth-child(3) {
                border-right: 2px solid #d4d3d3;
            }

            /*table.ipi-code-lax-nyc tr td:nth-child(4) {
            border-right: 1px solid #d4d3d3;
        }*/

            table.ipi-code-lax-nyc tr td:nth-child(5) {
                border-right: 2px solid #d4d3d3;
            }

            /*table.ipi-code-lax-nyc tr td:nth-child(6) {
            border-right: 1px solid #d4d3d3;
        }*/

            table.ipi-code-lax-nyc tr td:nth-child(7) {
                border-right: 2px solid #d4d3d3;
            }

            /*        IT ENTRY PREPARATION / CANCELLATION FEE         */

            table.it-entry {
                background-color: #ffffff;
                border-top: 2px solid #016491;
                border-bottom: 1px solid #016491;
                border-right: 1px solid #016491;
                border-left: 1px solid #016491;
            }

            table.it-entry tr {
                height: 30px;

            }

            table.it-entry tr td {
                border-bottom: 1px solid #d4d3d3;
                padding-left: 5px;
            }

            table.it-entry tr:first-child td {
                font-weight: 700;
                border-bottom: 1px solid #016491;
                color: #404040;
            }

            table.it-entry tr:first-child td {
                border-bottom: 1px solid #016491;
            }

            /*.table_borders {
            border-bottom: 1px solid #d4d3d3;
        }

        .table_borders-footer {
            border-bottom: 1px solid #016491;
        }*/
        </style>

        <script>
            /*(function (i, s, o, g, r, a, m) {
                        i['GoogleAnalyticsObject'] = r;
                        i[r] = i[r] || function () {
                            (i[r].q = i[r].q || []).push(arguments)
                        }, i[r].l = 1 * new Date();
                        a = s.createElement(o),
                            m = s.getElementsByTagName(o)[0];
                        a.async = 1;
                        a.src = g;
                        m.parentNode.insertBefore(a, m)
                    })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

                    ga('create', 'UA-54008281-2', 'auto');
                    ga('send', 'pageview');*/
        </script>

    </head>

    <body>
        <!DOCTYPE html>
<html>
<head>
    <title></title>
    <link href="source/css/sole.css" rel="stylesheet" type="text/css" visible="true"/>
    <link href="source/css/skin.css" rel="stylesheet" type="text/css" visible="true"/>

    <link
        href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800'
        rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="source/css/megadrop.css"/>
    <script type="text/javascript" src="source/js/megascripts.js"></script>
    <style>
        .searchbox {
            height: 28px;
            width: 225px;
            border: 1px solid #dadada;
            border-top-left-radius: 3px;
            border-bottom-left-radius: 3px;
            padding-left: 10px;
            font-size: 12px;
            color: #9b9b9b
        }

        .searchbutton {
            cursor: pointer;
            background-image: url('source/images/search.GIF');
            height: 30px;
            width: 70px;
            margin-top: 0;
            color: transparent
        }

        .txtSearchbox::-webkit-input-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox:-moz-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox::-moz-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }

        .txtSearchbox:-ms-input-placeholder {
            color: #9f9fa1;
            font-size: 12px;
            font-style: italic
        }
    </style>
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NQDLZPP');</script>
<!-- End Google Tag Manager -->
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NQDLZPP"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div id="topLine">
</div>
<div id="main-header" align="center" style="font-family: Arial;">
    <div id="main-header-area" align="left">
        <a href="index.php">
            <img src="source/images/logo-new.png" alt="Air 7 Seas" style="float: left; position: relative;"></a>

        <div class="top-small-link" style=" vertical-align: middle">
            <table border="0">
                <tr style="vertical-align: top">
                    <td style="padding-top: 3px;">
                        <a href="cargo-tracking.php" style="color: #404040; font-family: Arial;"><b>Cargo
                                Tracking</b></a>|
                        <a href="about-air7seas.php">About Us</a>|
                        <a href="https://portal.cargoez.com/air7seas/login" target="_blank">Login</a>|
                        <a href="shipping-news.php">News &amp; Events</a>

                    </td>
                    <td style="vertical-align: top;"><img src="source/images/phone-ico.PNG" alt=""
                                                          style="margin-top: 0px;">
                    </td>
                    <td style="padding: 3px 0 0 5px; width: 185px;">
                        <span style="font-size: 13pt; float: right"><span style="font-size: 9pt;">Toll Free:</span>
                        <a href="tel:+18882477732"
                           style="padding-left: 0px; padding-right: 0px; margin-right: 0px; color: #026799;"><b>1-888-247-7732<b/></a></span>
                    </td>

                </tr>
                <tr>
                    <td colspan="3" style="">
                        <div id="SrCl" style="padding-top: 8px; float: right">
                            <form method="post" action="search-results.php">

                                <input type="text" id="find" name="find" autocomplete="off"
                                       class="searchbox txtSearchbox" placeholder="How can i help you...?">
                                <input type="submit" name="" style="border:0px; height: 28px;" class="searchbutton"
                                       alt="Search"/>

                            </form>
                        </div>
                    </td>
                </tr>
            </table>


        </div>


    </div>
</div>
<div id="menu-bar" style="width: 100%; background-color: #1e6a89;" align="center">
<div style="width: 980px;" align="left">
<ul class="nav-mainmenu clearfix animated">
<li><a href="index.php">Home</a></li>
<li>
    <a href="#">Services</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px; ">

            <ul class="menu-items">
                <li class="seperator"><a href="international-freight.php" style="font-weight: 600">International
                        Freight</a></li>
                <li class="seperator"><a href="domestic-freight.php">Domestic Freight</a></li>
                <li class="seperator"><a href="freight-forwarder.php">Freight Forwarding</a></li>
                <li class="seperator"><a href="freight-consultation.php">Consultation</a></li>

            </ul>
        </div>
    </div>
</li>
<li><a href="#">Products</a>

    <div class="container-2" style="width: 500px;">
        <table border="0">
            <tr>
                <td style="border-right:1px solid #ccc; vertical-align: top;">
                    <div class="col1" style="width: 250px;">

                        <ul class="menu-items">


                            <li class="seperator"><a href="shipping-to-vietnam.php"><img
                                        src="source/images/Vietnam-Flag-icon.png" alt="Vietnam Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Saigon Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-india.php"><img
                                        src="source/images/India-Flag-icon.png" alt="India Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">India Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-middle-east.php"><img
                                        src="source/images/MiddleEast-Flag-icon.png" alt="Shipping to Middle East"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Middle East Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-china.php"><img
                                        src="source/images/China-Flag-icon.png" alt="China Shipper"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">China Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-philippines.php"><img
                                        src="source/images/Philippines-Flag-icon.png" alt="Philippines Shipper"
                                        width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Manila Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-spain.php"><img
                                        src="source/images/Spain-Flag-icon.png" alt="Spain Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Spain Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-mexico.php"><img
                                        src="source/images/Mexico-Flag-icon.png" alt="Mexico Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Mexico Shipper</span></a>
                            </li>
                            <li class="seperator"><a href="autos-to-canada.php"><img
                                        src="source/images/Canada-Flag-icon.png" alt="Canada Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Autos to Canada</span></a>
                            </li>
  <li class="seperator"><a href="importers-logistics-rep.php">Importer&#39;s Rep</a></li>

                        </ul>
                    </div>
                </td>
                <td style="vertical-align: top;">
                    <div class="col1" style="width: 250px;">

                        <ul class="menu-items">
                            <li class="seperator"><a href="shipping-to-africa.php">
                                    <img src="source/images/Africa-Flag-icon.png" alt="AfriCargo Express" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">AfriCargo Express</span></a>
                            </li>
                            <li class="seperator"><a href="shipping-to-latin-america.php">
                                    <img src="source/images/Latino-Flag-icon.png" alt="Latino Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Latino Shipper</span></a>
                            </li>
                              <li class="seperator"><a href="nvo.php">
                                    <img src="source/images/lcl-icon.jpg" alt="Latino Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Cargo-Coloader LCL</span></a>
                            </li>
                            <li class="seperator"><a href="a7s-pre-fulfilment-service.php"><img src="source/images/receiving-center-icon.png"
                                                                                      alt="Air7seas Pre-Fulfillment Service" width="22px"
                                                                                      style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Pre-Fulfillment &amp; Delivery </span></a></li>
                            <li class="seperator"><a href="receiving-center.php"><img src="source/images/receiving-center-icon.png"
                                                                                      alt="Mexico Shipper" width="22px"
                                                                                      style="position: absolute; margin-top: 1px;"><span
                                        style="margin-left: 33px;">Pre-Shipping Receiving Center</span></a></li>
                            <!--<li class="seperator"><a href="receiving-center.php">Receiving Center</a></li>-->
                            <li class="seperator"><a href="partners-agents.php"><img
                                        src="source/images/partners-agents-icon.png" alt="Canada Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Partners - Agents</span></a>
                            </li>
                            <li class="seperator"><a href="autos-vehicles-machinery.php"><img
                                        src="source/images/autos-vehicle-mechinery-icon.png" alt="Mexico Shipper" width="22px"
                                        style="position: absolute; margin-top: 1px;"><span style="margin-left: 33px;">Autos Vehicles Machinery</span></a>
                            </li>
                            <li class="seperator"><a href="transloading-transhipment.php">Transloading -
                                    Transhipment</a></li>
                            <li class="seperator"><a href="ship-hazardous-perishable-goods.php">Hazardous &amp;
                                    Perishable</a></li>


                        </ul>
                    </div>
                </td>
            </tr>
        </table>


    </div>
</li>
<li><a href="#">Mover &amp; Relocation</a>

    <div class="container-4" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="move-household-goods.php">Household Goods</a></li>
                <li class="seperator"><a href="ship-commercial-goods.php">Commercial Goods</a></li>
                <!--     <li class="seperator"><a href="#">Countries served</a></li> -->
            </ul>
        </div>
    </div>
</li>
<li><a href="#">Freight Carrier</a>

    <div class="container-4" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="air-freight-carrier.php">Air Freight Carrier</a></li>
                <li class="seperator"><a href="ocean-freight-carrier.php">Ocean Freight Carrier</a>
                </li>
                <li class="seperator"><a href="soc-movements.php">SOC Movements</a></li>
            </ul>
        </div>
    </div>
</li>
<li>
    <a href="#">Customs Release</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="export-import.php"">Export - Import</a></li>
                <li class="seperator"><a href="isf.php">ISF / AMS</a></li>
                <li class="seperator"><a href="importers-logistics-rep.php">Importer&#39;s Rep</a></li>
            </ul>
        </div>
    </div>
</li>

<li><a href="#">Insurance</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="cargo-insurance-coverage-types.php">Coverage Types</a></li>
                <li class="seperator"><a href="free-estimate-insurance.php">Free Estimate - Insurance</a>
                </li>
                <li class="seperator"><a href="order-online-insurance.php">Order Online - Insurance</a></li>
                <li class="seperator"><a href="claim-submission.php">Claim submission Form</a></li>
                <li class="seperator"><a href="faq-insurance.php">FAQ</a></li>
                <!--<li class="seperator"><a href="#">Resources - Insurance</a></li>-->
                <li class="seperator"><a href="damages-to-the-goods-by-customs.php">Damages to the goods by
                        Customs</a></li>

            </ul>
        </div>
    </div>
</li>
<li><a href="#">Contact Us</a>

    <div class="container-1" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="contact-us.php">Contacts</a></li>
                <li class="seperator"><a href="free-estimatesdetails.php">Get an Estimate</a></li>
                <li class="seperator"><a href="ordernowdetails.php">Book a Shipment</a></li>
                <li class="seperator"><a href="feedback.php">Feedback</a></li>
                <li class="seperator"><a href="complaint.php">Complaint</a></li>
                <li class="seperator"><a href="customer-review.php">Testimonial</a></li>
                <li class="seperator"><a href="claim-submission.php">Claim submission</a></li>
                <li class="seperator"><a href="terms-and-conditions.php">Terms &amp; Conditions</a></li>
                <li class="seperator"><a href="jobs.php">Jobs</a></li>
            </ul>
        </div>
    </div>
</li>
<li><a href="#" class="last-list">Tools &amp; Resources</a>

    <div class="container-1 right" style="width: 230px;">
        <div class="col1" style="width: 230px;">

            <ul class="menu-items">
                <li class="seperator"><a href="forms-downloads.php">Documents &amp; Forms</a></li>
                <li class="seperator"><a href="payments.php">Payment options</a></li>
                <li class="seperator"><a href="moving-tips.php">Moving Tips</a></li>
                <li class="seperator"><a href="container-sizes.php">Container Sizes for Sea</a></li>
                <li class="seperator"><a href="faq.php">FAQs</a></li>
                <li class="seperator"><a href="shipping-news.php">News &amp; Events</a></li>
                <li class="seperator"><a href="ask-a-question.php">Ask a question</a></li>
            </ul>
        </div>
    </div>
</li>

</ul>
</div>

</div>
<div id="info-bar" style="box-shadow: 0px 3px 3px 0px rgba(0, 0, 0, 0.15); position: relative; z-index: 100;"
     align="center">
    <div id="info-bar-area" align="left">
        <div class="top-thin-links">
            <div class="thin-links-wrapper">
                <a class="review" href="free-estimatesdetails.php"><span class="icon"></span><span>Free Shipping Estimate</span></a>
                <a class="finance" href="estimate-sizeof-shipment.php"><span
                        class="icon"></span><span>Moving Calculator</span></a>
                <a class="facebook" href="moving-tips.php"><span class="icon"></span><span>Moving Tips</span></a>
                <a class="catalogue" href="ordernowdetails.php"><span class="icon"></span><span>Order Online</span></a>
                <a class="trade-account" href="ask-a-question.php"><span class="icon"></span><span>Shipping ?</span></a>
            </div>
        </div>
    </div>
</div>

</body>
</html>

        <div id="contents" align="center">
            <div id="contentsArea" align="left" style="padding-left: 20px;">

                <!-- Top Information Bar -->
                <div id="BreadcrumbWrapper" style="width: 940px; margin-top: 12px;">
                    <div id="Breadcrumb" class="Breadcrumb BoxSBB">
                        <span itemscope itemtype='#'>
                            <a href="index.php" itemprop='url' title="Air7seas Homepage">
                                <span itemprop='title'>Home</span>
                            </a>
                        </span>
                        &rsaquo;
                        <span itemscope itemtype='#'>
                            <span itemprop='title'>
                                <b>Products</b>
                            </span>
                        </span>
                        &rsaquo;
                        <span itemscope itemtype='#'>
                            <span itemprop='title'>
                                <b>
                                    <a href="partners-agents.php">Partners &amp; Agents
                                    </a>
                                </b>
                            </span>
                        </span>
                        &rsaquo;
                        <span itemscope itemtype='#'>
                            <span itemprop='title'>
                                <b>USA De&#45;consolidation &amp; OCC Net Costs</b>
                            </span>
                        </span>
                    </div>

                </div>

                <div id="BreadcrumbWrapper" class="FL HMenu" style="margin-top: 0px;">
                    <h1 style="font-size: 18pt; font-family: 'open sans'; color: #3b3b3b; margin-bottom: 20px; font-weight: 600;">
                        USA De-consolidation, Devanning &amp; OCC/IPI&#39;s Charges</h1>


                    <div style="background-color: #f4f4f4;">
                        These COSTs are applicable only if Groupage/Consolidation to either NYC or LAX &amp; shmt is for any of the following destinations
                        (IPIs). OCC (On Carriage Chg) furnishd below would constitute your costs.

                    </div>
                    <br>

                    <h2 style="font-size: 12pt; font-family: 'open sans'; color: #3b3b3b; margin-bottom: 20px; font-weight: 600;">
                        Devanning charges at:</h2>
                    <table style="width: 100%;" cellpadding="0" cellspacing="0" class="devann-lax">
                        <tr>
                            <td></td>
                            <td></td>
                            <td>LAX</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>NYC</td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr style="background-color: #fff;">
                            <td style="width: 13%;">
                            </td>
                            <td style="width: 5%;">
                                20&#39;ST
                            </td>
                            <td style="width: 5%;">
                                40&#39;ST
                            </td>
                            <td style="width: 5%;">
                                40&#39;HC
                            </td>
                            <td style="width: 22%;"></td>
                            <td style="width: 5%;">
                                20&#39;ST
                            </td>
                            <td style="width: 5%;">
                                40&#39;ST
                            </td>
                            <td style="width: 5%;">
                                40&#39;HC
                            </td>
                            <td style="width: 22%;"></td>

                        </tr>
                        <tr>
                            <td>Devan</td>
                            <td>$215</td>
                            <td>$250</td>
                            <td>$250</td>
                            <td></td>
                            <td>$625</td>
                            <td>$725</td>
                            <td>$725</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>Trucking FCL</td>
                            <td>included</td>
                            <td>included</td>
                            <td>included</td>
                            <td>Overweight/Hazardous subject to additional charge</td>
                            <td>included</td>
                            <td>included</td>
                            <td>included</td>
                            <td>Overweight Handling Staten Island Pier(NYCT): $125</td>
                        </tr>
                        <tr>
                            <td>Consol Handling</td>
                            <td>$100</td>
                            <td>$150</td>
                            <td>$175</td>
                            <td></td>
                            <td>$100</td>
                            <td>$150</td>
                            <td>$175</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>Clean Truck &amp; Pier Pass Fee</td>
                            <td>$110</td>
                            <td>$220</td>
                            <td>$220</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </table>
                    <br>
                    <br>
                    
                    <table style="width: 100%;" cellpadding="0" cellspacing="0" class="ipi-code-lax-nyc">
                        <tr>
                            <td style="width: 7%;">
                                IPI Code
                            </td>
                            <td style="width: 15%;">
                                IPI City
                            </td>
                            <td style="width: 7%;">
                                State
                            </td>
                            <td style="width: 10%;">
                                Ex LAX
                            </td>
                            <td style="width: 10%;">
                                TT xLAX
                            </td>
                            <td style="width: 10%;">
                                Ex NYC
                            </td>
                            <td style="width: 10%;">
                                TT xNY
                            </td>
                            <td style="width: 10%;">
                                Frqncy
                            </td>
                            <td style="width: 25%;"></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>Days</td>
                            <td></td>
                            <td>Days</td>
                            <td>Days</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>CAK</td>
                            <td>Akron</td>
                            <td>OH</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>ABQ</td>
                            <td>Albuquerque</td>
                            <td>NM</td>
                            <td>$46.80</td>
                            <td>6 to 7</td>
                            <td>$80.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>ATL</td>
                            <td>Atlanta</td>
                            <td>GA</td>
                            <td>$40.80</td>
                            <td>10 to 11</td>
                            <td>$10.00</td>
                            <td>5</td>
                            <td>F/M</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>AUS</td>
                            <td>Austin</td>
                            <td>TX</td>
                            <td>$57.60</td>
                            <td>10 to 11</td>
                            <td>$71.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>BWI</td>
                            <td>Baltimore</td>
                            <td>MD</td>
                            <td>$52.80</td>
                            <td>11 to 12</td>
                            <td></td>
                            <td>2</td>
                            <td>Daily</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>BHM</td>
                            <td>Birmingham</td>
                            <td>AL</td>
                            <td>$54.00</td>
                            <td>10 to 11</td>
                            <td>$25.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>BOS</td>
                            <td>Boston</td>
                            <td>MA</td>
                            <td>$63.60</td>
                            <td>10 to 11</td>
                            <td></td>
                            <td>2</td>
                            <td>T/TH/F</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>BRO</td>
                            <td>Brownsville</td>
                            <td>TX</td>
                            <td>$51.60</td>
                            <td>5 to 6</td>
                            <td>$86.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>BUF</td>
                            <td>Buffalo</td>
                            <td>NY</td>
                            <td>$81.60</td>
                            <td>11 to 12</td>
                            <td>$24.00</td>
                            <td></td>
                            <td></td>
                            <td>$200 (Minim)</td>
                        </tr>
                        <tr>
                            <td>CHS</td>
                            <td>Charleston</td>
                            <td>SC</td>
                            <td>$57.60</td>
                            <td>9 to 10</td>
                            <td>$11.00</td>
                            <td>5</td>
                            <td>F/M</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>CLT</td>
                            <td>Charlotte</td>
                            <td>NC</td>
                            <td>$57.60</td>
                            <td>9 to 10</td>
                            <td>$13.00</td>
                            <td>5</td>
                            <td>F/M</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>CHA</td>
                            <td>Chattanooga</td>
                            <td>TN</td>
                            <td>$60.00</td>
                            <td>10 to 12</td>
                            <td>$25.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>CHI</td>
                            <td>Chicago</td>
                            <td>IL</td>
                            <td>$38.40</td>
                            <td>7 to 8</td>
                            <td>$13.00</td>
                            <td>4</td>
                            <td>M/T/Th</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>CVG</td>
                            <td>Cincinnati</td>
                            <td>OH</td>
                            <td>$50.40</td>
                            <td>9 to 10</td>
                            <td>$17.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>CLE</td>
                            <td>Cleveland</td>
                            <td>OH</td>
                            <td>$52.80</td>
                            <td>9 to 10</td>
                            <td>$12.00</td>
                            <td>4</td>
                            <td>M/T</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>CMH</td>
                            <td>Columbus</td>
                            <td>OH</td>
                            <td>$50.40</td>
                            <td>9 to 10</td>
                            <td>$14.00</td>
                            <td>4</td>
                            <td>M/T</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>DFW</td>
                            <td>Dallas&#45;Fort Worth</td>
                            <td>TX</td>
                            <td>$33.60</td>
                            <td>7 to 8</td>
                            <td>$35.00</td>
                            <td>9</td>
                            <td>W/TH</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>DAY</td>
                            <td>Dayton</td>
                            <td>OH</td>
                            <td>$54.00</td>
                            <td>9 to 10</td>
                            <td>$40.00</td>
                            <td>4</td>
                            <td>M/T</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>DEN</td>
                            <td>Denver</td>
                            <td>CO</td>
                            <td>$49.20</td>
                            <td>5 to 7</td>
                            <td>$77.00</td>
                            <td>13</td>
                            <td>W</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>DSM</td>
                            <td>Des Moines</td>
                            <td>IA</td>
                            <td>$56.40</td>
                            <td>6 to 7</td>
                            <td>$86.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>DTT</td>
                            <td>Detroit</td>
                            <td>MI</td>
                            <td>$52.80</td>
                            <td>9 to 10</td>
                            <td>$17.00</td>
                            <td>5</td>
                            <td>M/T</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>ELP</td>
                            <td>El Paso</td>
                            <td>TX</td>
                            <td>$50.40</td>
                            <td>5 to 6</td>
                            <td>$50.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>GPZ</td>
                            <td>Grand Rapids</td>
                            <td>MI</td>
                            <td>$56.40</td>
                            <td>9 to 10</td>
                            <td>$40.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>GSO</td>
                            <td>Greensboro</td>
                            <td>NC</td>
                            <td>$69.60</td>
                            <td>11 to 13</td>
                            <td>$32.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>GSP</td>
                            <td>Greenville</td>
                            <td>SC</td>
                            <td>$69.60</td>
                            <td>11 to 13</td>
                            <td>$29.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>Hidalgo</td>
                            <td>TX</td>
                            <td>$51.60</td>
                            <td>5 to 6</td>
                            <td>$87.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>HOU</td>
                            <td>Houston</td>
                            <td>TX</td>
                            <td>$32.40</td>
                            <td>5 to 6</td>
                            <td>$38.00</td>
                            <td>9</td>
                            <td>W/TH</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>HSV</td>
                            <td>Huntsville</td>
                            <td>AL</td>
                            <td>$57.60</td>
                            <td>10 to 11</td>
                            <td>$22.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>IND</td>
                            <td>Indianapolis</td>
                            <td>IN</td>
                            <td>$55.20</td>
                            <td>9 to 10</td>
                            <td>$38.00</td>
                            <td>9</td>
                            <td>M/T</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>JAX</td>
                            <td>Jacksonville</td>
                            <td>FL</td>
                            <td>$62.40</td>
                            <td>11 to 12</td>
                            <td>$21.00</td>
                            <td>7</td>
                            <td>F/M</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>MCI</td>
                            <td>Kansas City</td>
                            <td>MO</td>
                            <td>$38.40</td>
                            <td>9 to 10</td>
                            <td>$20.00</td>
                            <td>9</td>
                            <td>M/T</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>TYS</td>
                            <td>Knoxville</td>
                            <td>TN</td>
                            <td>$61.20</td>
                            <td>11 to 12</td>
                            <td>$22.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>LRD</td>
                            <td>Laredo</td>
                            <td>TX</td>
                            <td>$50.40</td>
                            <td>5 to 6</td>
                            <td>$82.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>LAS</td>
                            <td>Las Vegas *</td>
                            <td>NV</td>
                            <td>$55.20</td>
                            <td>3 to 4</td>
                            <td>$86.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>LIT</td>
                            <td>Little Rock</td>
                            <td>AR</td>
                            <td>$51.60</td>
                            <td>10 to 11</td>
                            <td>$30.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>LAX</td>
                            <td>Los Angeles</td>
                            <td>CA</td>
                            <td></td>
                            <td></td>
                            <td>$35.00</td>
                            <td>8</td>
                            <td>M/W/Fr</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>SDF</td>
                            <td>Louisville</td>
                            <td>KY</td>
                            <td>$60.00</td>
                            <td>9 to 10</td>
                            <td>$30.00</td>
                            <td>9</td>
                            <td>M/T</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>MEM</td>
                            <td>Memphis</td>
                            <td>TN</td>
                            <td>$45.60</td>
                            <td>8 to 9</td>
                            <td>$17.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>MIA</td>
                            <td>Miami</td>
                            <td>FL</td>
                            <td>$56.40</td>
                            <td>11 to 12</td>
                            <td>$20.00</td>
                            <td>6</td>
                            <td>F/M</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>MKE</td>
                            <td>Milwaukee</td>
                            <td>WI</td>
                            <td>$54.00</td>
                            <td>9 to 10</td>
                            <td>$40.00</td>
                            <td>9</td>
                            <td>M/T</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>MSP</td>
                            <td>Minneapolis/St.Paul</td>
                            <td>MN</td>
                            <td>$54.00</td>
                            <td>8 to 9</td>
                            <td>$40.00</td>
                            <td>9</td>
                            <td>M/T</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>MOB</td>
                            <td>Mobile</td>
                            <td>AL</td>
                            <td>$52.80</td>
                            <td>9 to 10</td>
                            <td>$25.00</td>
                            <td>9</td>
                            <td>F/M</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>YMQ</td>
                            <td>Montreal *</td>
                            <td>CN</td>
                            <td></td>
                            <td></td>
                            <td>$52.00</td>
                            <td></td>
                            <td></td>
                            <td>$160 (Minim)</td>
                        </tr>
                        <tr>
                            <td>BNA</td>
                            <td>Nashville</td>
                            <td>TN</td>
                            <td>$51.60</td>
                            <td>10 to 11</td>
                            <td>$20.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>MSY</td>
                            <td>New Orleans</td>
                            <td>LA</td>
                            <td>$49.20</td>
                            <td>9 to 10</td>
                            <td>$30.00</td>
                            <td>9</td>
                            <td>F/M</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>NYC</td>
                            <td>New York</td>
                            <td>NY</td>
                            <td>$50.40</td>
                            <td>8 to 9</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>Nogales</td>
                            <td>AZ</td>
                            <td>$57.60</td>
                            <td>5 to 6</td>
                            <td>$77.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>ORF</td>
                            <td>Norfolk</td>
                            <td>VA</td>
                            <td>$60.00</td>
                            <td>10 to 11</td>
                            <td>$12.00</td>
                            <td>3</td>
                            <td>T/W</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>OAK</td>
                            <td>Oakland *</td>
                            <td>CA</td>
                            <td>$29.00</td>
                            <td>3 to 4</td>
                            <td>$50.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>OKC</td>
                            <td>Oklahoma City</td>
                            <td>OK</td>
                            <td>$46.80</td>
                            <td>9 to 10</td>
                            <td>$40.00</td>
                            <td></td>
                            <td>W/Th</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>OMA</td>
                            <td>Omaha</td>
                            <td>NE</td>
                            <td>$57.60</td>
                            <td>6 to 7</td>
                            <td>$84.00</td>
                            <td></td>
                            <td>W via LA</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>MCO</td>
                            <td>Orlando</td>
                            <td>FL</td>
                            <td>$60.00</td>
                            <td>11 to 12</td>
                            <td>$28.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>PHL</td>
                            <td>Philadelphia</td>
                            <td>PA</td>
                            <td>$52.80</td>
                            <td>10 to 11</td>
                            <td></td>
                            <td>2</td>
                            <td>Daily</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>PHX</td>
                            <td>Phoenix</td>
                            <td>AZ</td>
                            <td>$43.20</td>
                            <td>5 to 6</td>
                            <td>$77.00</td>
                            <td>13</td>
                            <td>W</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>PIT</td>
                            <td>Pittsburg</td>
                            <td>PA</td>
                            <td>$69.60</td>
                            <td>9 to 10</td>
                            <td>$13.00</td>
                            <td>3</td>
                            <td>M/T</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>PVD</td>
                            <td>Providence **</td>
                            <td>RI</td>
                            <td>$66.00</td>
                            <td>11 to 13</td>
                            <td>$20.00</td>
                            <td></td>
                            <td></td>
                            <td>$150.00</td>
                        </tr>
                        <tr>
                            <td>PDX</td>
                            <td>Portland</td>
                            <td>OR</td>
                            <td>$49.20</td>
                            <td>5 to 6</td>
                            <td>$52.00</td>
                            <td>13</td>
                            <td>W</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>RDU</td>
                            <td>Raleigh/Durham</td>
                            <td>NC</td>
                            <td>$61.20</td>
                            <td>11 to 12</td>
                            <td>$27.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>RIC</td>
                            <td>Richmond</td>
                            <td>VA</td>
                            <td>$63.60</td>
                            <td>11 to 12</td>
                            <td>$18.00</td>
                            <td>5</td>
                            <td>T/W</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>ROC</td>
                            <td>Rochester **</td>
                            <td>NY</td>
                            <td>$79.20</td>
                            <td>5 to 6</td>
                            <td>$50.00</td>
                            <td></td>
                            <td></td>
                            <td>$275</td>
                        </tr>
                        <tr>
                            <td>SLC</td>
                            <td>Salt Lake City</td>
                            <td>UT</td>
                            <td>$49.20</td>
                            <td>5 to 6</td>
                            <td>$75.00</td>
                            <td>13</td>
                            <td>W</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>SAT</td>
                            <td>San Antonio</td>
                            <td>TX</td>
                            <td>$49.20</td>
                            <td>7 to 8</td>
                            <td>$73.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>SAN</td>
                            <td>San Diego</td>
                            <td>CA</td>
                            <td>$28.80</td>
                            <td>2 to 3</td>
                            <td>$52.00</td>
                            <td>13</td>
                            <td>W</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>SFO</td>
                            <td>San Francisco</td>
                            <td>CA</td>
                            <td>$32.40</td>
                            <td>3 to 4</td>
                            <td>$52.00</td>
                            <td>13</td>
                            <td>W</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>SAV</td>
                            <td>Savannah</td>
                            <td>GA</td>
                            <td>$58.80</td>
                            <td>10 to 11</td>
                            <td>$18.00</td>
                            <td>6</td>
                            <td>F/M</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>SEA</td>
                            <td>Seattle</td>
                            <td>WA</td>
                            <td>$49.20</td>
                            <td>3 to 4</td>
                            <td>$52.00</td>
                            <td></td>
                            <td>W</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>SHV</td>
                            <td>Shreveport</td>
                            <td>LA</td>
                            <td>$57.60</td>
                            <td>11 to 13</td>
                            <td>$57.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>SFY</td>
                            <td>Springfield</td>
                            <td>MI</td>
                            <td>$62.40</td>
                            <td>6 to 7</td>
                            <td>$40.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>STL</td>
                            <td>St. Louis</td>
                            <td>MO</td>
                            <td>$43.20</td>
                            <td>9 to 10</td>
                            <td>$20.00</td>
                            <td>9</td>
                            <td>M/T</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>TPA</td>
                            <td>Tampa</td>
                            <td>FL</td>
                            <td>$61.20</td>
                            <td>12 to 13</td>
                            <td>$20.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>TOL</td>
                            <td>Toledo</td>
                            <td>OH</td>
                            <td>$50.40</td>
                            <td>10 to 11</td>
                            <td>$28.00</td>
                            <td>7</td>
                            <td>M/T</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>YYZ</td>
                            <td>Toronto *</td>
                            <td>CN</td>
                            <td></td>
                            <td></td>
                            <td>$56.00</td>
                            <td></td>
                            <td></td>
                            <td>$180 (Minim)</td>
                        </tr>
                        <tr>
                            <td>TUS</td>
                            <td>Tucson</td>
                            <td>AZ</td>
                            <td>$56.40</td>
                            <td>5 to 6</td>
                            <td>$71.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>TUL</td>
                            <td>Tulsa</td>
                            <td>OK</td>
                            <td>$49.20</td>
                            <td>9 to 10</td>
                            <td>$75.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>IAD</td>
                            <td>Washington **</td>
                            <td>DC</td>
                            <td>$79.20</td>
                            <td>11 to 13</td>
                            <td>$25.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>ICT</td>
                            <td>Wichita</td>
                            <td>KS</td>
                            <td>$46.80</td>
                            <td>6 to 7</td>
                            <td>$45.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>ILM</td>
                            <td>Wilmington</td>
                            <td>NC</td>
                            <td>$61.20</td>
                            <td>11 to 12</td>
                            <td>$24.00</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>HNL</td>
                            <td>Honolulu</td>
                            <td>HI</td>
                            <td>Ask Rates</td>
                            <td>10 to 12</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>SJU</td>
                            <td>San Juan Puerto Rico</td>
                            <td>PR</td>
                            <td></td>
                            <td></td>
                            <td>Ask Rates</td>
                            <td>5 to 8 days</td>
                            <td>Th</td>
                            <td></td>
                        </tr>
                    </table>
                    <br>
                    <p>From NJ to Baltimore, Md, Philadelphia, PA & Boston, MA 足 No charge up to maximum of 15,000 lbs/6819k
                        or 15CBM
                        <br> Cargo exceeding the maximums as stated above, there is a charge of Freight at $10 per 1000Kgs/1
                        CBM,
                        <br> whichever produces the greater revenue with a minimum of $28.
                    </p>
                    <br>

                    <p>Rates are based on 1CBM or 800 lbs. Whichever is greater, minimum charge 1 CBM with the exception of
                        -
                    </p>

                    <p>
                        <span style="color: red;">*</span> Las Vegas (NV), Oakland via NYC (CA), Montreal &amp; Toronto (Canada) via NYC only = 3CBM
                        Minimum
                    </p>

                    <p>
                        <span style="color: red;">**</span> Providence RI; Rochester NY: Washington DC = 5 CBM Minim</p>
                    <br>

                    <p>18% Fuel Surcharged should be added to all IPI, I.T., BONDED or DOMESTIC Inland Moved
                        <b>VIA NEW YORK (Variable)</b>
                    </p>

                    <p>35% Fuel Surcharged should be added to all IPI, I.T., BONDED or DOMESTIC Inland Moved
                        <b>VIA LOS ANGELES (Variable)</b>
                    </p>
                    <br>
                    <table style="width: 100%;" cellpadding="0" cellspacing="0" class="it-entry">
                        <tr>
                            <td style="width: 30%;">
                                Terminal IN &amp; OUT fee at IPI&#39;s Range

                            </td>
                            <td style="width: 20%;">
                                $75-$250

                            </td>
                            <td style="width: 20%;">
                                Per shipment

                            </td>
                            <td style="width: 30%;">
                                Various for IPI charged at actual + $15

                            </td>
                        </tr>
                        <tr>
                            <td>Docs fee range
                            </td>
                            <td>$25-$65
                            </td>
                            <td>per shipment</td>
                            <td>Paid by Consignee
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 30%;">
                                I.T. Entry Preparation/Cancellation Fee
                            </td>
                            <td style="width: 20%;">
                                $35.00
                            </td>
                            <td style="width: 20%;">
                                each IPI shipment
                            </td>
                            <td style="width: 30%;">
                                I.T. = (Immediate Transport)
                            </td>
                        </tr>
                        <tr>
                            <td>Personal Effects shipment</td>
                            <td>$10</td>
                            <td>per shipment</td>
                            <td>Paid by Consignee (not shipper)</td>
                        </tr>
                        <tr>
                            <td>Haz Cargo Surcharge; MSDS required</td>
                            <td>At Actual + $ 45</td>
                            <td>per shipment</td>
                            <td>Must take prior approval</td>
                        </tr>
                        <tr>
                            <td>Cargo Reweigh/Remeasure</td>
                            <td>$35</td>
                            <td>per shipment</td>
                            <td>Paid by Consignee (not shipper)</td>
                        </tr>

                        <tr>
                            <td>Carton Segregation/Labeling</td>
                            <td>$8/cbm / 800Lbs</td>
                            <td>per carton,Minim $50</td>
                            <td>Paid by Consignee (not shipper)</td>
                        </tr>

                    </table>
                    <br>

                    <p> #.- May vary at different warehouse</p>

                    <p>Over Dimensional/Weight: 1pc >10ft/10,000lbs- $15 per cbm/800lbs Max $100/Pc with Disclaimer</p>
                    <br>
                    <ul style="padding: 10px 30px; line-height: 2;">
                        <li>Your selling Freight Rates for these IPI points can be reflected separately on HBL or be included
                            in WM Freight Rate.</li>
                        <li>Master B/Lading should be consigned to Air7Seas.</li>
                        <li>HBL must includes Tel. No. of Cnee. </li>
                    </ul>

                    <div style="margin-top: 20px;">
                        <h2 class="title">Services/Accessorial Charges</h2>
                        <ul style="padding: 10px 30px; line-height: 2;">
                            <li>Rates apply to Normal FAK/General Cargo. LCL Cargoes 30,000#/30cbm or greater per HBL add $10.00/cbm/800
                                lbs to destination base rate
                            </li>
                            <li>IT Preparation Charge -0- IT Cancellation or Amend $30</li>
                            <li>Since above rates reflect "NON-EXCLUSIVE" use of our trailer loads, please be advised that loading
                                dates may vary. It is up to each CONSOLIDATOR or IMPORTER or SHIPPER to verify DEPARTURE
                                DATE and/or ARRIVAL DATE at inland destination. We offer ESTIMATED TIMES ONLY and cannot
                                be held liable for any charges arising from EARLY or LATE arrival.
                            </li>
                            <li>IPI PROCEDURES - IPI CARGO is placed in it's assigned location at CFS/NY warehouse upon devan.
                                Cargoes are then reloaded according to volume and frequency of service. If IPI CARGO is destined
                                for ANOTHER ASSIGNED CFS then all freight releases must be surrendered directly to that assigned
                                CFS (not to CFS/NJ). In addition it is up to the ASSIGNED CFS to arrange validation of I.T.'s.
                                We accept no responsibilities for guarantees and/or releases. If IPI cargo is destined for
                                another location (of customers choice) not only do we accept no responsibility of freight
                                releases and/or guarantees, but I.T.'s must be validated by that CUSTOMER's ASSIGNED CFS
                                with U.S CUSTOMS.
                                <br>
                                <i> PLEASE NOTE: All I.T.'s clearly state the CFS DESTINATION. It is imperative customers read
                                    and double check that all information is accurate according to your files. we accept
                                    no responsibility for errors and omissions as a result thereof.</i>
                            </li>
                        </ul>
                    </div>
                    <p style="margin-top: 20px;" align="center">
                        <i>Information as of March 2018 period, Rates may change without Notice</i>
                    </p>
                </div>
            </div>
        </div>
        <!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" lang="en">


<head>
    <!--Start of Zopim Live Chat Script
    <script type="text/javascript">
        window.$zopim || (function (d, s) {
            var z = $zopim = function (c) {
                z._.push(c)
            }, $ = z.s =
                d.createElement(s), e = d.getElementsByTagName(s)[0];
            z.set = function (o) {
                z.set.
                    _.push(o)
            };
            z._ = [];
            z.set._ = [];
            $.async = !0;
            $.setAttribute('charset', 'utf-8');
            $.src = '//v2.zopim.com/?2NBKvMLseKA8C45Gr5ywmelLErtAkht6';
            z.t = +new Date;
            $.
                type = 'text/javascript';
            e.parentNode.insertBefore($, e)
        })(document, 'script');
    </script>
    End of Zopim Live Chat Script-->
    
    <!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = '3kWxTfUv3x';var d=document;var w=window;function l(){
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
<!-- {/literal} END JIVOSITE CODE -->

    <link href="source/css/sole.css" rel="stylesheet">

<body class="vpform pgTrustPilot" lang="en-GB" align="center">


<div id="footerinfo" style="width: 100%; background-color: #cccccc" align="center">
    <div style="width: 980px; background-color: #ffffff; padding: 10px 0px;" align="left">
        <div id="BreadcrumbWrapper">
            <div class="section group">
                <div class="col span_12_of_12" style="line-height: 23px; border-right: 1px solid #dddddd; ">
                </div>
            </div>
            <hr>
        </div>
        <img src="source/images/logos.jpg" alt="" style="width: 980px;">
        <div style="margin-left:40px;">
            <a id="bbblink" class="ruvtbum" target="_blank" href="https://www.bbb.org/us/ca/milpitas/profile/logistics/air-7-seas-transport-logistics-1216-213698#bbbseal"
        title="AIR 7 SEAS Transport Logistics Inc, Logistics, Milpitas, CA"
        style="display: block;position: relative;overflow: hidden; width: 60px; height: 108px; margin: 0">
        <img style="padding: 0px; border: none;" id="bbblinkimg" src="https://seal-sanjose.bbb.org/logo/ruvtbum/air-7-seas-transport-logistics-213698.png" width="120" height="108" alt="AIR 7 SEAS Transport Logistics Inc, Logistics, Milpitas, CA" />
        </a>    
        </div>
        
        <script type="text/javascript">var bbbprotocol = ( ("https:" == document.location.protocol) ? "https://" : "http://" ); (function(){var s=document.createElement('script');s.src=bbbprotocol + 'seal-sanjose.bbb.org' + unescape('%2Flogo%2Fair-7-seas-transport-logistics-213698.js');s.type='text/javascript';s.async=true;var st=document.getElementsByTagName('script');st=st[st.length-1];var pt=st.parentNode;pt.insertBefore(s,pt.nextSibling);})();
        </script>
    </div>
</div>
<!--footer-->
<footer style="background-color: #4d4d4d">
    <div class="DB MMdLFtR">
        <div class="FL DB MMdLFtRa" style="padding-left: 75px;">

            <div id="FtR" class="LH20 footer-links">
                <div class="left-section FL">
                    <div class="left-wrapper FL">
                        <section class="ordering-fromus">
                            <div class="title">
                                AIR 7 SEAS
                            </div>
                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="about-air7seas.php" id="aContact">About Us</a>
                                    <a href="feedback.php" id="aFAQ">Feedback</a>
                                    <a href="shipping-news.php" id="aOrdertracking">News &amp;
                                        Events</a>
                                    <a href="#">Privacy Policy</a>
                                    <a href="terms-and-conditions.php">Terms &amp;
                                        Conditions</a>
                                    <a href="jobs.php">Jobs</a>
                                </li>
                            </ul>
                        </section>
                        <section class="help-support">
                            <div class="title">
                                SERVICES
                            </div>

                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="international-freight.php">International &#45;
                                        Freight</a>
                                    <a href="domestic-freight.php">Domestic &#45;
                                        Freight</a>
                                    <a href="autos-vehicles-machinery.php">Machinery &amp; Vehicles</a>
                                    <a href="freight-forwarder.php">Freight Forwarding</a>
                                    <a href="customs-release.php">Customs Release</a>
                                    <a href="moving.php">Movers</a>
                                </li>
                            </ul>
                        </section>
                        <section class="information">
                            <div class="title">
                                SUPPORT
                            </div>
                            <ul class="FL FTR8">
                                <li class="FL">
                                    <a href="faq.php">Frequently Asked Questions</a>
                                    <a href="moving-tips.php">Moving Tips</a>

                                    <a href="payments.php" id="aFreeRecycle">Payment Options</a>
                                    <a href="procedural-steps-for-claim-submition.php">Claim
                                        Submission Procedures</a>
                                    <a href="isf.php">Importer Security Filing (ISF)</a>
                                    <a href="order-online-insurance.php">Order Online -
                                        Insurance</a>

                                </li>
                            </ul>
                        </section>
                    </div>
                    <div class="social-links">


                    </div>
                </div>
                <section class="newsletter">
                    <div class="title">CORPORATE OFFICE</div>
                    <div class="footer-contact">
                        <ul>
                            <li class="f-map"><a
                                    href="contact-us.php"
                                    target="_blank">1815 Houret Court, <br> Milpitas, CA 95035, US</a></li>
                            <li class="f-phone"><span><a href="tel:+18882477732">Call Us: 1-888-247-7732</a></span></li>
                            <li class="f-mail"><a href="mailto:info@air7seas.us">info (@) air7seas.us</a></li>
                        </ul>
                    </div>
                    <br><br>

                    <div>
                        <a href="https://www.facebook.com/pages/Air7Seas-Transport-Logistics-Inc/731149066945233" target="_blank">
                            <img src="source/images/icons/fb.png" style="margin-top: 7px; width: 25px;">
                        </a>&nbsp;
                        <a href="https://twitter.com/Air7seas" target="_blank">
                            <img src="source/images/icons/twitter.png" style="margin-top: 7px; width: 25px;">
                        </a>&nbsp;
                        <a href="https://www.google.com/maps/place/AIR+7+SEAS+Transport+Logistics+Inc/@37.405497,-121.8994427,17z/data=!3m1!4b1!4m5!3m4!1s0x808fceb215c020c3:0x183384c4fb534d3c!8m2!3d37.405497!4d-121.897254" target="_blank">
                            <img src="source/images/icons/gp.png" style="margin-top: 7px; width: 25px;">
                        </a>
                    </div>

                </section>
            </div>
        </div>
    </div>

</footer>

<div class="baseline-footer">
    <div class="baseline-footer-wrapper">
        <section class="FL" itemprop="provider" itemscope itemtype="http://schema.org/Organization">
            <div class="FL">

                <meta itemprop="url" content="http://www.air7seas.com/"/>
                <meta itemprop="name" content="Air 7 Seas Transport Logistics Pvt Ltd"/>
                <meta itemprop="email" content="info@air7seas.com "/>
                <div itemprop="location" itemscope itemtype="http://www.schema.org/LocalBusiness">

                    <meta itemprop="openingHours" content="Mo-Fr 08:00-16:00"/>
                    <meta itemprop="openingHours" content="Sa-Su Holiday"/>
                    <div itemprop="geo" itemscope itemtype="http://schema.org/GeoCoordinates">
                        <meta itemprop="latitude" content="53.55519"/>
                        <meta itemprop="longitude" content="-3.041651"/>
                    </div>
                </div>

            </div>
            <div class="contact-information">
                <div id="pnlUKFooter">

                    <div class="address" itemprop=address itemscope itemtype=http://schema.org/PostalAddress>
                        <span class="address-image"></span>

                        <div class="address-wrapper">
                            <span itemprop=streetAddress><a href="contact-us.php" style="color: #cfcfcf;">1815 Houret
                                    Court,<br> Milpitas, CA 95035</a></span>,
                            <span itemprop=addressLocality>USA</span>
                        </div>
                    </div>
                    <div class="phone-number">
                        <span class="phone-image"></span>
                        <span class="telephone" itemprop=telephone><a href="tel:+18882477732" style="color: #cfcfcf;">1-888-247-7732</a></span>
                        <span class="sales-support">(Customer Support)</span>
                    </div>
                    <div class="email-address">
                        <span class="email-img"></span>
                        <span itemprop=email><a class="mail-id"
                                                href="mailto:info@air7seas.us">info (@) air7seas.us</a></span>
                    </div>


                </div>

            </div>
        </section>


        <div itemprop="copyrightHolder" itemscope itemtype="http://www.schema.org/Organization"
             class="copywrite-holder">
            <meta itemprop="url" content="http://www.air7seas.com/"/>
            <meta itemprop="name" content="Air 7 Seas Transport Logistics Pvt Ltd"/>

            <meta itemprop="email" content="info@air7seas.com "/>

            Copyright <span class="copyrights">&copy;</span> AIR 7 SEAS 2014 &#45; 2015
        </div>
        <meta itemprop="copyrightYear" content="1986-2014"/>

        <div class="divAuthorisedText">Authorised and regulated by AIR 7 SEAS 95035</div>


    </div>
</div>

</body>
</html>

    </body>

    </html>